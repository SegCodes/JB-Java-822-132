package app.core.services;

import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class LoginManager {

	public enum ClientType {
		ADMINISTRATOR, COMPANY, CUSTOMER;
	}

	/**
	 * Attempt to login using the entered email and password as the entered client
	 * type.
	 * 
	 * @param email      - The entered email.
	 * @param password   - The entered password.
	 * @param clientType - The entered client type to login as.
	 * @param ctx        - The application context to get beans to run the login
	 *                   check.
	 * @return The matching client service of the client type if the login is
	 *         successful, or null if the login failed.
	 */
	public static ClientService Login(String email, String password, ClientType clientType, ApplicationContext ctx) {
		if (clientType.equals(ClientType.ADMINISTRATOR)) {
			AdminService adminService = ctx.getBean(AdminService.class);
			if (adminService.login(email, password)) {
				return adminService;
			}
			return null;

		} else if (clientType.equals(ClientType.COMPANY)) {
			CompanyService companySerivce = ctx.getBean(CompanyService.class);
			if (companySerivce.login(email, password)) {
				return companySerivce;
			}
			return null;

		} else {
			CustomerService customerService = ctx.getBean(CustomerService.class);
			if (customerService.login(email, password)) {
				return customerService;
			}
			return null;
		}
	}
}
