package app.core.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import app.core.entities.Coupon;
import app.core.entities.Coupon.Category;
import app.core.entities.Customer;
import app.core.exceptions.ServiceException;
import app.core.services.CustomerService;

public class CustomerScreen {

	private CustomerService service;
	private static final JFrame FRAME = new JFrame("Coupon System - Company");
	private SpringLayout CONTENT_LAYOUT;
	private JPanel CONTENT;
	private Dimension screenSize;

	public CustomerScreen(CustomerService customerService) {
		screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		service = customerService;
		startCustomerScreen();
	}

	private void startCustomerScreen() {
		FRAME.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		FRAME.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.7), (int) (screenSize.getHeight() / 1.4)));

		CONTENT_LAYOUT = new SpringLayout();
		CONTENT = new JPanel(CONTENT_LAYOUT);

		JMenuBar menuBar = new JMenuBar();

		JMenu accountMenu = new JMenu("Account");

		JMenuItem getInfo = new JMenuItem("Get Info");
		getInfo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				CONTENT.removeAll();
				setGetInfoComponents();
			}
		});
		accountMenu.add(getInfo);

		JMenuItem logout = new JMenuItem("Logout");
		logout.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				FRAME.dispose();
				LoginScreen.startLoginScreen(null);
			}
		});
		accountMenu.add(logout);

		menuBar.add(accountMenu);

		JMenu couponsMenu = new JMenu("Coupons");

		JMenuItem purchaseCoupon = new JMenuItem("Purchase");
		purchaseCoupon.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				CONTENT.removeAll();
				setPurchaseCouponComponents();
			}
		});
		couponsMenu.add(purchaseCoupon);

		JMenu getCouponsMenu = new JMenu("Get");

		JMenuItem getAllCoupons = new JMenuItem("All");
		getAllCoupons.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				CONTENT.removeAll();
				setGetAllCouponsComponents();
			}
		});
		getCouponsMenu.add(getAllCoupons);

		JMenuItem getCouponsByCategory = new JMenuItem("By Category");
		getCouponsByCategory.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				CONTENT.removeAll();
				setGetCouponsByCategoryComponents();
			}
		});
		getCouponsMenu.add(getCouponsByCategory);

		JMenuItem getCouponsByPrice = new JMenuItem("By Price");
		getCouponsByPrice.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				CONTENT.removeAll();
				setGetCouponsByPriceComponents();
			}
		});
		getCouponsMenu.add(getCouponsByPrice);

		couponsMenu.add(getCouponsMenu);

		menuBar.add(couponsMenu);

		FRAME.setJMenuBar(menuBar);
		FRAME.setContentPane(CONTENT);
		FRAME.setResizable(false);
		FRAME.pack();
		FRAME.setVisible(true);
		FRAME.setLocationRelativeTo(null);
	}

	private void setGetInfoComponents() {
		JLabel title = new JLabel("Customer Info");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		CONTENT.add(title);

		JPanel fieldsPanel = new JPanel();
		fieldsPanel.setLayout(new GridLayout(5, 1, 3, 3));

		JPanel idPanel = new JPanel();
		idPanel.setBorder(BorderFactory.createTitledBorder("ID"));

		JTextField idField = new JTextField();
		idField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		idField.setFocusable(false);
		idPanel.add(idField);

		fieldsPanel.add(idPanel);

		JPanel fNamePanel = new JPanel();
		fNamePanel.setBorder(BorderFactory.createTitledBorder("First Name"));

		JTextField fNameField = new JTextField();
		fNameField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		fNameField.setFocusable(false);
		fNamePanel.add(fNameField);

		fieldsPanel.add(fNamePanel);

		JPanel lNamePanel = new JPanel();
		lNamePanel.setBorder(BorderFactory.createTitledBorder("Last Name"));

		JTextField lNameField = new JTextField();
		lNameField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		lNameField.setFocusable(false);
		lNamePanel.add(lNameField);

		fieldsPanel.add(lNamePanel);

		JPanel emailPanel = new JPanel();
		emailPanel.setBorder(BorderFactory.createTitledBorder("Email"));

		JTextField emailField = new JTextField();
		emailField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		emailField.setFocusable(false);
		emailPanel.add(emailField);

		fieldsPanel.add(emailPanel);

		JPanel passwordPanel = new JPanel();
		passwordPanel.setBorder(BorderFactory.createTitledBorder("Password"));

		JTextField passwordField = new JTextField();
		passwordField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		passwordField.setFocusable(false);
		passwordPanel.add(passwordField);

		fieldsPanel.add(passwordPanel);

		Customer customer;
		try {
			customer = service.getInfo();
			idField.setText(String.valueOf(customer.getId()));
			fNameField.setText(customer.getFirstName());
			lNameField.setText(customer.getLastName());
			emailField.setText(customer.getEmail());
			passwordField.setText(customer.getPassword());

		} catch (ServiceException e) {
			e.printStackTrace();
			if (e.getCause() != null) {
				e.getCause().printStackTrace();
			}
			JOptionPane.showMessageDialog(null, e.getMessage(), "Customer Info Retrieval Failure",
					JOptionPane.ERROR_MESSAGE);

			idField.setText(null);
			fNameField.setText(null);
			lNameField.setText(null);
			emailField.setText(null);
			passwordField.setText(null);
		}

		CONTENT.add(fieldsPanel);

		CONTENT_LAYOUT.putConstraint(SpringLayout.NORTH, title, (int) (CONTENT.getHeight() * 0.1), SpringLayout.NORTH,
				CONTENT);
		CONTENT_LAYOUT.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, CONTENT);

		CONTENT_LAYOUT.putConstraint(SpringLayout.NORTH, fieldsPanel, 10, SpringLayout.SOUTH, title);
		CONTENT_LAYOUT.putConstraint(SpringLayout.HORIZONTAL_CENTER, fieldsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				CONTENT);

		CONTENT.revalidate();
		CONTENT.repaint();
	}

	private void setPurchaseCouponComponents() {
		JLabel title = new JLabel("Purchase Coupon");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		CONTENT.add(title);

		JPanel fieldPanel = new JPanel();
		fieldPanel.setBorder(BorderFactory.createTitledBorder("ID"));

		JTextField idField = new JTextField();
		idField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		fieldPanel.add(idField);

		CONTENT.add(fieldPanel);

		JPanel buttonsPanel = new JPanel(new GridLayout(1, 2, 5, 5));

		JButton purchaseButton = new JButton("Purchase");
		purchaseButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if (idField.getText().isBlank()) {
						throw new Exception("Cannot purchase a coupon without id.");
					}
					int id = Integer.parseInt(idField.getText());

					service.purchaseCoupon(new Coupon(id));
					JOptionPane.showMessageDialog(null,
							"Purchased coupon with id #" + id + ". Go to Get Coupons to see it.",
							"Coupon Purchase Success", JOptionPane.INFORMATION_MESSAGE);

				} catch (NumberFormatException e1) {
					e1.printStackTrace();
					if (e1.getCause() != null) {
						e1.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "Invalid id Input.", "Coupon Purchase Failure",
							JOptionPane.ERROR_MESSAGE);

				} catch (Exception e2) {
					e2.printStackTrace();
					if (e2.getCause() != null) {
						e2.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, e2.getMessage(), "Coupon Purchase Failure",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		buttonsPanel.add(purchaseButton);

		JButton clearButton = new JButton("Clear");
		clearButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				idField.setText(null);
			}
		});
		buttonsPanel.add(clearButton);

		CONTENT.add(buttonsPanel);

		CONTENT_LAYOUT.putConstraint(SpringLayout.NORTH, title, (int) (CONTENT.getHeight() * 0.1), SpringLayout.NORTH,
				CONTENT);
		CONTENT_LAYOUT.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, CONTENT);

		CONTENT_LAYOUT.putConstraint(SpringLayout.NORTH, fieldPanel, 10, SpringLayout.SOUTH, title);
		CONTENT_LAYOUT.putConstraint(SpringLayout.HORIZONTAL_CENTER, fieldPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				CONTENT);

		CONTENT_LAYOUT.putConstraint(SpringLayout.NORTH, buttonsPanel, 10, SpringLayout.SOUTH, fieldPanel);
		CONTENT_LAYOUT.putConstraint(SpringLayout.HORIZONTAL_CENTER, buttonsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				CONTENT);

		CONTENT.revalidate();
		CONTENT.repaint();
	}

	private void setGetAllCouponsComponents() {
		JLabel title = new JLabel("All Coupons");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		CONTENT.add(title);

		String[] cols = { "ID", "Company ID", "Category", "Title", "Description", "Start Date", "Expiration Date",
				"Amount", "Price", "Image Path" };
		DefaultTableModel tm = new DefaultTableModel(cols, 0);
		tm.addRow(cols);
		JTable table = new JTable(tm) {

			@Override
			public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
				Component component = super.prepareRenderer(renderer, row, column);
				int rendererWidth = component.getPreferredSize().width;
				TableColumn tableColumn = getColumnModel().getColumn(column);
				tableColumn.setPreferredWidth(
						Math.max(rendererWidth + getIntercellSpacing().width, tableColumn.getPreferredWidth()));
				return component;
			}
		};
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setBorder(new LineBorder(Color.black));
		DefaultTableCellRenderer cellRender = new DefaultTableCellRenderer();
		cellRender.setHorizontalAlignment(SwingConstants.CENTER);

		for (int i = 0; i < table.getColumnCount(); i++) {
			table.getColumnModel().getColumn(i).setCellRenderer(cellRender);
		}

		try {
			List<Coupon> coupons = service.getCoupons();
			for (int i = 0; i < coupons.size(); i++) {
				int id = coupons.get(i).getId();
				int companyID = coupons.get(i).getCompany().getId();
				Category category = coupons.get(i).getCategory();
				String couponTitle = coupons.get(i).getTitle();
				String description = coupons.get(i).getDescription();
				LocalDate startDate = coupons.get(i).getStartDate();
				LocalDate endDate = coupons.get(i).getEndDate();
				int amount = coupons.get(i).getAmount();
				double price = coupons.get(i).getPrice();
				String imgPath = coupons.get(i).getImgPath();
				Object[] vals = { id, companyID, category, couponTitle, description, startDate, endDate, amount, price,
						imgPath };
				tm.addRow(vals);
			}
		} catch (ServiceException e) {
			e.printStackTrace();
			if (e.getCause() != null) {
				e.getCause().printStackTrace();
			}
			JOptionPane.showMessageDialog(null, e.getMessage(), "Coupons Retrieval Failure", JOptionPane.ERROR_MESSAGE);
		}
		CONTENT.add(table);

		CONTENT_LAYOUT.putConstraint(SpringLayout.NORTH, title, (int) (CONTENT.getHeight() * 0.1), SpringLayout.NORTH,
				CONTENT);
		CONTENT_LAYOUT.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, CONTENT);

		CONTENT_LAYOUT.putConstraint(SpringLayout.NORTH, table, 10, SpringLayout.SOUTH, title);
		CONTENT_LAYOUT.putConstraint(SpringLayout.HORIZONTAL_CENTER, table, 0, SpringLayout.HORIZONTAL_CENTER, CONTENT);

		CONTENT.revalidate();
		CONTENT.repaint();
	}

	private void setGetCouponsByCategoryComponents() {
		JLabel title = new JLabel("All Coupons");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		CONTENT.add(title);

		JPanel categoriesPanel = new JPanel();
		categoriesPanel.setBorder(new TitledBorder("Categories"));

		JComboBox<Category> categoriesList = new JComboBox<>(Category.values());
		categoriesPanel.add(categoriesList);

		String[] cols = { "ID", "Company ID", "Category", "Title", "Description", "Start Date", "Expiration Date",
				"Amount", "Price", "Image Path" };
		DefaultTableModel tm = new DefaultTableModel(cols, 0);
		tm.addRow(cols);
		JTable table = new JTable(tm) {

			@Override
			public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
				Component component = super.prepareRenderer(renderer, row, column);
				int rendererWidth = component.getPreferredSize().width;
				TableColumn tableColumn = getColumnModel().getColumn(column);
				tableColumn.setPreferredWidth(
						Math.max(rendererWidth + getIntercellSpacing().width, tableColumn.getPreferredWidth()));
				return component;
			}
		};
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setBorder(new LineBorder(Color.black));
		DefaultTableCellRenderer cellRender = new DefaultTableCellRenderer();
		cellRender.setHorizontalAlignment(SwingConstants.CENTER);

		for (int i = 0; i < table.getColumnCount(); i++) {
			table.getColumnModel().getColumn(i).setCellRenderer(cellRender);
		}

		CONTENT.add(table);

		JButton showButton = new JButton("Show");
		showButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					List<Coupon> coupons = service.getCoupons((Category) categoriesList.getSelectedItem());

					if (tm.getRowCount() > 1) {
						for (int i = tm.getRowCount() - 1; i > 0; i--) {
							tm.removeRow(i);
						}
					}
					
					for (int i = 0; i < coupons.size(); i++) {
						int id = coupons.get(i).getId();
						int companyID = coupons.get(i).getCompany().getId();
						Category category = coupons.get(i).getCategory();
						String couponTitle = coupons.get(i).getTitle();
						String description = coupons.get(i).getDescription();
						LocalDate startDate = coupons.get(i).getStartDate();
						LocalDate endDate = coupons.get(i).getEndDate();
						int amount = coupons.get(i).getAmount();
						double price = coupons.get(i).getPrice();
						String imgPath = coupons.get(i).getImgPath();
						
						Object[] vals = { id, companyID, category, couponTitle, description, startDate, endDate, amount,
								price, imgPath };
						tm.addRow(vals);
					}
					
					CONTENT.revalidate();
					CONTENT.repaint();
				} catch (ServiceException e1) {
					e1.printStackTrace();
					
					if (e1.getCause() != null) {
						e1.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, e1.getMessage(), "Coupons Retrieval By Category Failure",
							JOptionPane.ERROR_MESSAGE);
					
					if (tm.getRowCount() > 1) {
						for (int i = tm.getRowCount() - 1; i > 0; i--) {
							tm.removeRow(i);
						}
					}
				}
			}
		});
		categoriesPanel.add(showButton);

		CONTENT.add(categoriesPanel);

		CONTENT_LAYOUT.putConstraint(SpringLayout.NORTH, title, (int) (CONTENT.getHeight() * 0.1), SpringLayout.NORTH,
				CONTENT);
		CONTENT_LAYOUT.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, CONTENT);

		CONTENT_LAYOUT.putConstraint(SpringLayout.NORTH, categoriesPanel, 10, SpringLayout.SOUTH, title);
		CONTENT_LAYOUT.putConstraint(SpringLayout.HORIZONTAL_CENTER, categoriesPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				CONTENT);

		CONTENT_LAYOUT.putConstraint(SpringLayout.NORTH, table, 10, SpringLayout.SOUTH, categoriesPanel);
		CONTENT_LAYOUT.putConstraint(SpringLayout.HORIZONTAL_CENTER, table, 0, SpringLayout.HORIZONTAL_CENTER, CONTENT);

		CONTENT.revalidate();
		CONTENT.repaint();
	}

	private void setGetCouponsByPriceComponents() {
		JLabel title = new JLabel("All Coupons");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		CONTENT.add(title);

		JPanel pricePanel = new JPanel();
		pricePanel.setBorder(new TitledBorder("Price"));

		JTextField priceField = new JTextField();
		priceField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.04), (int) (screenSize.getHeight() * 0.02)));
		pricePanel.add(priceField);

		String[] cols = { "ID", "Company ID", "Category", "Title", "Description", "Start Date", "Expiration Date",
				"Amount", "Price", "Image Path" };
		DefaultTableModel tm = new DefaultTableModel(cols, 0);
		tm.addRow(cols);
		JTable table = new JTable(tm) {

			@Override
			public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
				Component component = super.prepareRenderer(renderer, row, column);
				int rendererWidth = component.getPreferredSize().width;
				TableColumn tableColumn = getColumnModel().getColumn(column);
				tableColumn.setPreferredWidth(
						Math.max(rendererWidth + getIntercellSpacing().width, tableColumn.getPreferredWidth()));
				return component;
			}
		};
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setBorder(new LineBorder(Color.black));
		DefaultTableCellRenderer cellRender = new DefaultTableCellRenderer();
		cellRender.setHorizontalAlignment(SwingConstants.CENTER);

		for (int i = 0; i < table.getColumnCount(); i++) {
			table.getColumnModel().getColumn(i).setCellRenderer(cellRender);
		}

		CONTENT.add(table);

		JButton showButton = new JButton("Show");
		showButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					double maxPrice = Double.parseDouble(priceField.getText());
					List<Coupon> coupons = service.getCoupons(maxPrice);

					if (tm.getRowCount() > 1) {
						for (int i = tm.getRowCount() - 1; i > 0; i--) {
							tm.removeRow(i);
						}
					}
					for (int i = 0; i < coupons.size(); i++) {
						int id = coupons.get(i).getId();
						int companyID = coupons.get(i).getCompany().getId();
						Category category = coupons.get(i).getCategory();
						String couponTitle = coupons.get(i).getTitle();
						String description = coupons.get(i).getDescription();
						LocalDate startDate = coupons.get(i).getStartDate();
						LocalDate endDate = coupons.get(i).getEndDate();
						int amount = coupons.get(i).getAmount();
						double price = coupons.get(i).getPrice();
						String imgPath = coupons.get(i).getImgPath();
						
						Object[] vals = { id, companyID, category, couponTitle, description, startDate, endDate, amount,
								price, imgPath };
						tm.addRow(vals);
					}
					CONTENT.revalidate();
					CONTENT.repaint();

				} catch (NumberFormatException e1) {
					e1.printStackTrace();
					
					if (e1.getCause() != null) {
						e1.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "Invalid price input.", "Coupons Retrieval By Price Failure",
							JOptionPane.ERROR_MESSAGE);
					
					if (tm.getRowCount() > 1) {
						for (int i = tm.getRowCount() - 1; i > 0; i--) {
							tm.removeRow(i);
						}
					}

				} catch (Exception e2) {
					e2.printStackTrace();
					
					if (e2.getCause() != null) {
						e2.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, e2.getMessage(), "Coupons Retrieval By Price Failure",
							JOptionPane.ERROR_MESSAGE);
					
					if (tm.getRowCount() > 1) {
						for (int i = tm.getRowCount() - 1; i > 0; i--) {
							tm.removeRow(i);
						}
					}
				}
			}
		});
		pricePanel.add(showButton);

		CONTENT.add(pricePanel);

		CONTENT_LAYOUT.putConstraint(SpringLayout.NORTH, title, (int) (CONTENT.getHeight() * 0.1), SpringLayout.NORTH,
				CONTENT);
		CONTENT_LAYOUT.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, CONTENT);

		CONTENT_LAYOUT.putConstraint(SpringLayout.NORTH, pricePanel, 10, SpringLayout.SOUTH, title);
		CONTENT_LAYOUT.putConstraint(SpringLayout.HORIZONTAL_CENTER, pricePanel, 0, SpringLayout.HORIZONTAL_CENTER,
				CONTENT);

		CONTENT_LAYOUT.putConstraint(SpringLayout.NORTH, table, 10, SpringLayout.SOUTH, pricePanel);
		CONTENT_LAYOUT.putConstraint(SpringLayout.HORIZONTAL_CENTER, table, 0, SpringLayout.HORIZONTAL_CENTER, CONTENT);

		CONTENT.revalidate();
		CONTENT.repaint();
	}
}
