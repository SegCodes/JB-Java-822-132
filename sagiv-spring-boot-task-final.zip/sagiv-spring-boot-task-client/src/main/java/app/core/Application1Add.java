package app.core;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.springframework.web.client.RestTemplate;

import app.core.beans.Employee;
import app.core.beans.Job;

public class Application1Add {

	public static void main(String[] args) {
		String baseUrl = "http://localhost:8080/api/company";
		RestTemplate rt = new RestTemplate();

		List<Job> jobs = Arrays.asList(new Job(0, "Meet Sam at New York", LocalDate.parse("2022-02-22"), null),
				new Job(0, "Meet Jack at London", LocalDate.parse("2022-03-11"), null));
		Employee e = new Employee(0, "Dana", 7500, jobs);
		
		String path = baseUrl + "/add";
		long id = rt.postForObject(path, e, long.class);
		System.out.println("Added employee with id #" + id + ".");
	}

}
