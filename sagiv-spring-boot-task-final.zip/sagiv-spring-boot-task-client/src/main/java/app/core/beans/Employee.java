package app.core.beans;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString(exclude = "jobs")
@EqualsAndHashCode(of = "id")
public class Employee {

	private long id;
	private String name;
	private double salary;
	private List<Job> jobs;
	
	public void setJobs(List<Job> jobs) {
		if(this.jobs == null) {
			this.jobs = new ArrayList<Job>();
		}
		for(Job job : jobs) {
			job.setEmployee(this);
		}
		this.jobs = jobs;
	}
}
