package app.core.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import app.core.entities.Job;

public interface JobRepository extends JpaRepository<Job, Long> {
	List<Job> findJobsByEndDate(LocalDate endDate);

	List<Job> findJobsByEndDateBetween(LocalDate startDate, LocalDate endDate);
}
