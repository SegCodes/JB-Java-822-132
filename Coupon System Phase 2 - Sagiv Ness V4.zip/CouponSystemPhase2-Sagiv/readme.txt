======= Coupon System Phase 2 By Sagiv Ness =======
How to run:
1. Start the program normally.

2. Perform actions by logging in with the following examples or by seeing the database:
	- Customer: Email = dlevin@mail.com, Password = levin123
	- Company: Email = aaa@mail.com, Password = aaa1
	- Customer: Email = admin@admin.com, Password = admin

3. When finished, logout of the account your'e logged into and close the window. Closing the window will end the program.*

*Note - You cannot close the window when your'e logged in. You must logout to close the program.
===================================================