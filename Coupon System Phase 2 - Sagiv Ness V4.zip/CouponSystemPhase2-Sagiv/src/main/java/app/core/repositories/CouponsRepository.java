package app.core.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import app.core.entities.Coupon;
import app.core.entities.Coupon.Category;

public interface CouponsRepository extends JpaRepository<Coupon, Integer> {
	
	boolean existsByCompanyIdAndTitle(int companyID, String title);
	
	List<Coupon> findByCompanyId(int companyID);
	
	List<Coupon> findByCompanyIdAndCategory(int companyID, Category category);
	
	List<Coupon> findByCompanyIdAndPriceLessThanEqual(int companyID, double maxPrice);
	
	List<Coupon> findByCustomersId(int customerID);
	
	List<Coupon> findByCustomersIdAndCategory(int customerID, Category category);
	
	List<Coupon> findByCustomersIdAndPriceLessThanEqual(int customerID, double maxPrice);
	
	@Query("SELECT co FROM Coupon co JOIN FETCH co.customers WHERE co.endDate <= :date")
	List<Coupon> findExpiredCoupons(LocalDate date);
	
	List<Coupon> findByEndDateLessThanEqual(LocalDate date);
	
}
