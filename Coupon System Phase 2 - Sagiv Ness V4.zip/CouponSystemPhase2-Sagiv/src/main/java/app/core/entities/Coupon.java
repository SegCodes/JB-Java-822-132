package app.core.entities;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString(exclude = { "company", "customers" })
@EqualsAndHashCode(of = "id")
@Table(name = "coupons")
public class Coupon {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	@ManyToOne(cascade = { CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH })
	@JoinColumn(name = "company_id")
	private Company company;
	private Category category;
	private String title;
	private String description;
	private LocalDate startDate;
	private LocalDate endDate;
	private int amount;
	private double price;
	private String imgPath;

	@ManyToMany(mappedBy = "coupons", cascade = {CascadeType.DETACH, CascadeType.MERGE, CascadeType.REFRESH})
	private List<Customer> customers;

	public enum Category {
		FOOD, ELECTRICITY, CLOTHING, CAMPING, VACATION, HOME;
	}

	public Coupon(int id) {
		super();
		this.id = id;
	}

	public Coupon(Category category, String title, String description, LocalDate startDate, LocalDate endDate,
			int amount, double price, String imgPath) {
		super();
		this.category = category;
		this.title = title;
		this.description = description;
		this.startDate = startDate;
		this.endDate = endDate;
		this.amount = amount;
		this.price = price;
		this.imgPath = imgPath;
		this.customers = null;
	}

	public Coupon(int id, Category category, String title, String description, LocalDate startDate, LocalDate endDate,
			int amount, double price, String imgPath) {
		super();
		this.id = id;
		this.category = category;
		this.title = title;
		this.description = description;
		this.startDate = startDate;
		this.endDate = endDate;
		this.amount = amount;
		this.price = price;
		this.imgPath = imgPath;
		this.customers = null;
	}

	public Coupon(Company company, Category category, String title, String description, LocalDate startDate,
			LocalDate endDate, int amount, double price, String imgPath) {
		super();
		this.company = company;
		this.category = category;
		this.title = title;
		this.description = description;
		this.startDate = startDate;
		this.endDate = endDate;
		this.amount = amount;
		this.price = price;
		this.imgPath = imgPath;
		this.customers = null;
	}
	
	public void instantiateCoupons() {
		if (this.customers == null) {
			this.customers = new ArrayList<Customer>();
		}
	}
	
	public void deletePurchaseHistory() {
		for (Customer customer : customers) {
			customer.getCoupons().remove(this);
		}
		this.customers = null;
	}

}
