package app.core.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString(exclude = "coupons")
@EqualsAndHashCode(of = "id")
@Table(name = "companies")
public class Company {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;
	private String email;
	private String password;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "company")
	private List<Coupon> coupons;

	public Company(int id) {
		super();
		this.id = id;
	}
	
	public Company(int id, String email, String password) {
		super();
		this.id = id;
		this.email = email;
		this.password = password;
		this.coupons = null;
	}

	public Company(String name, String email, String password) {
		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.coupons = null;
	}

	private void instantiateCoupons() {
		if (this.coupons == null) {
			this.coupons = new ArrayList<Coupon>();
		}
	}

	public void addCoupon(Coupon coupon) {
		instantiateCoupons();
		this.coupons.add(coupon);
	}

}
