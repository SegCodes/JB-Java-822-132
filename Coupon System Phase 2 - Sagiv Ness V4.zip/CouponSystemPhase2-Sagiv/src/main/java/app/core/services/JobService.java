package app.core.services;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import app.core.entities.Coupon;
import app.core.repositories.CouponsRepository;

@Service
@Transactional
public class JobService {

	// ******************************
	// Attributes
	// ******************************
	@Autowired
	private CouponsRepository couponsRepo;

	// ******************************
	// Methods
	// ******************************
	/**
	 * Deletes all of the expired coupons in the database.
	 */
	public void deleteExpiredCoupons() {
		List<Coupon> expiredCoupons = couponsRepo.findByEndDateLessThanEqual(LocalDate.now());
		for (Coupon coupon : expiredCoupons) {
			coupon.deletePurchaseHistory();
			coupon.getCompany().getCoupons().remove(coupon);
			coupon.setCompany(null);
		}
		couponsRepo.deleteAllInBatch(expiredCoupons);
	}
}
