package app.core.threads;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.concurrent.TimeUnit;

import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import app.core.services.JobService;

@Component
public class Job {
	
	@Autowired
	private JobService service;
	
	@Scheduled(timeUnit = TimeUnit.SECONDS, initialDelay = 5, fixedDelay = 86_400)
	private void deleteExpiredCoupons() {
		System.out.println("\n" + LocalDate.now() + " " + LocalTime.now() + " - Starting Daily Job...");
		System.out.println("====================");
		service.deleteExpiredCoupons();
		System.out.println("====================");
		System.out.println(LocalDate.now() + " " + LocalTime.now() + " - Daily Job finished. Standing by...\n");
	}
	
	@PreDestroy
	private void closeMessage() {
		System.out.println(LocalDate.now() + " " + LocalTime.now() + " - Job Closing...");
	}
}
