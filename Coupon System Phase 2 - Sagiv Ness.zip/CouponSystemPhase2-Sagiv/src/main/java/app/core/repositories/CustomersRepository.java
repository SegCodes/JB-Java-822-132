package app.core.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import app.core.entities.Coupon.Category;
import app.core.entities.Customer;

public interface CustomersRepository extends JpaRepository<Customer, Integer> {
	
	Optional<Customer> findByEmailAndPassword(String email, String password);
	
	boolean existsByEmail(String email);
	
	@Query("SELECT c FROM Customer c JOIN FETCH c.coupons WHERE c.id = :customerID")
	Optional<Customer> findByIdWithCoupons(int customerID);
	
	@Query("SELECT c FROM Customer c JOIN FETCH c.coupons co WHERE c.id = :customerID AND co.category = :category")
	Optional<Customer> findByIdWithCouponsByCategory(int customerID, Category category);
	
	@Query("SELECT c FROM Customer c JOIN FETCH c.coupons co WHERE c.id = :customerID AND co.price <= :maxPrice")
	Optional<Customer> findByIdWithCouponsByPrice(int customerID, double maxPrice);
}
