package app.core.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import app.core.entities.Company;
import app.core.entities.Coupon;
import app.core.entities.Customer;
import app.core.exceptions.ServiceException;

@Service
@Transactional
@Scope("prototype")
public class AdminService extends ClientService {

	@Value("${admin.email}")
	private String adminEmail;

	@Value("${admin.password}")
	private String adminPassword;

	@Override
	public boolean login(String email, String password) {
		if (email.equals(adminEmail) && password.equals(adminPassword)) {
			return true;
		}
		return false;
	}

	public int addCompany(Company company) throws ServiceException {
		try {
			company.setId(0);

			if (company.getName().isBlank() || company.getName() == null) {
				throw new ServiceException("Cannot add a company with an empty name.");

			} else if (companiesRepo.existsByName(company.getName())) {
				throw new ServiceException("Name is already used.");

			} else if (company.getEmail().isBlank() || company.getEmail() == null) {
				throw new ServiceException("Cannot add a company with an empty email.");

			} else if (companiesRepo.existsByEmail(company.getEmail())) {
				throw new ServiceException("Email is already used.");

			} else if (company.getPassword().isBlank() || company.getPassword() == null) {
				throw new ServiceException("Cannot add a company with an empty password.");

			} else {
				company = companiesRepo.save(company);
				return company.getId();
			}
		} catch (Exception e) {
			throw new ServiceException("Company addition failed - " + e.getMessage(), e);
		}
	}

	public void updateCompany(Company company) throws ServiceException {
		try {
			Company ogCompany = getOneCompany(company.getId());

			if (companiesRepo.existsByEmail(company.getEmail()) && !ogCompany.getEmail().equals(company.getEmail())) {
				throw new ServiceException("Email is already used.");

			} else if (!company.getEmail().isBlank() && !ogCompany.getEmail().equals(company.getEmail())) {
				ogCompany.setEmail(company.getEmail());
			}

			if (!company.getPassword().isBlank() && !ogCompany.getPassword().equals(company.getPassword())) {
				ogCompany.setPassword(company.getPassword());
			}
		} catch (Exception e) {
			throw new ServiceException("Company update failed - " + e.getMessage(), e);
		}
	}

	public void deleteCompany(int companyID) throws ServiceException {
		try {
			Company company = getOneCompany(companyID);
			List<Coupon> coupons = company.getCoupons();
			coupons.forEach(Coupon::deletePurchaseHistory);
			companiesRepo.delete(company);
		} catch (Exception e) {
			throw new ServiceException("Company deletion failed - " + e.getMessage(), e);
		}
	}

	public List<Company> getAllCompanies() throws ServiceException {
		try {
			List<Company> companies = companiesRepo.findAll();
			if (companies.isEmpty()) {
				throw new ServiceException("There are no companies.");
			}
			return companies;
		} catch (Exception e) {
			throw new ServiceException("Companies retrieval failed - " + e.getMessage(), e);
		}
	}

	public Company getOneCompany(int companyID) throws ServiceException {
		try {
			return companiesRepo.findById(companyID)
					.orElseThrow(() -> new ServiceException("No company with id #" + companyID + " was found."));
		} catch (Exception e) {
			throw new ServiceException("Company retrieval failed - " + e.getMessage(), e);
		}
	}

	public int addCustomer(Customer customer) throws ServiceException {
		try {
			customer.setId(0);

			if (customer.getFirstName().isBlank() || customer.getFirstName() == null) {
				throw new ServiceException("Cannot add a customer with an empty first name.");

			} else if (customer.getLastName().isBlank() || customer.getLastName() == null) {
				throw new ServiceException("Cannot add a customer with an empty last name.");

			} else if (customer.getEmail().isBlank() || customer.getEmail() == null) {
				throw new ServiceException("Cannot add a customer with an empty email.");

			} else if (companiesRepo.existsByEmail(customer.getEmail())) {
				throw new ServiceException("Email is already used.");

			} else if (customer.getPassword().isBlank() || customer.getPassword() == null) {
				throw new ServiceException("Cannot add a customer with an empty password.");

			} else {
				customer = customersRepo.save(customer);
				return customer.getId();
			}
		} catch (Exception e) {
			throw new ServiceException("Customer addition failed - " + e.getMessage(), e);
		}
	}

	public void updateCustomer(Customer customer) throws ServiceException {
		try {
			Customer ogCustomer = getOneCustomer(customer.getId());
			if (!customer.getFirstName().isBlank() && !ogCustomer.getFirstName().equals(customer.getFirstName())) {
				ogCustomer.setFirstName(customer.getFirstName());
			}

			if (!customer.getLastName().isBlank() && !ogCustomer.getLastName().equals(customer.getLastName())) {
				ogCustomer.setLastName(customer.getLastName());
			}

			if (customersRepo.existsByEmail(customer.getEmail())
					&& !ogCustomer.getEmail().equals(customer.getEmail())) {
				throw new ServiceException("Email is already used.");

			} else if (!customer.getEmail().isBlank() && !ogCustomer.getEmail().equals(customer.getEmail())) {
				ogCustomer.setEmail(customer.getEmail());
			}

			if (!customer.getPassword().isBlank() && !ogCustomer.getPassword().equals(customer.getPassword())) {
				ogCustomer.setPassword(customer.getPassword());
			}
		} catch (Exception e) {
			throw new ServiceException("Customer update failed - " + e.getMessage(), e);
		}
	}

	public void deleteCustomer(int customerID) throws ServiceException {
		try {
			Customer customer = getOneCustomer(customerID);
			List<Coupon> coupons = customer.getCoupons();
			coupons.forEach(Coupon::deletePurchaseHistory);
			customersRepo.delete(customer);
		} catch (Exception e) {
			throw new ServiceException("Customer deletion failed - " + e.getMessage(), e);
		}
	}

	public List<Customer> getAllCustomers() throws ServiceException {
		try {
			List<Customer> customers = customersRepo.findAll();
			if (customers.isEmpty()) {
				throw new ServiceException("There are no customers.");
			}
			return customers;
		} catch (Exception e) {
			throw new ServiceException("Customers retrieval failed - " + e.getMessage(), e);
		}
	}

	public Customer getOneCustomer(int customerID) throws ServiceException {
		try {
			return customersRepo.findById(customerID)
					.orElseThrow(() -> new ServiceException("No customer with id #" + customerID + " was found."));
		} catch (Exception e) {
			throw new ServiceException("Customer retrieval failed - " + e.getMessage(), e);
		}
	}
}
