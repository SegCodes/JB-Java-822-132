package app.core.services;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import app.core.entities.Coupon;
import app.core.entities.Coupon.Category;
import app.core.entities.Customer;
import app.core.exceptions.ServiceException;

@Service
@Transactional
@Scope("prototype")
public class CustomerService extends ClientService {

	private int customerID;

	public int getID() {
		return this.customerID;
	}

	@Override
	public boolean login(String email, String password) {
		Optional<Customer> opt = customersRepo.findByEmailAndPassword(email, password);
		if (opt.isPresent()) {
			this.customerID = opt.get().getId();
			return true;
		} else {
			return false;
		}
	}

	public void purchaseCoupon(Coupon coupon) throws ServiceException {
		try {
			Coupon ogCoupon = couponsRepo.findById(coupon.getId())
					.orElseThrow(() -> new ServiceException("No coupon with id #" + coupon.getId() + " was found."));
			
			Customer customer = getInfo();
			if(customer.getCoupons().contains(ogCoupon)) {
				throw new ServiceException("You already bought this coupon.");
			
			} else if(ogCoupon.getAmount() == 0) {
				throw new ServiceException("Coupon out of stock.");
			
			} else if(ogCoupon.getEndDate().isBefore(LocalDate.now())) {
				throw new ServiceException("Cannot buy expired coupon.");
			
			} else {
				ogCoupon.setAmount(ogCoupon.getAmount() - 1);
				customer.purchaseCoupon(ogCoupon);
			}
		} catch (Exception e) {
			throw new ServiceException("Coupon purchase failed - " + e.getMessage(), e);
		}
	}

	public List<Coupon> getCoupons() throws ServiceException {
		try {
			Customer customer = customersRepo.findByIdWithCoupons(customerID)
					.orElseThrow(() -> new ServiceException("You don't have any coupons."));
			List<Coupon> coupons = customer.getCoupons();
			if (coupons.isEmpty()) {
				throw new ServiceException("You don't have any coupons.");
			}
			return coupons;
		} catch (Exception e) {
			throw new ServiceException("Customer's coupons retrieval failed - " + e.getMessage(), e);
		}
	}

	public List<Coupon> getCoupons(Category category) throws ServiceException {
		try {
			Customer customer = customersRepo.findByIdWithCouponsByCategory(customerID, category)
					.orElseThrow(() -> new ServiceException("You don't have any coupons in category: " + category + "."));
			List<Coupon> coupons = customer.getCoupons();
			if (coupons.isEmpty()) {
				throw new ServiceException("You don't have any coupons in category: " + category + ".");
			}
			return coupons;
		} catch (Exception e) {
			throw new ServiceException("Customer's coupons retrieval by category failed - " + e.getMessage(), e);
		}
	}

	public List<Coupon> getCoupons(double maxPrice) throws ServiceException {
		try {
			Customer customer = customersRepo.findByIdWithCouponsByPrice(customerID, maxPrice)
					.orElseThrow(() -> new ServiceException("You don't have coupons under price: " + maxPrice + "."));
			List<Coupon> coupons = customer.getCoupons();
			if (coupons.isEmpty()) {
				throw new ServiceException("You don't have any coupons under price: " + maxPrice + ".");
			}
			return coupons;
		} catch (Exception e) {
			throw new ServiceException("Customer's coupons retrieval by price failed - " + e.getMessage(), e);
		}
	}

	public Customer getInfo() throws ServiceException {
		try {
			return customersRepo.findById(customerID)
					.orElseThrow(() -> new ServiceException("No customer with id #" + customerID + " was found."));
		} catch (Exception e) {
			throw new ServiceException("Customer info retrieval failed - " + e.getMessage(), e);
		}
	}
}
