package task;

import java.util.Arrays;

public class FlowControlTask {

	public static void main(String[] args) {
		// Section 1 start
		int[] nums1 = new int[15];
		int[] nums2 = new int[15];
		
		for(int i = 0; i < nums1.length; i++) {
			nums1[i] = (int)(Math.random()*10);
			nums2[i] = (int)(Math.random()*10);
		}
		// Section 1 end
		
		// Section 2 start
		System.out.println("Nums1: " + Arrays.toString(nums1));
		System.out.println("Nums2: " + Arrays.toString(nums2));
		// Section 2 end
		
		// Section 3 start
		int max = 0;
		for (int i = 0; i < nums1.length - 2; i++) {
			int n = nums1[i] * 100 + nums1[i + 1] * 10 + nums1[i + 2];
			if (max < n) {
				max = n;
			}
		}
		System.out.println("Max in nums1: " + max);
		// Section 3 end
		
		// Section 4 start
		
		int[] distinct = new int[15];
		for (int i = 0; i < distinct.length; i++) {
			distinct[i] = -1;
		}
		
		int pos = 0;
		
		lbl1: for(int i = 0; i < nums1.length; i++) {
			for(int j = 0; j < nums2.length; j++) {
				if(nums1[i] == nums2[j]) {
					continue lbl1;
				}
			}
			distinct[pos] = nums1[i];
			pos++;
		}
		
		lbl2: for(int i = 0; i < nums2.length; i++) {
			for(int j = 0; j < nums1.length; j++) {
				if(nums2[i] == nums1[j]) {
					continue lbl2;
				}
			}
			distinct[pos] = nums2[i];
			pos++;
		}
		//System.out.println("distinct: " + Arrays.toString(distinct));
		
		int[] temp = new int[distinct.length];
		pos = 0;
		
	lbl3: for(int i = 0; i < distinct.length; i++){
			for(int j = 0; j < pos; j++) {
				if(temp[j] == distinct[i]) {
					continue lbl3;
				}
			}
			temp[pos] = distinct[i];
			pos++;
		}
		//System.out.println("temp 1: " + Arrays.toString(temp));
		
		for(int i = 0; i < temp.length - 1; i++) {
			if(i != 0 && temp[i] == 0 && temp[i - 1] == -1) {
				temp[i] = -1;
			}
		}
		temp[temp.length - 1] = -1;
		//System.out.println("temp 2: " + Arrays.toString(temp));
		
		System.arraycopy(temp, 0, distinct, 0, distinct.length);
		// Section 4 end
		
		// Section 5 start
		System.out.println("Distinct final: " + Arrays.toString(distinct));
		// Section 5 end
		
		// Section 6 start
		int n = 0;
		for(int i = distinct.length - 1; i >= 0 ; i--) {
			if(distinct[i] == -1) {
				continue;
			}
			n += distinct[i];
			n *= 10;
		}
		n /= 10;
		System.out.println("Number from distinct: " + n);
		// Section 6 end
	}

}
