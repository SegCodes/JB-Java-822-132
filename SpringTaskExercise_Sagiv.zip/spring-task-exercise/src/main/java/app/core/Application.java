package app.core;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import app.core.entities.Customer;
import app.core.entities.Order;
import app.core.services.CustomerService;
import app.core.services.OrderService;

@SpringBootApplication
public class Application {

	public static void main(String[] args) {
		ApplicationContext ctx = SpringApplication.run(Application.class, args);
		System.out.println("=====START=====");
		try {
			CustomerService cService = ctx.getBean(CustomerService.class);
			OrderService oService = ctx.getBean(OrderService.class);
			
			System.out.println();
			List<Order> l1 = Arrays.asList(new Order("Milk", LocalDate.parse("2021-11-20")),
					new Order("Chicken", LocalDate.parse("2022-03-03")),
					new Order("Chocolate", LocalDate.parse("2022-05-12")));
			
			System.out.println();
			cService.addCustomer(new Customer(0, "Shmuel", "Netanya", "Moshe Hatzadik", l1));
			
			System.out.println();
			List<Order> l2 = Arrays.asList(new Order("PC", LocalDate.now()),
					new Order("PS", LocalDate.parse("2021-01-01")), new Order("XBOX", LocalDate.parse("2021-12-08")));
			
			System.out.println();
			cService.addCustomer(new Customer(0, "Hanna", "Jerusalem", "Plugat Hatankim", l2));

			System.out.println();
			List<Order> l3 = Arrays.asList(new Order("Pistol", LocalDate.parse("2021-12-08")),
					new Order("Uzi", LocalDate.now()), new Order("Dagger", LocalDate.parse("2021-12-08")));
			
			System.out.println();
			cService.addCustomer(new Customer(0, "Jason", "Los Angeles", "Trump Avn.", l3));
			
			System.out.println();
			Customer c = cService.getCustomer(2);
			System.out.println(c + "\n");
			
			List<Customer> customers1 = cService.getAllCustomers();
			System.out.println(customers1 + "\n");
			
			List<Customer> customers2 = cService.getAllByCity("Netanya");
			System.out.println(customers2 + "\n");
			
			List<Order> orders1 = oService.getAllOrders();
			System.out.println(orders1 + "\n");
			
			List<Order> orders2 = oService.getLateOrders();
			System.out.println(orders2 + "\n");
			
			List<Order> orders3 = oService.getNearingOrders(5);
			System.out.println(orders3 + "\n");
		} catch (Exception e) {
			System.err.println("ERROR: " + e.getMessage());
		}
		System.out.println("=====END=====");
	}

}
