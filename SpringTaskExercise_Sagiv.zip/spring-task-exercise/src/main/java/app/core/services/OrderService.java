package app.core.services;

import java.time.LocalDate;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import app.core.entities.Order;
import app.core.repositories.OrdersRepository;

@Service
@Transactional
public class OrderService {
	
	@Autowired
	private OrdersRepository ordersRepo;
	
	public List<Order> getAllOrders() throws Exception {
		List<Order> orders = ordersRepo.findAll();
		if(orders.isEmpty()) {
			throw new Exception("There are no orders.");
		} else {
			return orders;
		}
	}
	
	public List<Order> getLateOrders() throws Exception {
		List<Order> orders = ordersRepo.findAllBySupplyDateLessThanEqual(LocalDate.now());
		if(orders.isEmpty()) {
			throw new Exception("There are no late orders");
		} else {
			return orders;
		}
	}
	
	public List<Order> getNearingOrders(int days) throws Exception {
		List<Order> orders = ordersRepo.findAllBySupplyDate(LocalDate.now().plusDays(days));
		if(orders.isEmpty()) {
			throw new Exception("There are no orders near " + LocalDate.now().plusDays(days));
		} else {
			return orders;
		}
	}
}
