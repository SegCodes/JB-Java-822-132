package app.core.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import app.core.entities.Customer;
import app.core.repositories.CustomersRepository;
import app.core.repositories.OrdersRepository;

@Service
@Transactional
public class CustomerService {
	
	@Autowired
	private CustomersRepository customersRepo;
	@Autowired
	private OrdersRepository ordersRepo;
	
	public int addCustomer(Customer customer) throws Exception {
		Optional<Customer> opt = customersRepo.findById(customer.getId());
		if(opt.isPresent()) {
			throw new Exception("A customer with the id #" + customer.getId() + " already exists.");
		} else {
			if(customer.getOrders() != null && customer.getOrders().isEmpty()) {
				ordersRepo.saveAll(customer.getOrders());
			}
			customer = customersRepo.save(customer);
			return customer.getId();
		}
	}
	
	public Customer getCustomer(int customerID) throws Exception {
		Optional<Customer> opt = customersRepo.findById(customerID);
		if(opt.isEmpty()) {
			throw new Exception("No customer found with id:" + customerID);
		} else {
			return opt.get();
		}
	}
	
	public List<Customer> getAllCustomers() throws Exception {
		List<Customer> customers = customersRepo.findAll();
		if(customers.isEmpty()) {
			throw new Exception("There are no customers");
		} else {
			return customers;
		}
	}
	
	public List<Customer> getAllByCity(String city) throws Exception {
		List<Customer> customers = customersRepo.findAllByCity(city);
		if(customers.isEmpty()) {
			throw new Exception("There are no customers in city: " + city);
		} else {
			return customers;
		}
	}
}
