package app.core.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import app.core.entities.Customer;

public interface CustomersRepository extends JpaRepository<Customer, Integer> {
	
	List<Customer> findAllByCity(String city);
}
