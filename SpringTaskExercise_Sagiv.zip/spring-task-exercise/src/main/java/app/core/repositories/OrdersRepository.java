package app.core.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import app.core.entities.Order;

public interface OrdersRepository extends JpaRepository<Order, Integer> {
	
	List<Order> findAllBySupplyDateLessThanEqual(LocalDate date);
	
	List<Order> findAllBySupplyDate(LocalDate date);
}
