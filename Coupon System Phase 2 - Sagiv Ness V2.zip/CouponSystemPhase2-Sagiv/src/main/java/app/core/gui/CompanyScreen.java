package app.core.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import app.core.entities.Company;
import app.core.entities.Coupon;
import app.core.entities.Coupon.Category;
import app.core.exceptions.ServiceException;
import app.core.services.CompanyService;

public class CompanyScreen {

	private CompanyService service;
	private JFrame frame;
	private JPanel content;
	private SpringLayout contentLayout;
	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

	public CompanyScreen(CompanyService companyService) {
		frame = new JFrame("Coupon System - Company");
		contentLayout = new SpringLayout();
		content = new JPanel(contentLayout);
		service = companyService;
		startCompanyScreen();
	}

	private void startCompanyScreen() {
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.7), (int) (screenSize.getHeight() / 1.4)));
		JMenuBar menuBar = new JMenuBar();

		JMenu accountMenu = new JMenu("Account");

		JMenuItem getInfo = new JMenuItem("Get Info");
		getInfo.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setGetInfoComponents();
			}
		});
		accountMenu.add(getInfo);

		JMenuItem logout = new JMenuItem("Logout");
		logout.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				LoginScreen.startApplication(null);
			}
		});
		accountMenu.add(logout);

		menuBar.add(accountMenu);

		JMenu modCouponMenu = new JMenu("Modify Coupon");

		JMenuItem addCoupon = new JMenuItem("Add");
		addCoupon.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setAddCouponComponents();
			}
		});
		modCouponMenu.add(addCoupon);

		JMenuItem updateCoupon = new JMenuItem("Update");
		updateCoupon.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setUpdateCouponComponents();
			}
		});
		modCouponMenu.add(updateCoupon);

		JMenuItem deleteCoupon = new JMenuItem("Delete");
		deleteCoupon.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setDeleteCouponComponents();
			}
		});
		modCouponMenu.add(deleteCoupon);

		menuBar.add(modCouponMenu);

		JMenu getCouponsMenu = new JMenu("Get Coupons");

		JMenuItem getAllCoupons = new JMenuItem("All");
		getAllCoupons.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setGetAllCouponsComponents();
			}
		});
		getCouponsMenu.add(getAllCoupons);

		JMenuItem getCouponsByCategory = new JMenuItem("By Category");
		getCouponsByCategory.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setGetCouponsByCategoryComponents();
			}
		});
		getCouponsMenu.add(getCouponsByCategory);

		JMenuItem getCouponsByPrice = new JMenuItem("By Price");
		getCouponsByPrice.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setGetCouponsByPriceComponents();
			}
		});
		getCouponsMenu.add(getCouponsByPrice);

		menuBar.add(getCouponsMenu);

		frame.setJMenuBar(menuBar);
		frame.setContentPane(content);
		frame.setResizable(false);
		frame.pack();
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
	}

	private void setGetInfoComponents() {
		JLabel title = new JLabel("Company Info");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		JPanel fieldsPanel = new JPanel();
		fieldsPanel.setLayout(new GridLayout(5, 1, 3, 3));

		JPanel idPanel = new JPanel();
		idPanel.setBorder(BorderFactory.createTitledBorder("ID"));

		JTextField idField = new JTextField();
		idField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		idField.setFocusable(false);
		idPanel.add(idField);

		fieldsPanel.add(idPanel);

		JPanel fNamePanel = new JPanel();
		fNamePanel.setBorder(BorderFactory.createTitledBorder("First Name"));

		JTextField nameField = new JTextField();
		nameField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		nameField.setFocusable(false);
		fNamePanel.add(nameField);

		fieldsPanel.add(fNamePanel);

		JPanel emailPanel = new JPanel();
		emailPanel.setBorder(BorderFactory.createTitledBorder("Email"));

		JTextField emailField = new JTextField();
		emailField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		emailField.setFocusable(false);
		emailPanel.add(emailField);

		fieldsPanel.add(emailPanel);

		JPanel passwordPanel = new JPanel();
		passwordPanel.setBorder(BorderFactory.createTitledBorder("Password"));

		JTextField passwordField = new JTextField();
		passwordField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		passwordField.setFocusable(false);
		passwordPanel.add(passwordField);

		fieldsPanel.add(passwordPanel);

		try {
			Company company = service.getInfo();
			idField.setText(String.valueOf(company.getId()));
			nameField.setText(company.getName());
			emailField.setText(company.getEmail());
			passwordField.setText(company.getPassword());

		} catch (ServiceException e) {
			e.printStackTrace();
			if (e.getCause() != null) {
				e.getCause().printStackTrace();
			}
			JOptionPane.showMessageDialog(null, e.getMessage(), "Company Info Retrieval Failure",
					JOptionPane.ERROR_MESSAGE);

			idField.setText(null);
			nameField.setText(null);
			emailField.setText(null);
			passwordField.setText(null);
		}

		content.add(fieldsPanel);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, fieldsPanel, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, fieldsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		content.revalidate();
		content.repaint();
	}

	private void setAddCouponComponents() {
		JLabel title = new JLabel("Add Coupon");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		JPanel fieldsPanel = new JPanel(new GridLayout(4, 2, 3, 3));

		JPanel categoriesPanel = new JPanel();
		categoriesPanel.setBorder(new TitledBorder("Categories"));

		JComboBox<Category> categoriesList = new JComboBox<Category>(Category.values());
		categoriesPanel.add(categoriesList);
		fieldsPanel.add(categoriesPanel);

		JPanel titlePanel = new JPanel();
		titlePanel.setBorder(new TitledBorder("Title"));

		JTextField titleField = new JTextField();
		titleField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		titlePanel.add(titleField);
		fieldsPanel.add(titlePanel);

		JPanel descriptionPanel = new JPanel();
		descriptionPanel.setBorder(new TitledBorder("Description"));

		JTextField descriptionField = new JTextField();
		descriptionField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		descriptionPanel.add(descriptionField);
		fieldsPanel.add(descriptionPanel);

		JPanel startDatePanel = new JPanel();
		startDatePanel.setBorder(new TitledBorder("Start Date"));

		JFormattedTextField startDateField = new JFormattedTextField(DateTimeFormatter.ISO_LOCAL_DATE.toFormat());
		startDateField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		startDateField.setToolTipText("Enter start date in the following foramt: YYYY-MM-DD.");
		startDatePanel.add(startDateField);
		fieldsPanel.add(startDatePanel);

		JPanel endDatePanel = new JPanel();
		endDatePanel.setBorder(new TitledBorder("Expiration Date"));

		JTextField endDateField = new JFormattedTextField(DateTimeFormatter.ISO_LOCAL_DATE.toFormat());
		endDateField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		endDateField.setToolTipText("Enter start date in the following foramt: YYYY-MM-DD.");
		endDatePanel.add(endDateField);
		fieldsPanel.add(endDatePanel);

		JPanel amountPanel = new JPanel();
		amountPanel.setBorder(new TitledBorder("Amount"));

		JTextField amountField = new JTextField();
		amountField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		amountPanel.add(amountField);
		fieldsPanel.add(amountPanel);

		JPanel pricePanel = new JPanel();
		pricePanel.setBorder(new TitledBorder("Price"));

		JTextField priceField = new JTextField();
		priceField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		pricePanel.add(priceField);
		fieldsPanel.add(pricePanel);

		JPanel imgPathPanel = new JPanel();
		imgPathPanel.setBorder(new TitledBorder("Image Path"));

		JTextField imgPathField = new JTextField();
		imgPathField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		imgPathPanel.add(imgPathField);
		fieldsPanel.add(imgPathPanel);

		content.add(fieldsPanel);

		JPanel buttonsPanel = new JPanel(new GridLayout(1, 2, 5, 5));

		JButton addButton = new JButton("Add");
		addButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					Category category = (Category) categoriesList.getSelectedItem();
					String couponTitle = titleField.getText();
					String description = descriptionField.getText();
					LocalDate startDate = LocalDate.parse(startDateField.getText());
					LocalDate endDate = LocalDate.parse(endDateField.getText());
					int amount = Integer.parseInt(amountField.getText());
					double price = Double.parseDouble(priceField.getText());
					String imgPath = imgPathField.getText();

					int id = service.addCoupon(
							new Coupon(category, couponTitle, description, startDate, endDate, amount, price, imgPath));

					JOptionPane.showMessageDialog(null,
							"Added coupon with id #" + id + ". Go to Get Coupons to see it.", "Coupon Addition Success",
							JOptionPane.INFORMATION_MESSAGE);
					
					categoriesList.setSelectedIndex(0);
					titleField.setText(null);
					descriptionField.setText(null);
					startDateField.setText(null);
					endDateField.setText(null);
					amountField.setText(null);
					priceField.setText(null);
					imgPathField.setText(null);
					
				} catch (DateTimeParseException e1) {
					e1.printStackTrace();
					if (e1.getCause() != null) {
						e1.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null,
							"Invalid start/end date entered. Please enter them in the following format: YYYY-MM-DD.",
							"Coupon Addition Failure", JOptionPane.ERROR_MESSAGE);

				} catch (NumberFormatException e2) {
					e2.printStackTrace();
					if (e2.getCause() != null) {
						e2.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "Invalid amount/price entered.", "Coupon Addition Failure",
							JOptionPane.ERROR_MESSAGE);

				} catch (Exception e3) {
					e3.printStackTrace();
					if (e3.getCause() != null) {
						e3.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, e3.getMessage(), "Coupon Addition Failure",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		buttonsPanel.add(addButton);

		JButton clearButton = new JButton("Clear");
		clearButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				categoriesList.setSelectedIndex(0);
				titleField.setText(null);
				descriptionField.setText(null);
				startDateField.setText(null);
				endDateField.setText(null);
				amountField.setText(null);
				priceField.setText(null);
				imgPathField.setText(null);
			}
		});
		buttonsPanel.add(clearButton);

		content.add(buttonsPanel);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, fieldsPanel, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, fieldsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		contentLayout.putConstraint(SpringLayout.NORTH, buttonsPanel, 10, SpringLayout.SOUTH, fieldsPanel);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, buttonsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		content.revalidate();
		content.repaint();
	}

	private void setUpdateCouponComponents() {
		JLabel title = new JLabel("Update Coupon");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		JPanel fieldsPanel = new JPanel(new GridLayout(4, 2, 3, 3));

		JPanel idPanel = new JPanel();
		idPanel.setBorder(new TitledBorder("ID"));

		JTextField idField = new JTextField();
		idField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		idPanel.add(idField);
		content.add(idPanel);

		JPanel categoriesPanel = new JPanel();
		categoriesPanel.setBorder(new TitledBorder("Categories"));

		JComboBox<Category> categoriesList = new JComboBox<Category>(Category.values());
		categoriesPanel.add(categoriesList);
		fieldsPanel.add(categoriesPanel);

		JPanel titlePanel = new JPanel();
		titlePanel.setBorder(new TitledBorder("Title"));

		JTextField titleField = new JTextField();
		titleField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		titlePanel.add(titleField);
		fieldsPanel.add(titlePanel);

		JPanel descriptionPanel = new JPanel();
		descriptionPanel.setBorder(new TitledBorder("Description"));

		JTextField descriptionField = new JTextField();
		descriptionField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		descriptionPanel.add(descriptionField);
		fieldsPanel.add(descriptionPanel);

		JPanel startDatePanel = new JPanel();
		startDatePanel.setBorder(new TitledBorder("Start Date"));

		JFormattedTextField startDateField = new JFormattedTextField(DateTimeFormatter.ISO_LOCAL_DATE.toFormat());
		startDateField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		startDateField.setToolTipText("Enter start date in the following foramt: YYYY-MM-DD.");
		startDatePanel.add(startDateField);
		fieldsPanel.add(startDatePanel);

		JPanel endDatePanel = new JPanel();
		endDatePanel.setBorder(new TitledBorder("Expiration Date"));

		JTextField endDateField = new JFormattedTextField(DateTimeFormatter.ISO_LOCAL_DATE.toFormat());
		endDateField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		endDateField.setToolTipText("Enter start date in the following foramt: YYYY-MM-DD.");
		endDatePanel.add(endDateField);
		fieldsPanel.add(endDatePanel);

		JPanel amountPanel = new JPanel();
		amountPanel.setBorder(new TitledBorder("Amount"));

		JTextField amountField = new JTextField();
		amountField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		amountPanel.add(amountField);
		fieldsPanel.add(amountPanel);

		JPanel pricePanel = new JPanel();
		pricePanel.setBorder(new TitledBorder("Price"));

		JTextField priceField = new JTextField();
		priceField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		pricePanel.add(priceField);
		fieldsPanel.add(pricePanel);

		JPanel imgPathPanel = new JPanel();
		imgPathPanel.setBorder(new TitledBorder("Image Path"));

		JTextField imgPathField = new JTextField();
		imgPathField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		imgPathPanel.add(imgPathField);
		fieldsPanel.add(imgPathPanel);

		content.add(fieldsPanel);

		JPanel buttonsPanel = new JPanel(new GridLayout(1, 2, 5, 5));

		JButton updateButton = new JButton("Update");
		updateButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if (idField.getText().isBlank()) {
						throw new Exception("Cannot update a coupon withoud an id.");

					}

					int id = Integer.parseInt(idField.getText());
					Category category = (Category) categoriesList.getSelectedItem();
					String couponTitle = titleField.getText();
					String description = descriptionField.getText();

					LocalDate startDate = null;
					if (startDateField.getText() != null && !startDateField.getText().isBlank()) {
						startDate = LocalDate.parse(startDateField.getText());
					}

					LocalDate endDate = null;
					if (endDateField.getText() != null && !endDateField.getText().isBlank()) {
						endDate = LocalDate.parse(endDateField.getText());
					}

					int amount;
					if (amountField.getText() != null && !amountField.getText().isBlank()) {
						amount = Integer.parseInt(amountField.getText());
					} else {
						amount = -1;
					}

					double price;
					if (priceField.getText() != null && !priceField.getText().isBlank()) {
						price = Double.parseDouble(priceField.getText());
					} else {
						price = -1;
					}
					
					String imgPath = imgPathField.getText();

					service.updateCoupon(new Coupon(id, category, couponTitle, description, startDate, endDate, amount,
							price, imgPath));

					JOptionPane.showMessageDialog(null,
							"Updated coupon with id #" + id + ". Go to Get Coupons to see it.", "Coupon Update Success",
							JOptionPane.INFORMATION_MESSAGE);

				} catch (DateTimeParseException e1) {
					e1.printStackTrace();
					if (e1.getCause() != null) {
						e1.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null,
							"Invalid start/end date entered. Please enter them in the following format: YYYY-MM-DD.",
							"Coupon Update Failure", JOptionPane.ERROR_MESSAGE);

				} catch (NumberFormatException e2) {
					e2.printStackTrace();
					if (e2.getCause() != null) {
						e2.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "Invalid id/amount/price entered.", "Coupon Update Failure",
							JOptionPane.ERROR_MESSAGE);

				} catch (Exception e3) {
					e3.printStackTrace();
					if (e3.getCause() != null) {
						e3.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, e3.getMessage(), "Coupon Update Failure",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		buttonsPanel.add(updateButton);

		JButton clearButton = new JButton("Clear");
		clearButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				idField.setText(null);
				categoriesList.setSelectedIndex(0);
				titleField.setText(null);
				descriptionField.setText(null);
				startDateField.setText(null);
				endDateField.setText(null);
				amountField.setText(null);
				priceField.setText(null);
				imgPathField.setText(null);
			}
		});
		buttonsPanel.add(clearButton);

		content.add(buttonsPanel);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, idPanel, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, idPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		contentLayout.putConstraint(SpringLayout.NORTH, fieldsPanel, 5, SpringLayout.SOUTH, idPanel);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, fieldsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		contentLayout.putConstraint(SpringLayout.NORTH, buttonsPanel, 10, SpringLayout.SOUTH, fieldsPanel);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, buttonsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		content.revalidate();
		content.repaint();
	}

	private void setDeleteCouponComponents() {
		JLabel title = new JLabel("Delete Coupon");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		JPanel fieldPanel = new JPanel();
		fieldPanel.setBorder(BorderFactory.createTitledBorder("ID"));

		JTextField idField = new JTextField();
		idField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		fieldPanel.add(idField);

		content.add(fieldPanel);

		JPanel buttonsPanel = new JPanel(new GridLayout(1, 2, 5, 5));

		JButton deleteButton = new JButton("Delete");
		deleteButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if (idField.getText().isBlank()) {
						throw new Exception("Cannot delete a company without id.");
					}
					int id = Integer.parseInt(idField.getText());

					service.deleteCoupon(id);
					JOptionPane.showMessageDialog(null, "Deleted coupon with id #" + id + ".",
							"Company Deletion Success", JOptionPane.INFORMATION_MESSAGE);

				} catch (NumberFormatException e1) {
					e1.printStackTrace();
					if (e1.getCause() != null) {
						e1.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "Invalid id Input.", "Coupon Deletion Failure",
							JOptionPane.ERROR_MESSAGE);

				} catch (Exception e2) {
					e2.printStackTrace();
					if (e2.getCause() != null) {
						e2.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, e2.getMessage(), "Coupon Deletion Failure",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		buttonsPanel.add(deleteButton);

		JButton clearButton = new JButton("Clear");
		clearButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				idField.setText(null);
			}
		});
		buttonsPanel.add(clearButton);

		content.add(buttonsPanel);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, fieldPanel, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, fieldPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		contentLayout.putConstraint(SpringLayout.NORTH, buttonsPanel, 10, SpringLayout.SOUTH, fieldPanel);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, buttonsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		content.revalidate();
		content.repaint();
	}

	private void setGetAllCouponsComponents() {
		JLabel title = new JLabel("All Coupons");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		String[] cols = { "ID", "Company ID", "Category", "Title", "Description", "Start Date", "Expiration Date",
				"Amount", "Price", "Image Path" };
		DefaultTableModel tm = new DefaultTableModel(cols, 0);
		tm.addRow(cols);
		JTable table = new JTable(tm) {

			@Override
			public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
				Component component = super.prepareRenderer(renderer, row, column);
				int rendererWidth = component.getPreferredSize().width;
				TableColumn tableColumn = getColumnModel().getColumn(column);
				tableColumn.setPreferredWidth(
						Math.max(rendererWidth + getIntercellSpacing().width, tableColumn.getPreferredWidth()));
				return component;
			}
		};
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setBorder(new LineBorder(Color.black));
		DefaultTableCellRenderer cellRender = new DefaultTableCellRenderer();
		cellRender.setHorizontalAlignment(SwingConstants.CENTER);

		for (int i = 0; i < table.getColumnCount(); i++) {
			table.getColumnModel().getColumn(i).setCellRenderer(cellRender);
		}

		try {
			List<Coupon> coupons = service.getCoupons();
			for (int i = 0; i < coupons.size(); i++) {
				int id = coupons.get(i).getId();
				int companyID = coupons.get(i).getCompany().getId();
				Category category = coupons.get(i).getCategory();
				String couponTitle = coupons.get(i).getTitle();
				String description = coupons.get(i).getDescription();
				LocalDate startDate = coupons.get(i).getStartDate();
				LocalDate endDate = coupons.get(i).getEndDate();
				int amount = coupons.get(i).getAmount();
				double price = coupons.get(i).getPrice();
				String imgPath = coupons.get(i).getImgPath();
				Object[] vals = { id, companyID, category, couponTitle, description, startDate, endDate, amount, price,
						imgPath };
				tm.addRow(vals);
			}
		} catch (ServiceException e) {
			e.printStackTrace();
			if (e.getCause() != null) {
				e.getCause().printStackTrace();
			}
			JOptionPane.showMessageDialog(null, e.getMessage(), "Coupons Retrieval Failure", JOptionPane.ERROR_MESSAGE);
		}
		content.add(table);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, table, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, table, 0, SpringLayout.HORIZONTAL_CENTER, content);

		content.revalidate();
		content.repaint();
	}

	private void setGetCouponsByCategoryComponents() {
		JLabel title = new JLabel("All Coupons");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		JPanel categoriesPanel = new JPanel();
		categoriesPanel.setBorder(new TitledBorder("Categories"));

		JComboBox<Category> categoriesList = new JComboBox<>(Category.values());
		categoriesPanel.add(categoriesList);

		String[] cols = { "ID", "Company ID", "Category", "Title", "Description", "Start Date", "Expiration Date",
				"Amount", "Price", "Image Path" };
		DefaultTableModel tm = new DefaultTableModel(cols, 0);
		tm.addRow(cols);
		JTable table = new JTable(tm) {

			@Override
			public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
				Component component = super.prepareRenderer(renderer, row, column);
				int rendererWidth = component.getPreferredSize().width;
				TableColumn tableColumn = getColumnModel().getColumn(column);
				tableColumn.setPreferredWidth(
						Math.max(rendererWidth + getIntercellSpacing().width, tableColumn.getPreferredWidth()));
				return component;
			}
		};
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setBorder(new LineBorder(Color.black));
		DefaultTableCellRenderer cellRender = new DefaultTableCellRenderer();
		cellRender.setHorizontalAlignment(SwingConstants.CENTER);

		for (int i = 0; i < table.getColumnCount(); i++) {
			table.getColumnModel().getColumn(i).setCellRenderer(cellRender);
		}

		content.add(table);

		JButton showButton = new JButton("Show");
		showButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					List<Coupon> coupons = service.getCoupons((Category) categoriesList.getSelectedItem());
					
					if(tm.getRowCount() > 1) {
						for(int i = tm.getRowCount() - 1; i > 0; i--) {
							tm.removeRow(i);
						}
					}
					for (int i = 0; i < coupons.size(); i++) {
						int id = coupons.get(i).getId();
						int companyID = coupons.get(i).getCompany().getId();
						Category category = coupons.get(i).getCategory();
						String couponTitle = coupons.get(i).getTitle();
						String description = coupons.get(i).getDescription();
						LocalDate startDate = coupons.get(i).getStartDate();
						LocalDate endDate = coupons.get(i).getEndDate();
						int amount = coupons.get(i).getAmount();
						double price = coupons.get(i).getPrice();
						String imgPath = coupons.get(i).getImgPath();
						Object[] vals = { id, companyID, category, couponTitle, description, startDate, endDate, amount,
								price, imgPath };
						tm.addRow(vals);
					}
					content.revalidate();
					content.repaint();
				} catch (ServiceException e1) {
					e1.printStackTrace();
					if (e1.getCause() != null) {
						e1.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, e1.getMessage(), "Coupons Retrieval By Category Failure",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		categoriesPanel.add(showButton);

		content.add(categoriesPanel);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, categoriesPanel, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, categoriesPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		contentLayout.putConstraint(SpringLayout.NORTH, table, 10, SpringLayout.SOUTH, categoriesPanel);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, table, 0, SpringLayout.HORIZONTAL_CENTER, content);

		content.revalidate();
		content.repaint();
	}

	private void setGetCouponsByPriceComponents() {
		JLabel title = new JLabel("All Coupons");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		JPanel pricePanel = new JPanel();
		pricePanel.setBorder(new TitledBorder("Price"));

		JTextField priceField = new JTextField();
		priceField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.04), (int) (screenSize.getHeight() * 0.02)));
		pricePanel.add(priceField);

		String[] cols = { "ID", "Company ID", "Category", "Title", "Description", "Start Date", "Expiration Date",
				"Amount", "Price", "Image Path" };
		DefaultTableModel tm = new DefaultTableModel(cols, 0);
		tm.addRow(cols);
		JTable table = new JTable(tm) {

			@Override
			public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
				Component component = super.prepareRenderer(renderer, row, column);
				int rendererWidth = component.getPreferredSize().width;
				TableColumn tableColumn = getColumnModel().getColumn(column);
				tableColumn.setPreferredWidth(
						Math.max(rendererWidth + getIntercellSpacing().width, tableColumn.getPreferredWidth()));
				return component;
			}
		};
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setBorder(new LineBorder(Color.black));
		DefaultTableCellRenderer cellRender = new DefaultTableCellRenderer();
		cellRender.setHorizontalAlignment(SwingConstants.CENTER);

		for (int i = 0; i < table.getColumnCount(); i++) {
			table.getColumnModel().getColumn(i).setCellRenderer(cellRender);
		}

		content.add(table);

		JButton showButton = new JButton("Show");
		showButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					double maxPrice = Double.parseDouble(priceField.getText());
					List<Coupon> coupons = service.getCoupons(maxPrice);
					
					if(tm.getRowCount() > 1) {
						for(int i = tm.getRowCount() - 1; i > 0; i--) {
							tm.removeRow(i);
						}
					}
					for (int i = 0; i < coupons.size(); i++) {
						int id = coupons.get(i).getId();
						int companyID = coupons.get(i).getCompany().getId();
						Category category = coupons.get(i).getCategory();
						String couponTitle = coupons.get(i).getTitle();
						String description = coupons.get(i).getDescription();
						LocalDate startDate = coupons.get(i).getStartDate();
						LocalDate endDate = coupons.get(i).getEndDate();
						int amount = coupons.get(i).getAmount();
						double price = coupons.get(i).getPrice();
						String imgPath = coupons.get(i).getImgPath();
						Object[] vals = { id, companyID, category, couponTitle, description, startDate, endDate, amount,
								price, imgPath };
						tm.addRow(vals);
					}
					content.revalidate();
					content.repaint();

				} catch (NumberFormatException e1) {
					e1.printStackTrace();
					if (e1.getCause() != null) {
						e1.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "Invalid price input.", "Coupons Retrieval By Category Failure",
							JOptionPane.ERROR_MESSAGE);

				} catch (Exception e2) {
					e2.printStackTrace();
					if (e2.getCause() != null) {
						e2.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, e2.getMessage(), "Coupons Retrieval By Category Failure",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		pricePanel.add(showButton);

		content.add(pricePanel);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, pricePanel, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, pricePanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		contentLayout.putConstraint(SpringLayout.NORTH, table, 10, SpringLayout.SOUTH, pricePanel);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, table, 0, SpringLayout.HORIZONTAL_CENTER, content);

		content.revalidate();
		content.repaint();
	}
}
