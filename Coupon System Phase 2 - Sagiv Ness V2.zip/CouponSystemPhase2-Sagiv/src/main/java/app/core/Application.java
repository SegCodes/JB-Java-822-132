package app.core;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.EnableScheduling;

import app.core.gui.LoginScreen;

@SpringBootApplication
@EnableScheduling
public class Application {

	public static void main(String[] args) {
		ApplicationContext ctx = new SpringApplicationBuilder(Application.class).headless(false).run(args);
		LoginScreen.startApplication(ctx);
	}

}
