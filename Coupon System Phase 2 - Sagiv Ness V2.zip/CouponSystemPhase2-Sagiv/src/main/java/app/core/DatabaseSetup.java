package app.core;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import app.core.entities.Company;
import app.core.entities.Coupon;
import app.core.entities.Coupon.Category;
import app.core.entities.Customer;
import app.core.exceptions.DatabaseSetupException;
import app.core.exceptions.ServiceException;
import app.core.services.AdminService;
import app.core.services.ClientService;
import app.core.services.CompanyService;
import app.core.services.CustomerService;
import app.core.services.LoginManager;
import app.core.services.LoginManager.ClientType;
import app.core.services.SetupService;

@Component
@Order(1)
public class DatabaseSetup implements CommandLineRunner {

	@Autowired
	private ApplicationContext ctx;

	@Override
	public void run(String... args) throws Exception {
		try {
			setupCompanies();
		} catch (DatabaseSetupException e) {
			e.printStackTrace();
			if (e.getCause() != null) {
				e.getCause().printStackTrace();
			}
			System.out.println();
		}
		
		try {
			setupCustomers();
		} catch (DatabaseSetupException e) {
			e.printStackTrace();
			if (e.getCause() != null) {
				e.getCause().printStackTrace();
			}
			System.out.println();
		}

		try {
			setupExpiredCoupons();
		} catch (DatabaseSetupException e) {
			e.printStackTrace();
			if (e.getCause() != null) {
				e.getCause().printStackTrace();
			}
			System.out.println();
		}

	}

	private void setupCompanies() throws DatabaseSetupException {
		ClientService client = LoginManager.Login("admin@admin.com", "admin", ClientType.ADMINISTRATOR, ctx);
		if (client instanceof AdminService) {
			AdminService admin = (AdminService) client;
			try {
				int id1 = admin.addCompany(new Company("aaa", "aaa@mail.com", "aaa1"));
				setupCompany1Coupons();

				System.out
						.println("\n" + LocalDate.now() + " " + LocalTime.now().format(DateTimeFormatter.ISO_LOCAL_TIME)
								+ " - Added company #" + id1 + "." + "\n");

				int id2 = admin.addCompany(new Company("bbb", "bbb@mail.com", "bbb2"));
				setupCompany2Coupons();

				System.out
						.println("\n" + LocalDate.now() + " " + LocalTime.now().format(DateTimeFormatter.ISO_LOCAL_TIME)
								+ " - Added company #" + id2 + "." + "\n");

				int id3 = admin.addCompany(new Company("ccc", "ccc@mail.com", "ccc3"));
				setupCompany3Coupons();

				System.out
						.println("\n" + LocalDate.now() + " " + LocalTime.now().format(DateTimeFormatter.ISO_LOCAL_TIME)
								+ " - Added company #" + id3 + "." + "\n");
			} catch (ServiceException e) {
				throw new DatabaseSetupException("Companies setup failed - " + e.getMessage(), e);
			}
		}
	}

	private void setupCompany1Coupons() throws DatabaseSetupException {
		ClientService client = LoginManager.Login("aaa@mail.com", "aaa1", ClientType.COMPANY, ctx);
		if (client instanceof CompanyService) {
			CompanyService company1 = (CompanyService) client;
			try {
				company1.addCoupon(
						new Coupon(Category.FOOD, "Chicken Breast Discount", "10% off 1 kg of chicken breast.",
								LocalDate.parse("2022-01-01"), LocalDate.parse("2022-02-01"), 10, 9.99, "img-1"));

				company1.addCoupon(new Coupon(Category.CLOTHING, "Socks Discount", "12% off a pair of socks.",
						LocalDate.parse("2021-12-12"), LocalDate.parse("2022-01-12"), 12, 11.99, "img-2"));

				company1.addCoupon(new Coupon(Category.CAMPING, "Free Field Boots",
						"Buy a tent kit package, get free field boots.", LocalDate.parse("2021-12-06"),
						LocalDate.parse("2021-12-28"), 7, 14.49, "img-3"));

			} catch (ServiceException e) {
				throw new DatabaseSetupException("Company 1 coupons setup failed - " + e.getMessage(), e);
			}
		}
	}

	private void setupCompany2Coupons() throws DatabaseSetupException {
		ClientService client = LoginManager.Login("bbb@mail.com", "bbb2", ClientType.COMPANY, ctx);
		if (client instanceof CompanyService) {
			CompanyService company2 = (CompanyService) client;
			try {
				company2.addCoupon(
						new Coupon(Category.ELECTRICITY, "NVIDIA GPUs Discount", "5% off NVIDIA RTX 30 GPU Series.",
								LocalDate.parse("2021-12-25"), LocalDate.parse("2022-01-09"), 9, 18.99, "img-4"));

				company2.addCoupon(new Coupon(Category.HOME, "Table + Chairs Deal", "Buy a table, get 20% off chairs.",
						LocalDate.parse("2022-02-20"), LocalDate.parse("2022-04-20"), 20, 19.99, "img-5"));

				company2.addCoupon(new Coupon(Category.HOME, "Carpet Discount", "24% off carpets.",
						LocalDate.parse("2021-12-24"), LocalDate.parse("2022-02-08"), 8, 15.99, "img-6"));

			} catch (ServiceException e) {
				throw new DatabaseSetupException("Company 2 coupons setup failed - " + e.getMessage(), e);
			}
		}
	}

	private void setupCompany3Coupons() throws DatabaseSetupException {
		ClientService client = LoginManager.Login("ccc@mail.com", "ccc3", ClientType.COMPANY, ctx);
		if (client instanceof CompanyService) {
			CompanyService company3 = (CompanyService) client;
			try {
				company3.addCoupon(new Coupon(Category.VACATION, "Netherlands Flight Discount",
						"15% off flight ticket to the netherlands.", LocalDate.parse("2021-12-25"),
						LocalDate.parse("2022-01-09"), 15, 14.99, "img-7"));

				company3.addCoupon(new Coupon(Category.VACATION, "Free Business Seat Upgrade",
						"Get a free business seat for the next flight.", LocalDate.parse("2022-02-15"),
						LocalDate.parse("2022-05-03"), 19, 99.99, "img-8"));

				company3.addCoupon(new Coupon(Category.VACATION, "Hotel Discount", "10% off hotel nights.",
						LocalDate.parse("2021-12-06"), LocalDate.parse("2021-12-28"), 4, 9.99, "img-9"));

			} catch (ServiceException e) {
				throw new DatabaseSetupException("Company 3 coupons setup failed - " + e.getMessage(), e);
			}
		}
	}

	private void setupCustomers() throws DatabaseSetupException {
		ClientService client = LoginManager.Login("admin@admin.com", "admin", ClientType.ADMINISTRATOR, ctx);
		if (client instanceof AdminService) {
			AdminService admin = (AdminService) client;
			try {
				int id1 = admin.addCustomer(new Customer("Dana", "Levin", "dlevin@mail.com", "levin123"));
				setupCustomer1Coupons();

				System.out
						.println("\n" + LocalDate.now() + " " + LocalTime.now().format(DateTimeFormatter.ISO_LOCAL_TIME)
								+ " - Added customer #" + id1 + "." + "\n");

				int id2 = admin.addCustomer(new Customer("Jacob", "Benedict", "jbene@mail.com", "benedict123"));
				setupCustomer2Coupons();

				System.out
						.println("\n" + LocalDate.now() + " " + LocalTime.now().format(DateTimeFormatter.ISO_LOCAL_TIME)
								+ " - Added customer #" + id2 + "." + "\n");

				int id3 = admin.addCustomer(new Customer("Fred", "Olsen", "freddyo@mail.com", "fredo123"));
				setupCustomer3Coupons();

				System.out
						.println("\n" + LocalDate.now() + " " + LocalTime.now().format(DateTimeFormatter.ISO_LOCAL_TIME)
								+ " - Added customer #" + id3 + "." + "\n");
			} catch (ServiceException e) {
				throw new DatabaseSetupException("Customers setup failed - " + e.getMessage(), e);
			}
		}
	}

	private void setupCustomer1Coupons() throws DatabaseSetupException {
		ClientService client = LoginManager.Login("dlevin@mail.com", "levin123", ClientType.CUSTOMER, ctx);
		if (client instanceof CustomerService) {
			CustomerService customer1 = (CustomerService) client;
			try {
				customer1.purchaseCoupon(new Coupon(1));
				customer1.purchaseCoupon(new Coupon(4));
				customer1.purchaseCoupon(new Coupon(6));

			} catch (ServiceException e) {
				throw new DatabaseSetupException("Customer 1 coupons setup failed - " + e.getMessage(), e);
			}
		}
	}

	private void setupCustomer2Coupons() throws DatabaseSetupException {
		ClientService client = LoginManager.Login("jbene@mail.com", "benedict123", ClientType.CUSTOMER, ctx);
		if (client instanceof CustomerService) {
			CustomerService customer1 = (CustomerService) client;
			try {
				customer1.purchaseCoupon(new Coupon(7));
				customer1.purchaseCoupon(new Coupon(8));
				customer1.purchaseCoupon(new Coupon(9));

			} catch (ServiceException e) {
				throw new DatabaseSetupException("Customer 2 coupons setup failed - " + e.getMessage(), e);
			}
		}
	}

	private void setupCustomer3Coupons() throws DatabaseSetupException {
		ClientService client = LoginManager.Login("freddyo@mail.com", "fredo123", ClientType.CUSTOMER, ctx);
		if (client instanceof CustomerService) {
			CustomerService customer1 = (CustomerService) client;
			try {
				customer1.purchaseCoupon(new Coupon(2));
				customer1.purchaseCoupon(new Coupon(3));
				customer1.purchaseCoupon(new Coupon(5));

			} catch (ServiceException e) {
				throw new DatabaseSetupException("Customer 3 coupons setup failed - " + e.getMessage(), e);
			}
		}
	}

	private void setupExpiredCoupons() throws DatabaseSetupException {
		try {
			SetupService service = ctx.getBean(SetupService.class);

			Coupon c1 = new Coupon(Category.FOOD, "Expired 1",
					"This is an expired coupon.", LocalDate.now().minusDays(2), LocalDate.now().minusDays(1), 5, 5,
					"img-e1");

			Coupon c2 = new Coupon(Category.VACATION, "Expired 2",
					"This is an expired coupon.", LocalDate.now().minusDays(2), LocalDate.now().minusDays(1), 7, 7,
					"img-e2");

			int eId1 = service.addExpiredCoupon(c1, 1);
			System.out.println("\nAdded Expired coupon with id #" + eId1 + ".\n");

			int eId2 = service.addExpiredCoupon(c2, 3);
			System.out.println("\nAdded Expired coupon with id #" + eId2 + ".\n");
			
			service.purchaseExpiredCoupon(c2, 1);
			service.purchaseExpiredCoupon(c1, 3);
		} catch (Exception e) {
			throw new DatabaseSetupException("Expired coupons setup failed - " + e.getMessage(), e);
		}
	}

}
