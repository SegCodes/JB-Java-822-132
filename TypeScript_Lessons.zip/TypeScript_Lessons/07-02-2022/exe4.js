var fName = prompt("Enter the first name:");
var lName = prompt("Enter the last name:");
document.write("First Name: " + fName + ".");
//# sourceMappingURL=exe4.js.map