var fName = prompt("Enter the first name:");
var lName = prompt("Enter the last name:");
document.write("Last Name: " + lName + ".");
//# sourceMappingURL=exe3.js.map