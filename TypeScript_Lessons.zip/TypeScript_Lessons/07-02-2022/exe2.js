var fName = prompt("Enter the first name:");
var lName = prompt("Enter the last name:");
document.write("Last Name: " + lName + ".<br>");
document.write("First Name: " + fName + ".");
//# sourceMappingURL=exe2.js.map