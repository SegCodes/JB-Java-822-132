﻿var fName: String = prompt("Enter the first name:");
var lName: String = prompt("Enter the last name:");
document.write(`Last Name: ${lName}.`);