var item = prompt("Enter the item's name.");
for (var i = 0; i < 3; i++) {
    document.write(item + "<br>");
}
//# sourceMappingURL=exe5.js.map