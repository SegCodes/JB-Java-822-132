﻿var item: String = prompt("Enter the item's name.");
document.write(`${item}, ${item}, ${item}.`);