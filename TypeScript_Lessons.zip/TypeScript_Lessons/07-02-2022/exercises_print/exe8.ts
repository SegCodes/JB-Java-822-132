﻿var fName: String = prompt("Enter your first name.");
var lName: String = prompt("Enter your last name.");
document.write(`${fName}.<br>${lName}.`);