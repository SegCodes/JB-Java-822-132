var item = prompt("Enter the item's name.");
document.write(item + ", " + item + ", " + item + ".");
//# sourceMappingURL=exe6.js.map