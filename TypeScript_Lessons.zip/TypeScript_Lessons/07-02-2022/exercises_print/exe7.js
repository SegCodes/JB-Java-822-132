var item = prompt("Enter the item's name.");
item = prompt("Great! Now do it again:");
document.write(item + ".");
//# sourceMappingURL=exe7.js.map