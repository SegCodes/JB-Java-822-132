var fName = prompt("Enter your first name.");
var lName = prompt("Enter your last name.");
document.write(fName + ".<br>" + lName + ".");
//# sourceMappingURL=exe8.js.map