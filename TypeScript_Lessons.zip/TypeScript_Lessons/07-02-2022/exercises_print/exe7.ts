﻿var item: String = prompt("Enter the item's name.");
item = prompt("Great! Now do it again:");
document.write(`${item}.`);