var fName = prompt("Enter the first name:");
var lName = prompt("Enter the last name:");
document.write("First Name: " + fName + ".<br>");
document.write("Last Name: " + lName + ".");
//# sourceMappingURL=exe1.js.map