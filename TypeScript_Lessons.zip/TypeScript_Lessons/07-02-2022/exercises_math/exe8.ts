﻿var width: number = parseInt(prompt("Enter rectangle's width:"));
var length: number = parseInt(prompt("Enter rectangle's length:"));
document.write(`Rectangle's Width: ${width}.<br>Rectangle's Length: ${length}.<br>
Rectangle's size: ${width} * ${length} = ${width * length}.`);