﻿const pi: number = 3.14;
var diameter: number = parseInt(prompt("Enter pot's diameter:"));
var depth: number = parseInt(prompt("Enter pot's depth:"));
document.write(`Pot's Diameter: ${diameter}.<br>Pot's Depth: ${depth}.<br>
Pot's Capacity: (${diameter} / 2) * ${depth} = ${(diameter / 2) * depth}.`);