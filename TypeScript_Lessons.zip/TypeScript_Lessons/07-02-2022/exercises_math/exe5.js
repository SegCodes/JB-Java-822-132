{
    var n1_1 = parseInt(prompt("Enter the first number:"));
    var n2_1 = parseInt(prompt("Enter the second number:"));
    var n3_1 = parseInt(prompt("Enter the third number:"));
    var n4 = parseInt(prompt("Enter the last number:"));
    document.write("1. " + n3_1 + " + " + n1_1 + " = " + (n3_1 + n1_1) + ".<br>");
    document.write("2. " + n4 + " - " + n2_1 + " = " + (n4 - n2_1) + ".<br>");
    document.write("3. " + n3_1 + " / 8 = " + n3_1 / 8 + ".<br>");
    document.write("4. " + n4 + " * " + n1_1 + " = " + n4 * n1_1 + ".<br>");
}
//# sourceMappingURL=exe5.js.map