﻿var n1: number = parseFloat(prompt("Enter the first number:"));
var n2: number = parseFloat(prompt("Enter the second number:"));
var n3: number = parseFloat(prompt("Enter the last number:"));
var mul: number = n1 * n2 * n3;
document.write(`${n1} * ${n2} * ${n3} = ${mul}`);