var n = parseInt(prompt("Enter a 3 digit number."));
document.write(n + " last digit is: " + Math.floor(n / 100));
//# sourceMappingURL=exe13.js.map