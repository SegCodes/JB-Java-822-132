var n1 = parseInt(prompt("Enter the first number:"));
var n2 = parseInt(prompt("Enter the second number:"));
var n3 = parseInt(prompt("Enter the last number:"));
var sum = n1 + n2 + n3;
document.write(n1 + " + " + n2 + " + " + n3 + " = " + sum);
//# sourceMappingURL=exe1.js.map