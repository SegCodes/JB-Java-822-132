﻿var n: number = parseFloat(prompt("Enter a decimal digit number."));
var t: number = Math.floor(n % 10);
document.write(`After ${n}'s decimal is: ${n % t}.`);