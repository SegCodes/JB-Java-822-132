var pi = 3.14;
var diameter = parseInt(prompt("Enter pot's diameter:"));
var depth = parseInt(prompt("Enter pot's depth:"));
document.write("Pot's Diameter: " + diameter + ".<br>Pot's Depth: " + depth + ".<br>\nPot's Capacity: (" + diameter + " / 2) * " + depth + " = " + (diameter / 2) * depth + ".");
//# sourceMappingURL=exe9.js.map