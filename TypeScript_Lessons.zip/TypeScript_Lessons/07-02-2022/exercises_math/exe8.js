var width = parseInt(prompt("Enter rectangle's width:"));
var length = parseInt(prompt("Enter rectangle's length:"));
document.write("Rectangle's Width: " + width + ".<br>Rectangle's Length: " + length + ".<br>\nRectangle's size: " + width + " * " + length + " = " + width * length + ".");
//# sourceMappingURL=exe8.js.map