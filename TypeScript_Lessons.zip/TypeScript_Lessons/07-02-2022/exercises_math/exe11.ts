﻿var n = parseInt(prompt("Enter a 4 digit number."));
document.write(`${n} first digit is: ${n % 10}`);