var a = parseInt(prompt("Enter the first number:"));
var b = parseInt(prompt("Enter the second number:"));
document.write("Pre switch: a = " + a + ", b = " + b + ".<br>");
var t = a;
a = b;
b = t;
document.write("Post switch: a = " + a + ", b = " + b + ".");
//# sourceMappingURL=exe7.js.map