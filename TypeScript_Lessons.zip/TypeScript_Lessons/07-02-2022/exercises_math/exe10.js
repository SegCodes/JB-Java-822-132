var movieLength = parseInt(prompt("Enter movie length in minutes."));
document.write("Movie length is: " + Math.floor(movieLength / 60) + " hours and " + movieLength % 60 + " minutes.");
//# sourceMappingURL=exe10.js.map