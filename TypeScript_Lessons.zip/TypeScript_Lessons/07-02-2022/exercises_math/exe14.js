var n = parseInt(prompt("Enter a 2 digit number."));
document.write(n + " digit sum is: " + Math.floor(n / 10) + " + " + n % 10 + " = " + (Math.floor(n / 10) + (n % 10)));
//# sourceMappingURL=exe14.js.map