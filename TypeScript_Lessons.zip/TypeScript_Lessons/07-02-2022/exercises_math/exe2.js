var n1 = parseFloat(prompt("Enter the first number:"));
var n2 = parseFloat(prompt("Enter the second number:"));
var n3 = parseFloat(prompt("Enter the last number:"));
var avg = (n1 + n2 + n3) / 3;
document.write("(" + n1 + " + " + n2 + " + " + n3 + ") / 3 = " + avg);
//# sourceMappingURL=exe2.js.map