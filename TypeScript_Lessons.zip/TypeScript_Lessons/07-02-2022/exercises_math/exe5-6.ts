﻿{
    let n1: number = parseInt(prompt("Enter the first number:"));
    let n2: number = parseInt(prompt("Enter the second number:"));
    let n3: number = parseInt(prompt("Enter the third number:"));
    let n4: number = parseInt(prompt("Enter the last number:"));
    document.write(`1. ${n3} + ${n1} = ${n3 + n1}.<br>`);
    document.write(`2. ${n4} - ${n2} = ${n4 - n2}.<br>`);
    document.write(`3. ${n3} / 8 = ${n3 /8}.<br>`);
    document.write(`4. ${n4} * ${n1} = ${n4 * n1}.<br>`);
}