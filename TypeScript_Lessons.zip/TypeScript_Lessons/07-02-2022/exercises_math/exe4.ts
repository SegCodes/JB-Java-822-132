﻿var n: number = parseFloat(prompt("Enter a number:"));
document.write(`${n} ^ 2 = ${n ** 2}`);