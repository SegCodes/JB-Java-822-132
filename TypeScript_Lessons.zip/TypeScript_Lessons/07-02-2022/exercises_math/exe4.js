var n = parseFloat(prompt("Enter a number:"));
document.write(n + " ^ 2 = " + Math.pow(n, 2));
//# sourceMappingURL=exe4.js.map