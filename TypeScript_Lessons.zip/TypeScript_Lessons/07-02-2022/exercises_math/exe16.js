var n = parseFloat(prompt("Enter a decimal digit number."));
var t = Math.floor(n % 10);
document.write("After " + n + "'s decimal is: " + n % t + ".");
//# sourceMappingURL=exe16.js.map