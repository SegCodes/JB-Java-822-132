var n = parseInt(prompt("Enter a 4 digit number."));
document.write(n + " second digit is: " + Math.floor(n % 100 / 10));
//# sourceMappingURL=exe12.js.map