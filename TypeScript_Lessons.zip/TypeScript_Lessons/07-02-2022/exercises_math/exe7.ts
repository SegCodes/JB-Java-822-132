﻿var a: number = parseInt(prompt("Enter the first number:"));
var b: number = parseInt(prompt("Enter the second number:"));
document.write(`Pre switch: a = ${a}, b = ${b}.<br>`);
var t = a;
a = b;
b = t;
document.write(`Post switch: a = ${a}, b = ${b}.`);