﻿for (let i = 100; i < 1000; i++) {
    let d: number = i % 10;
    let t: number = Math.floor(i / 10 % 10);
    let h = Math.floor(i / 100);
    if (d % 2 == 0 && t % 2 == 0 && h % 2 == 0) {
        document.write(`${i}, `);
    }
}