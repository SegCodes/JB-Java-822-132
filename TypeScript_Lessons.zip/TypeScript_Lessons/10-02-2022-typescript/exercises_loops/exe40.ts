﻿var num: number = parseInt(prompt("Enter a number."));
var ind: number = 0;
var max: number = 0;
var ex: number = 0;

for (let i = 0; i < num; i++) {
    let n: number = Math.round(Math.random() * 20);
    //let n: number = parseInt(prompt("Enter another number."));
    if (max < n) {
        max = n;
        ex = 0;
        ind = i;
    } else if (max == n) {
        ex++;
    }
}
document.write(`Max value: ${max}.<br>`);
document.write(`${max}'s first appearance index: ${ind}.<br>`);
document.write(`${max}'s extra appearances: ${ex}.<br>`);