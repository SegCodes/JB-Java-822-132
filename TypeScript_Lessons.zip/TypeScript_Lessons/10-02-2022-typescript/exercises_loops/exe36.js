var n = parseInt(prompt("Enter a number."));
var sum = 0;
for (var i_1 = 1; i_1 <= n; i_1++) {
    if (i_1 % 4 == 0 || i_1 % 7 == 0) {
        sum += i_1;
        document.write(i_1 + ", ");
    }
}
document.write("<br>The sum of the numbers that can be divided by 4 or 7 from 1 to " + n + " is: " + sum + ".");
//# sourceMappingURL=exe36.js.map