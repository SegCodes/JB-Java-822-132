var num = parseInt(prompt("Enter a number."));
var min = num;
while (num > 0) {
    min = Math.min(min, num);
    num = parseInt(prompt("Enter another number."));
}
document.write("The lowest number entered is " + min + ".");
//# sourceMappingURL=exe08.js.map