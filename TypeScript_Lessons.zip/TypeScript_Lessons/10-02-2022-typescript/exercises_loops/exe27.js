var n1 = parseInt(prompt("Enter the first number."));
var n2 = parseInt(prompt("Enter the second number."));
var inc = 1;
if (n1 > n2) {
    var tmp_1 = n2;
    n2 = n1;
    n1 = tmp_1;
}
for (var i_1 = n1; i_1 <= n2; i_1++) {
    document.write(i_1 + ", ");
}
for (var i_2 = n2 - 1; i_2 > n1; i_2--) {
    document.write(i_2 + ", ");
}
document.write(n1 + ".");
//# sourceMappingURL=exe27.js.map