var num = parseInt(prompt("Enter the first number."));
var n2 = parseInt(prompt("Enter the second number."));
if (num > n2) {
    var tmp_1 = num;
    num = n2;
    n2 = tmp_1;
}
for (var i_1 = num; i_1 <= n2; i_1++) {
    document.write(i_1 + ", ");
}
//# sourceMappingURL=exe02.js.map