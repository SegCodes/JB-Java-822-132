for (var i_1 = 10; i_1 < 100; i_1++) {
    if (i_1 % 10 > Math.floor(i_1 / 10)) {
        document.write(i_1 + ", ");
    }
}
//# sourceMappingURL=exe50.js.map