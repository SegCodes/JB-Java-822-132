var num = parseInt(prompt("Enter a number."));
var dig = num;
while (dig > 10) {
    dig = Math.floor(dig / 10);
}
document.write(num + "'s most left digit is " + dig + ".");
//# sourceMappingURL=exe10.js.map