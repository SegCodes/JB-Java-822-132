var n = parseInt(prompt("Enter a number."));
var fact = 1;
if (n > 0) {
    for (var i_1 = 1; i_1 <= n; i_1++) {
        fact *= i_1;
    }
}
document.write(n + "! = " + fact + ".");
//# sourceMappingURL=exe33.js.map