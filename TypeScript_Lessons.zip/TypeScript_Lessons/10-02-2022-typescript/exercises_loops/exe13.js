var num = parseInt(prompt("Enter a number."));
var dig = parseInt(prompt("Enter a digit."));
var tmp = num;
var c = 0;
if (dig > 9 || dig < 0) {
    document.write("Invalid digit output.");
}
else {
    while (tmp > 0) {
        if (tmp % 10 == dig) {
            c++;
        }
        tmp = Math.floor(tmp / 10);
    }
    document.write(dig + " appears in " + num + " a total of " + c + " times.");
}
//# sourceMappingURL=exe13.js.map