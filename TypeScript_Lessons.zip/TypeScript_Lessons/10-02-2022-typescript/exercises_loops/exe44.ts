﻿var sumT: number = 0;
var cTotal: number = 0;
document.write("Schools Statistics:<br>");
for (let i = 0; i < 5; i++) {
    let sumS: number = 0;
    let c: number = 0;
    for (let j = 0; j < 5; j++) {
        let g: number = Math.round(Math.random() * 75 + 25);
        sumS += g;
        cTotal++;
        c++;
    }
    document.write(`Student #${i + 1} average grade: ${sumS / c}.<br>`);
    sumT += sumS;
}
document.write(`<br>School's average grade: ${sumT / cTotal}.`);