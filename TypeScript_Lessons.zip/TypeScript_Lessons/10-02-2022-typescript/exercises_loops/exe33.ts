﻿var n: number = parseInt(prompt("Enter a number."));
var fact: number = 1;
if (n > 0) {
    for (let i = 1; i <= n; i++) {
        fact *= i;
    }
}
document.write(`${n}! = ${fact}.`);