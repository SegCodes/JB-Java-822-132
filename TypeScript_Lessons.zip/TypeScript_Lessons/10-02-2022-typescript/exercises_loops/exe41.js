var num = parseInt(prompt("Enter a number."));
var ind = 0;
var max = 0;
var maxSec = 0;
var secInd = 0;
for (var i_1 = 0; i_1 < num; i_1++) {
    var n_1 = Math.round(Math.random() * 20);
    //let n: number = parseInt(prompt("Enter another number."));
    if (max < n_1) {
        maxSec = max;
        secInd = ind;
        max = n_1;
        ind = i_1;
    }
    else if (maxSec < n_1 && n_1 < max) {
        maxSec = n_1;
        secInd = i_1;
    }
    else if (maxSec == n_1) {
        secInd = i_1;
    }
    document.write(n_1 + ", ");
}
document.write("<br>Second max value: " + maxSec + ".<br>");
document.write(maxSec + "'s last appearance index: " + secInd + ".<br>");
//# sourceMappingURL=exe41.js.map