var num = parseInt(prompt("Enter the first number."));
var max = parseInt(prompt("Enter the maximum number."));
if (num = 0) {
    document.write("ERROR: divide by 0.");
}
for (var i = 0; i <= max; i++) {
    if (i % num == 0) {
        document.write(i + ", ");
    }
}
//# sourceMappingURL=exe4%20-%20Copy.js.map