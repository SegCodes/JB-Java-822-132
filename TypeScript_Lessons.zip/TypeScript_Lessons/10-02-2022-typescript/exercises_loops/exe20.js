var num = parseInt(prompt("Enter a number."));
document.write(num + " ^ 0.5 = " + Math.sqrt(num) + ".");
//# sourceMappingURL=exe20.js.map