var num = parseInt(prompt("Enter a number."));
var n2 = parseInt(prompt("Enter another number."));
var tmp = num;
var c = 0;
if (n2 == 0) {
    document.write("ERROR: divide by 0.");
}
else {
    while (tmp > 0) {
        tmp -= n2;
        c++;
    }
    document.write(num + " / " + n2 + " = " + c + ".");
}
//# sourceMappingURL=exe18.js.map