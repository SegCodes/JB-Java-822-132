﻿var num: number = parseInt(prompt("Enter the first number."));
var c: number = parseInt(prompt("Enter the maximum number."));

if (num = 0) {
    document.write("ERROR: divide by 0.");
}

for (let i = 0; i <= c; i++) {
    if (i % num == 0) {
        document.write(`${i}, `);
    }
}