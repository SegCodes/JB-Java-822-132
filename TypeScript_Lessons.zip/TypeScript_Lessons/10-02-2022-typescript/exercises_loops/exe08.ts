﻿var num: number = parseInt(prompt("Enter a number."));
var min: number = num;

while (num > 0) {
    min = Math.min(min, num);
    num = parseInt(prompt("Enter another number."));
}
document.write(`The lowest number entered is ${min}.`)