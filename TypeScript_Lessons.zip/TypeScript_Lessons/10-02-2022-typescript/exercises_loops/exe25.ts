﻿var n1: number = parseInt(prompt("Enter a number."));
var tmp: number = n1;
var div: number = 2;

if (n1 == 1 || n1 == 0) {
    document.write(`${n1} = ${n1}`);
} else {
    while (tmp > 1) {
        if (tmp % div == 0) {
            tmp /= div;
            document.write(`${div} x `);
        } else {
            div++;
        }
    }
    document.write(`1 = ${n1}`);
}