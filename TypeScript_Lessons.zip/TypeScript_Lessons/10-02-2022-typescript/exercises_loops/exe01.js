var topN = parseInt(prompt("Enter a number."));
for (var i_1 = 1; i_1 <= topN; i_1++) {
    document.write(i_1 + ", ");
}
//# sourceMappingURL=exe01.js.map