﻿var sum: number = 0;
for (let i = 1; i <= 15; i++) {
    let n: number = Math.round(Math.random() * 50);
    if (i % 3 == 0) {
        sum += n;
        document.write(`${n}, `);
    }
}
document.write(`<br>The sum of the numbers that are in every 3rd position is: ${sum}.`);