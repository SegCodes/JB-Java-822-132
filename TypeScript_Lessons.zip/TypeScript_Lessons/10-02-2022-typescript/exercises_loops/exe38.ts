﻿var sum: number = 0;
for (let i = 0; i < 20; i++) {
    let n: number = Math.round(Math.random() * 101);
    if (i % 2 == 0) {
        sum += n;
        document.write(`${n}(${i}), `);
    }
}
document.write(`<br>The sum of all the even numbers is: ${sum}.`);