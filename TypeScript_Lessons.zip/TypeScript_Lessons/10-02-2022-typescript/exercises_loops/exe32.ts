﻿var n: number = parseInt(prompt("Enter a number, 0 to end."));

while (n != 0) {
    if (checkFibbo(n)) {
        document.write(`${n} is in the fibbonaci sequence.<br>`);
        alert(`${n} is in the fibbonaci sequence.`);
    } else {
        document.write(`${n} is not in the fibbonaci sequence.<br>`);
        alert(`${n} is not in the fibbonaci sequence.`);
    }
    n = parseInt(prompt("Enter another number, 0 to end."));
}

function checkFibbo(num: number): boolean {
    var n1: number = 0;
    var n2: number = 1;

    while (n2 <= num) {
        let tmp: number = n1 + n2;
        n1 = n2;
        n2 = tmp;
    }

    if (n1 == num) {
        return true;
    } else {
        return false;
    }
}