var rows = parseInt(prompt("Enter number of rows."));
var cols = parseInt(prompt("Enter number of columns."));
for (var i_1 = 0; i_1 < rows; i_1++) {
    for (var j = 0; j < cols; j++) {
        document.write("* ");
    }
    document.write("<br>");
}
//# sourceMappingURL=exe48.js.map