var sum = 0;
var num;
var mes = "found";
for (var i_1 = 0; i_1 < 10; i_1++) {
    var n_1 = parseInt(prompt("Enter the " + (i_1 + 1) + " number."));
    //let n: number = Math.round(Math.random() * 10);
    document.write(n_1 + ", ");
    if (i_1 > 0) {
        num = n_1;
    }
    if (sum == num) {
        break;
    }
    sum += n_1;
    if (i_1 == 9) {
        mes = "not found";
    }
    alert("Sum = " + sum + ", num = " + num);
}
document.write("<br>A number equals to the sum of all the previous is " + mes + ".");
//# sourceMappingURL=exe43.js.map