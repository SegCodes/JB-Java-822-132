﻿var num: number = parseInt(prompt("Enter a number."));
var c: number = num;
var ind: number = 0;

for (let i = 1; i < 10; i++) {
    if (c < num) {
        c = num;
        ind = i;
    }
    num = parseInt(prompt("Enter another number."));
}
document.write(`The index of the highest number entered (${c}) is ${ind}.`);