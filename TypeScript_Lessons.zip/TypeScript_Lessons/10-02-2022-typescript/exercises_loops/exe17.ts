﻿var num: number = parseInt(prompt("Enter a number."));
var n2: number = parseInt(prompt("Enter another number."));
var tmp: number = 1;

for (let i = 0; i < n2; i++) {
    tmp *= num;
}

document.write(`${num} ^ ${n2} = ${tmp}.`);
