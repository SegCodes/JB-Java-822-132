var num = parseInt(prompt("Enter the first number."));
var n2 = parseInt(prompt("Enter the second number."));
if (num > n2) {
    var tmp_1 = num;
    num = n2;
    n2 = tmp_1;
}
for (var i = num; i <= n2; i++) {
    document.write(i + ", ");
}
//# sourceMappingURL=exe2.js.map