﻿var n: number = parseInt(prompt("Enter a number."));
var sum: number = 0;
for (let i = 1; i <= n; i++) {
    if (i % 3 == 0) {
        sum += i;
    }
}
document.write(`The sum of the numbers that are divisible by 3 from 1 to ${n}: ${sum}.`);