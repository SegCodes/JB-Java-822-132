﻿for (let i = 1; i < 11; i++) {
    for (let j = i; j < 11 * i; j += i) {
        document.write(`${j} `);
    }
    document.write("<br>");
}