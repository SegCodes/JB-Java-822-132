var num = parseInt(prompt("Enter a number."));
var c = num;
var ind = 0;
for (var i = 1; i < 10; i++) {
    if (c < num) {
        c = num;
        ind = i;
    }
    num = parseInt(prompt("Enter another number."));
}
document.write("The index of the highest number entered (" + c + ") is " + ind + ".");
//# sourceMappingURL=exe9.js.map