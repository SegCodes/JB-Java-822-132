var n1 = parseInt(prompt("Enter a number, negative to end."));
while (n1 > 0) {
    var tmp_1 = n1;
    var sum_1 = 0;
    while (tmp_1 > 0) {
        sum_1 += tmp_1 % 10;
        tmp_1 = Math.floor(tmp_1 / 10);
    }
    document.write(n1 + "'s digit sum: " + sum_1 + ".<br>");
    alert(n1 + "'s digit sum: " + sum_1 + ".");
    n1 = parseInt(prompt("Enter a number, negative to end."));
}
//# sourceMappingURL=exe29.js.map