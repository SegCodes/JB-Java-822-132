﻿var num: number = parseInt(prompt("Enter a number."));

document.write(`${num} ^ 0.5 = ${Math.sqrt(num)}.`);