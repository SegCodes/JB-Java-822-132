var num = parseInt(prompt("Enter a number."));
for (var i_1 = 1; i_1 <= num; i_1++) {
    for (var j = i_1; j <= num; j++) {
        document.write(j + " ");
    }
    document.write("<br>");
}
//# sourceMappingURL=exe45.js.map