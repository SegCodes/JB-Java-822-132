var n1 = parseInt(prompt("Enter a number."));
var c = 0;
var mes = "a prime number";
if (n1 == 1 || n1 == 0) {
    mes = "not a prime number";
}
else {
    for (var i_1 = 1; i_1 <= n1; i_1++) {
        if (n1 % i_1 == 0) {
            c++;
        }
    }
    if (c > 2) {
        mes = "not a prime number";
    }
}
document.write(n1 + " is " + mes + ".");
//# sourceMappingURL=exe24.js.map