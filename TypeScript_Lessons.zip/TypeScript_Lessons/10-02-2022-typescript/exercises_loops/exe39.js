var num = parseInt(prompt("Enter a number."));
document.write("The indexes of " + num + "'s appearances:<br>");
for (var i_1 = 0; i_1 < 20; i_1++) {
    var n_1 = Math.round(Math.random() * 101);
    //let n: number = parseInt(prompt("Enter another number."));
    if (n_1 == num) {
        document.write(i_1 + ", ");
    }
}
//# sourceMappingURL=exe39.js.map