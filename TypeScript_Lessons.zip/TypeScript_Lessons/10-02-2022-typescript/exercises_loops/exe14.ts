﻿var num: number = parseInt(prompt("Enter a number."));
var tmp: number = num;
var back: number = 0;

if (num < 10 && num >= 0) {
    back = num;
} else {
    while (tmp > 0) {
        /*
         * if back is string:
         * back += tmp % 10; without multipication.
         */
        back *= 10;
        back += tmp % 10;
        tmp = Math.floor(tmp / 10);
    }
}
document.write(`${num} backwards is ${back}.`);
