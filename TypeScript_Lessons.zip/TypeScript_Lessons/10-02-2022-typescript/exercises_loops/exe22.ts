﻿var n1: number = parseInt(prompt("Enter an number."));
document.write(`${n1} can be divided by:<br>`);

for (let i = 1; i <= n1; i++) {
    if (n1 % i == 0) {
        document.write(`${i}, `);
    }
}