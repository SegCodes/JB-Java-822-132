﻿var dig: number = parseInt(prompt("Enter a digit(0-9)"));
var test: boolean = false;
for (let i = 1; i < 101; i++) {
    let tmp: number = i;
    while (tmp > 0 && !test) {
        if (tmp % 10 == dig) {
            document.write(`${i}, `);
            test = true;
        }
        tmp = Math.floor(tmp / 10);
        test = false;
    }
}