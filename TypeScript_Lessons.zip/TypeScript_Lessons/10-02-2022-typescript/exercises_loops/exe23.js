var n1 = parseInt(prompt("Enter the first number."));
var n2 = parseInt(prompt("Enter the second number."));
var run = Math.min(n1, n2);
var c = 0;
for (var i_1 = 1; i_1 <= run; i_1++) {
    if (n1 % i_1 == 0 && n2 % i_1 == 0 && i_1 > c) {
        c = i_1;
    }
}
document.write(n1 + " & " + n2 + " largest denumenator is " + c + ".");
//# sourceMappingURL=exe23.js.map