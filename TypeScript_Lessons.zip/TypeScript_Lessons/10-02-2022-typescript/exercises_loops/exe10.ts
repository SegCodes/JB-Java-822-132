﻿var num: number = parseInt(prompt("Enter a number."));
var dig: number = num;

while (dig > 10) {
    dig = Math.floor(dig / 10);
}
document.write(`${num}'s most left digit is ${dig}.`);