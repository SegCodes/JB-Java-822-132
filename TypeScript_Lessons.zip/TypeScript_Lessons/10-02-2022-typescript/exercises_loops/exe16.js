var num = parseInt(prompt("Enter a number."));
var n2 = parseInt(prompt("Enter another number."));
var mul = 0;
for (var i_1 = 0; i_1 < n2; i_1++) {
    mul += num;
}
document.write(num + " x " + n2 + " = " + mul + ".");
//# sourceMappingURL=exe16.js.map