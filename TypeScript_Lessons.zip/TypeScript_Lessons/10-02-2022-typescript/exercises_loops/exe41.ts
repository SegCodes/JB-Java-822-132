﻿var num: number = parseInt(prompt("Enter a number."));
var ind: number = 0;
var max: number = 0;
var maxSec: number = 0;
var secInd: number = 0;

for (let i = 0; i < num; i++) {
    let n: number = Math.round(Math.random() * 20);
    //let n: number = parseInt(prompt("Enter another number."));
    if (max < n) {
        maxSec = max;
        secInd = ind;
        max = n;
        ind = i;
    } else if (maxSec < n && n < max) {
        maxSec = n;
        secInd = i;
    } else if (maxSec == n) {
        secInd = i;
    }
    document.write(`${n}, `);
}
document.write(`<br>Second max value: ${maxSec}.<br>`);
document.write(`${maxSec}'s last appearance index: ${secInd}.<br>`);