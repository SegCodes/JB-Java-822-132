var num = parseInt(prompt("Enter a number."));
var fact = 1;
if (num != 0) {
    for (var i_1 = 1; i_1 <= num; i_1++) {
        fact *= i_1;
    }
}
document.write(num + "! = " + fact + ".");
//# sourceMappingURL=exe19.js.map