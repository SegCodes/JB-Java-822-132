﻿var n1: number = parseInt(prompt("Enter a number."));

for (let i = 0; i <= n1; i++) {
    if (i % 2 == 0) {
        document.write(`${i}, `);
    }
}