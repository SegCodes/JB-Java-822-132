﻿var ind: number = parseInt(prompt("Enter an index."));
var n1: number = 1;
var n2: number = 1;

if (ind == 0) {
    n2 = 0;

} else if (ind > 2) {
    for (let i = 3; i <= ind; i++) {
        let tmp: number = n1 + n2;
        n1 = n2;
        n2 = tmp;
    }
}
document.write(`The number in index ${ind} in the fibonacci's sequence is: ${n2}.`)