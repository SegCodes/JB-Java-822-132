var num = parseInt(prompt("Enter a number."));
var sum = 0;
while (num != 99) {
    sum += num;
    num = parseInt(prompt("Enter another number."));
}
document.write("Numbers sum = " + sum + ".");
//# sourceMappingURL=exe05.js.map