var num = parseInt(prompt("Enter a number."));
var dig = 0;
var tmp = num;
var sum = 0;
while (tmp > 0) {
    dig = tmp % 10;
    sum += dig;
    tmp = Math.floor(tmp / 10);
}
document.write("The sum of " + num + "'s digits is " + sum + ".");
//# sourceMappingURL=exe12.js.map