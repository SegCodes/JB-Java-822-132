var topN = parseInt(prompt("Enter a number."));
for (var i = 1; i <= topN; i++) {
    document.write(i + ", ");
}
//# sourceMappingURL=exe1.js.map