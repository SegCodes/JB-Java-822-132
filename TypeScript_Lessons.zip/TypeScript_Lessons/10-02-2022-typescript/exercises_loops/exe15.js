var num = parseInt(prompt("Enter a number."));
var tmp = num;
var back = 0;
var pal = "";
if (num < 10 && num >= 0) {
    pal = "is a palindrum";
}
else {
    while (tmp > 0) {
        back *= 10;
        back += tmp % 10;
        tmp = Math.floor(tmp / 10);
    }
    if (num == back) {
        pal = "is a palindrum";
    }
    else {
        pal = "isn't a palindrum";
    }
}
document.write(num + " " + pal + ".");
//# sourceMappingURL=exe15.js.map