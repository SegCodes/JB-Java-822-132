var n1 = parseInt(prompt("Enter an number."));
document.write(n1 + " can be divided by:<br>");
for (var i_1 = 1; i_1 <= n1; i_1++) {
    if (n1 % i_1 == 0) {
        document.write(i_1 + ", ");
    }
}
//# sourceMappingURL=exe22.js.map