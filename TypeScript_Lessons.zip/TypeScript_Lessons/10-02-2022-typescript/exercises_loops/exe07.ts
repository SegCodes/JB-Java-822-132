﻿var num: number = parseInt(prompt("Enter a number."));
var c: number = num;

while (num > 0) {
    c = Math.max(c, num);
    num = parseInt(prompt("Enter another number."));
}
document.write(`The highest number entered is ${c}.`)