for (var i_1 = 1; i_1 < 11; i_1++) {
    for (var j = i_1; j < 11 * i_1; j += i_1) {
        document.write(j + " ");
    }
    document.write("<br>");
}
//# sourceMappingURL=exe49.js.map