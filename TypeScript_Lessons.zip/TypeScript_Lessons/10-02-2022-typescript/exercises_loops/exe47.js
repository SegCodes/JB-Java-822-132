var n1 = Math.floor(Math.random() * 10);
document.write(n1 + "(!), ");
for (var i_1 = 1; i_1 < 10; i_1++) {
    var n2 = Math.floor(Math.random() * 10);
    var inc_1 = 1;
    if (n1 > n2) {
        inc_1 = -1;
    }
    for (var j = (n1 + inc_1); j != n2; j += inc_1) {
        document.write(j + ", ");
    }
    document.write(n2 + "(!), ");
    n1 = n2;
}
//# sourceMappingURL=exe47.js.map