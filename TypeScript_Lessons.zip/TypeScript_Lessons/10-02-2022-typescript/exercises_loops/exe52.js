for (var i_1 = 10; i_1 < 100; i_1++) {
    var d_1 = i_1 % 10;
    var t = Math.floor(i_1 / 10);
    if (i_1 % d_1 == 0 && i_1 % t == 0 && i_1 % (d_1 + t) == 0) {
        document.write(i_1 + ", ");
    }
}
//# sourceMappingURL=exe52.js.map