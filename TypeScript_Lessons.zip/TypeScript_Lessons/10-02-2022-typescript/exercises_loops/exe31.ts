﻿var n1: number = parseInt(prompt("Enter a number."));
var count: number = 0;

while (!isPrime(n1)) {
    count++;
    n1 = parseInt(prompt("Enter another number."));
}
document.write(`You've entered ${count} non primed numbers.`);

function isPrime(num: number): boolean {
    var c: number = 0;
    var prime: boolean = true;

    if (num == 1 || num == 0) {
        prime = false;
    } else {
        for (let i = 1; i <= num; i++) {
            if (num % i == 0) {
                c++;
            }
        }

        if (c > 2) {
            prime = false;
        }
    }
    return prime;
}