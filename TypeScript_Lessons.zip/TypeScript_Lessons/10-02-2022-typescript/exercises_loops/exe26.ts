﻿var n1: number = parseInt(prompt("Enter the first number."));
var n2: number = parseInt(prompt("Enter the second number."));
var inc: number = 1;

if (n1 > n2) {
    inc = -1;
}

for (let i = n1; i != n2; i += inc) {
    document.write(`${i}, `);
}
document.write(`${n2}.`);