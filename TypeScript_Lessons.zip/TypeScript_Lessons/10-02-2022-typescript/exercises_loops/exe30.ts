﻿var n1: number = parseInt(prompt("Enter a number."));
var ord: string = "";
var c: number = 0;

for (let i = 0; i < 10; i++) {
    let tmp: number = n1;
    while (tmp > 0) {
        if (tmp % 10 == i) {
            c++;
        }
        tmp = Math.floor(tmp / 10);
    }

    for (let j = 0; j < c; j++) {
        ord += i;
    }
    c = 0;
}

document.write(`${n1} ordered is ${ord}.`);