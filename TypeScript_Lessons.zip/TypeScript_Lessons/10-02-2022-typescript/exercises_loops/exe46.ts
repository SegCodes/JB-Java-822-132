﻿var num: number = parseInt(prompt("Enter a number."));
for (let i = 1; i <= num; i++) {
    for (let j = num; j >= i; j--) {
        document.write(`${j} `);
    }
    document.write("<br>");
}