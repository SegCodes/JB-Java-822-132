﻿var n1: number = Math.floor(Math.random() * 10);
document.write(`${n1}(!), `);

for (let i = 1; i < 10; i++) {
    var n2: number = Math.floor(Math.random() * 10);
    let inc: number = 1;

    if (n1 > n2) {
        inc = -1;
    }

    for (let j = (n1 + inc); j != n2; j += inc) {
            document.write(`${j}, `);
    }

    document.write(`${n2}(!), `);
    n1 = n2;
}