var sum = 0;
var avg;
for (var i = 0; i < 30; i++) {
    sum += Math.round(Math.random() * 30 + 10);
}
avg = Math.round(sum / 30);
document.write("The days in July 2001 that were hotter than July 2000's average(" + avg + "):<br>");
for (var i_1 = 1; i_1 <= 30; i_1++) {
    var tmp_1 = Math.round(Math.random() * 30 + 10);
    if (tmp_1 > avg) {
        document.write(i_1 + "(" + tmp_1 + "), ");
    }
}
//# sourceMappingURL=exe28.js.map