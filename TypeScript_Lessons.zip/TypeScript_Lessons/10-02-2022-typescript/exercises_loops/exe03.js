var n1 = parseInt(prompt("Enter a number."));
for (var i_1 = 0; i_1 <= n1; i_1++) {
    if (i_1 % 2 == 0) {
        document.write(i_1 + ", ");
    }
}
//# sourceMappingURL=exe03.js.map