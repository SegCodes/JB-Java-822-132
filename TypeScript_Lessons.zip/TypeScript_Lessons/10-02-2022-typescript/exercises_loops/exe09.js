var num = parseInt(prompt("Enter a number."));
var c = num;
var ind = 0;
for (var i_1 = 1; i_1 < 10; i_1++) {
    if (c < num) {
        c = num;
        ind = i_1;
    }
    num = parseInt(prompt("Enter another number."));
}
document.write("The index of the highest number entered (" + c + ") is " + ind + ".");
//# sourceMappingURL=exe09.js.map