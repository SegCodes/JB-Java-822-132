var n = parseInt(prompt("Enter a number."));
var sum = 0;
for (var i_1 = 1; i_1 <= n; i_1++) {
    if (i_1 % 3 == 0) {
        sum += i_1;
    }
}
document.write("The sum of the numbers that are divisible by 3 from 1 to " + n + ": " + sum + ".");
//# sourceMappingURL=exe34.js.map