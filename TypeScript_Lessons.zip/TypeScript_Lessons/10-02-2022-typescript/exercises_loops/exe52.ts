﻿for (let i = 10; i < 100; i++) {
    let d: number = i % 10;
    let t: number = Math.floor(i / 10);
    if (i % d == 0 && i % t == 0 && i % (d + t) == 0) {
        document.write(`${i}, `);
    }
}