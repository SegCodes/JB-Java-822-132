var sum = 0;
for (var i_1 = 0; i_1 < 20; i_1++) {
    var n_1 = Math.round(Math.random() * 101);
    if (n_1 % 2 == 0) {
        sum += n_1;
        document.write(n_1 + "(" + (i_1 + 1) + "), ");
    }
}
document.write("<br>The sum of all the even numbers is: " + sum + ".");
//# sourceMappingURL=exe37.js.map