var sumT = 0;
var cTotal = 0;
document.write("Schools Statistics:<br>");
for (var i_1 = 0; i_1 < 5; i_1++) {
    var sumS = 0;
    var c_1 = 0;
    for (var j = 0; j < 5; j++) {
        var g = Math.round(Math.random() * 75 + 25);
        sumS += g;
        cTotal++;
        c_1++;
    }
    document.write("Student #" + (i_1 + 1) + " average grade: " + sumS / c_1 + ".<br>");
    sumT += sumS;
}
document.write("<br>School's average grade: " + sumT / cTotal + ".");
//# sourceMappingURL=exe44.js.map