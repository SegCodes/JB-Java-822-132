﻿var n1: number = parseInt(prompt("Enter the first number."));
var n2: number = parseInt(prompt("Enter the second number."));
var inc: number = 1;

if (n1 > n2) {
    let tmp = n2;
    n2 = n1;
    n1 = tmp;
}

for (let i = n1; i <= n2; i++) {
    document.write(`${i}, `);
}

for (let i = n2 - 1; i > n1; i--) {
    document.write(`${i}, `);
}

document.write(`${n1}.`);