﻿var num: number = parseInt(prompt("Enter a number."));
document.write(`The indexes of ${num}'s appearances:<br>`);
for (let i = 0; i < 20; i++) {
    let n: number = Math.round(Math.random() * 101);
    //let n: number = parseInt(prompt("Enter another number."));
    if (n == num) {
        document.write(`${i}, `);
    }
}