var num = parseInt(prompt("Enter a number."));
var n2 = parseInt(prompt("Enter another number."));
var tmp = 1;
for (var i_1 = 0; i_1 < n2; i_1++) {
    tmp *= num;
}
document.write(num + " ^ " + n2 + " = " + tmp + ".");
//# sourceMappingURL=exe17.js.map