﻿var num: number = parseInt(prompt("Enter a number."));
var dig: number = num;
var c: number = 0;

if (num == 0) {
    c = 1;
}
else {
    while (dig > 0) {
        dig = Math.floor(dig / 10);
        c++;
    }
}
document.write(`${num} has ${c} digits.`);