var pay = parseInt(prompt("Enter payment."));
var tmp = pay;
var db200 = 0;
var db100 = 0;
var db50 = 0;
var db20 = 0;
var db10 = 0;
var db5 = 0;
var db1 = 0;
while (tmp >= 200) {
    tmp -= 200;
    db200++;
}
while (tmp >= 100) {
    tmp -= 100;
    db100++;
}
while (tmp >= 50) {
    tmp -= 50;
    db50++;
}
while (tmp >= 20) {
    tmp -= 20;
    db20++;
}
while (tmp >= 10) {
    tmp -= 10;
    db10++;
}
while (tmp >= 5) {
    tmp -= 5;
    db5++;
}
while (tmp >= 1) {
    tmp--;
    db1++;
}
document.write("Payment of " + pay + ":<br>");
document.write("200 bills: " + db200 + ".<br>");
document.write("100 bills: " + db100 + ".<br>");
document.write("50 bills: " + db50 + ".<br>");
document.write("20 bills: " + db20 + ".<br>");
document.write("10 coins: " + db10 + ".<br>");
document.write("5 coins: " + db5 + ".<br>");
document.write("1 coins: " + db1 + ".<br>");
document.write("Total money types used: " + (db1 + db10 + db100 + db20 + db200 + db5 + db50));
//# sourceMappingURL=exe53.js.map