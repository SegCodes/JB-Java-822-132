var dig = parseInt(prompt("Enter a digit(0-9)"));
var test = false;
for (var i_1 = 1; i_1 < 101; i_1++) {
    var tmp_1 = i_1;
    while (tmp_1 > 0 && !test) {
        if (tmp_1 % 10 == dig) {
            document.write(i_1 + ", ");
            test = true;
        }
        tmp_1 = Math.floor(tmp_1 / 10);
        test = false;
    }
}
//# sourceMappingURL=exe51.js.map