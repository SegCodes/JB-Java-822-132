﻿var num: number = parseInt(prompt("Enter a number."));
var fact: number = 1;

if (num != 0) {
    for (let i = 1; i <= num; i++) {
        fact *= i;
    }
}

document.write(`${num}! = ${fact}.`);