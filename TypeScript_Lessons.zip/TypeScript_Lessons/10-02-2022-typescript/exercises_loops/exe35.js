var sum = 0;
for (var i_1 = 1; i_1 <= 15; i_1++) {
    var n_1 = Math.round(Math.random() * 50);
    if (i_1 % 3 == 0) {
        sum += n_1;
        document.write(n_1 + ", ");
    }
}
document.write("<br>The sum of the numbers that are in every 3rd position is: " + sum + ".");
//# sourceMappingURL=exe35.js.map