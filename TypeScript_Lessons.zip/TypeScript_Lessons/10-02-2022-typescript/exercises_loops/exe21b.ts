﻿var num: number = parseInt(prompt("Enter an number."));
var n1: number = 0;
var n2: number = 1;

while (n2 <= num) {
    document.write(`${n2}, `);
    let tmp: number = n1 + n2;
    n1 = n2;
    n2 = tmp;
}