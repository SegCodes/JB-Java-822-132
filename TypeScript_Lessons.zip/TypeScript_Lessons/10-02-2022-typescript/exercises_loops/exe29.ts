﻿var n1: number = parseInt(prompt("Enter a number, negative to end."));

while (n1 > 0) {
    let tmp: number = n1;
    let sum: number = 0;
    while (tmp > 0) {
        sum += tmp % 10;
        tmp = Math.floor(tmp / 10);
    }
    document.write(`${n1}'s digit sum: ${sum}.<br>`);
    alert(`${n1}'s digit sum: ${sum}.`);
    n1 = parseInt(prompt("Enter a number, negative to end."));
}