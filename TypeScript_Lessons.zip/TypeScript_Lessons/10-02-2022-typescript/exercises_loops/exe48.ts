﻿var rows: number = parseInt(prompt("Enter number of rows."));
var cols: number = parseInt(prompt("Enter number of columns."));


for (let i = 0; i < rows; i++) {

    for (let j = 0; j < cols; j++) {
        document.write("* ");
    }
    document.write("<br>");
}