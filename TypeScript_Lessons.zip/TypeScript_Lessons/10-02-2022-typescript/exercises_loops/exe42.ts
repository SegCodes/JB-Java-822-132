﻿var max: number = 0;
var mes: string = "arranged";

for (let i = 0; i < 10; i++) {
    let n: number = parseInt(prompt(`Enter the ${i + 1} number.`));
    if (max <= n) {
        max = n;
    } else {
        mes = "not arranged";
    }
    document.write(`${n}, `);
}
document.write(`<br>The numbers are ${mes} in a rising order.`);