var ind = parseInt(prompt("Enter an index."));
var n1 = 1;
var n2 = 1;
if (ind == 0) {
    n2 = 0;
}
else if (ind > 2) {
    for (var i_1 = 3; i_1 <= ind; i_1++) {
        var tmp_1 = n1 + n2;
        n1 = n2;
        n2 = tmp_1;
    }
}
document.write("The number in index " + ind + " in the fibonacci's sequence is: " + n2 + ".");
//# sourceMappingURL=exe21a.js.map