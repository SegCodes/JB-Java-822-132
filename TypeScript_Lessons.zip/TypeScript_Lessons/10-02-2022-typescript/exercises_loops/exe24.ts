﻿var n1: number = parseInt(prompt("Enter a number."));
var c: number = 0;
var mes: string = "a prime number";

if (n1 == 1 || n1 == 0) {
    mes = "not a prime number";
} else {
    for (let i = 1; i <= n1; i++) {
        if (n1 % i == 0) {
            c++;
        }
    }

    if (c > 2) {
        mes = "not a prime number";
    }
}
document.write(`${n1} is ${mes}.`);