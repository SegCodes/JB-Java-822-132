var num = parseInt(prompt("Enter an number."));
var n1 = 0;
var n2 = 1;
while (n2 <= num) {
    document.write(n2 + ", ");
    var tmp_1 = n1 + n2;
    n1 = n2;
    n2 = tmp_1;
}
//# sourceMappingURL=exe21b.js.map