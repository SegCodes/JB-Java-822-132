﻿var num: number = parseInt(prompt("Enter a number."));
for (let i = 1; i <= num; i++) {
    for (let j = i; j <= num; j++) {
        document.write(`${j} `);
    }
    document.write("<br>");
}