var n1 = parseInt(prompt("Enter a number."));
var ord = "";
var c = 0;
for (var i_1 = 0; i_1 < 10; i_1++) {
    var tmp_1 = n1;
    while (tmp_1 > 0) {
        if (tmp_1 % 10 == i_1) {
            c++;
        }
        tmp_1 = Math.floor(tmp_1 / 10);
    }
    for (var j = 0; j < c; j++) {
        ord += i_1;
    }
    c = 0;
}
document.write(n1 + " ordered is " + ord + ".");
//# sourceMappingURL=exe30.js.map