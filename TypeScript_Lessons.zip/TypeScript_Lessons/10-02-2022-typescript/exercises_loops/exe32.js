var n = parseInt(prompt("Enter a number, 0 to end."));
while (n != 0) {
    if (checkFibbo(n)) {
        document.write(n + " is in the fibbonaci sequence.<br>");
        alert(n + " is in the fibbonaci sequence.");
    }
    else {
        document.write(n + " is not in the fibbonaci sequence.<br>");
        alert(n + " is not in the fibbonaci sequence.");
    }
    n = parseInt(prompt("Enter another number, 0 to end."));
}
function checkFibbo(num) {
    var n1 = 0;
    var n2 = 1;
    while (n2 <= num) {
        var tmp_1 = n1 + n2;
        n1 = n2;
        n2 = tmp_1;
    }
    if (n1 == num) {
        return true;
    }
    else {
        return false;
    }
}
//# sourceMappingURL=exe32.js.map