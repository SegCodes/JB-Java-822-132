﻿var num: number = parseInt(prompt("Enter a number."));
var n2: number = parseInt(prompt("Enter another number."));
var mul: number = 0;

for (let i = 0; i < n2; i++) {
    mul += num;
}

document.write(`${num} x ${n2} = ${mul}.`);
