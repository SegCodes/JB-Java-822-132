var n = parseInt(prompt("Enter a number."));
for (var i = 0; i <= n; i++) {
    if (i % 2 == 0) {
        document.write(i + ", ");
    }
}
//# sourceMappingURL=exe3.js.map