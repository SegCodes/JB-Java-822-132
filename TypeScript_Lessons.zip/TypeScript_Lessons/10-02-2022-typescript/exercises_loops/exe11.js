var num = parseInt(prompt("Enter a number."));
var dig = num;
var c = 0;
if (num == 0) {
    c = 1;
}
else {
    while (dig > 0) {
        dig = Math.floor(dig / 10);
        c++;
    }
}
document.write(num + " has " + c + " digits.");
//# sourceMappingURL=exe11.js.map