﻿var sum: number = 0;
var num: number;
var mes: string = "found";

for (let i = 0; i < 10; i++) {
    let n: number = parseInt(prompt(`Enter the ${i + 1} number.`));
    //let n: number = Math.round(Math.random() * 10);
    document.write(`${n}, `);
    if (i > 0) {
        num = n;
    }
    if (sum == num) {
        break;
    }
    sum += n;
    if (i == 9) {
        mes = "not found";
    }
    alert(`Sum = ${sum}, num = ${num}`);
}
document.write(`<br>A number equals to the sum of all the previous is ${mes}.`);