﻿var num: number = parseInt(prompt("Enter a number."));
var sum: number = 0;
var denum: number = 0;

while (num != 0) {
    sum += num;
    denum++;
    num = parseInt(prompt("Enter another number."));
}
document.write(`Numbers average = ${sum / denum}.`)