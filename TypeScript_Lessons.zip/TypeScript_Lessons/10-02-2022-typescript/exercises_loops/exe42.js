var max = 0;
var mes = "arranged";
for (var i_1 = 0; i_1 < 10; i_1++) {
    var n_1 = parseInt(prompt("Enter the " + (i_1 + 1) + " number."));
    if (max <= n_1) {
        max = n_1;
    }
    else {
        mes = "not arranged";
    }
    document.write(n_1 + ", ");
}
document.write("<br>The numbers are " + mes + " in a rising order.");
//# sourceMappingURL=exe42.js.map