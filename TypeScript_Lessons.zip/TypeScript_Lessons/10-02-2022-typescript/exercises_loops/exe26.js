var n1 = parseInt(prompt("Enter the first number."));
var n2 = parseInt(prompt("Enter the second number."));
var inc = 1;
if (n1 > n2) {
    inc = -1;
}
for (var i_1 = n1; i_1 != n2; i_1 += inc) {
    document.write(i_1 + ", ");
}
document.write(n2 + ".");
//# sourceMappingURL=exe26.js.map