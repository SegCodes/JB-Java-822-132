var num = parseInt(prompt("Enter a number."));
var c = num;
while (num > 0) {
    c = Math.max(c, num);
    num = parseInt(prompt("Enter another number."));
}
document.write("The highest number entered is " + c + ".");
//# sourceMappingURL=exe07.js.map