﻿var n: number = parseInt(prompt("Enter a number."));
var sum: number = 0;
for (let i = 1; i <= n; i++) {
    if (i % 4 == 0 || i % 7 == 0) {
        sum += i;
        document.write(`${i}, `);
    }
}
document.write(`<br>The sum of the numbers that can be divided by 4 or 7 from 1 to ${n} is: ${sum}.`);