﻿for (let i = 10; i < 100; i++) {
    if (i % 10 > Math.floor(i / 10)) {
        document.write(`${i}, `);
    }
}