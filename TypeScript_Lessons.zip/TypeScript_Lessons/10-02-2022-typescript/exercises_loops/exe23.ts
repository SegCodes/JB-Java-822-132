﻿var n1: number = parseInt(prompt("Enter the first number."));
var n2: number = parseInt(prompt("Enter the second number."));
var run: number = Math.min(n1, n2);
var c: number = 0;

for (let i = 1; i <= run; i++) {
    if (n1 % i == 0 && n2 % i == 0 && i > c) {
        c = i;
    }
}
document.write(`${n1} & ${n2} largest denumenator is ${c}.`);