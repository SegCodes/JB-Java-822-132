var num = parseInt(prompt("Enter the first number."));
var c = parseInt(prompt("Enter the maximum number."));
if (num = 0) {
    document.write("ERROR: divide by 0.");
}
for (var i = 0; i <= c; i++) {
    if (i % num == 0) {
        document.write(i + ", ");
    }
}
//# sourceMappingURL=exe4.js.map