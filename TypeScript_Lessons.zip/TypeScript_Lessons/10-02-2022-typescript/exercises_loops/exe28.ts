﻿var sum: number = 0;
var avg: number;
for (var i = 0; i < 30; i++) {
    sum += Math.round(Math.random() * 30 + 10,);
}
avg = Math.round(sum / 30);
document.write(`The days in July 2001 that were hotter than July 2000's average(${avg}):<br>`);
for (let i = 1; i <= 30; i++) {
    let tmp: number = Math.round(Math.random() * 30 + 10);
    if (tmp > avg) {
        document.write(`${i}(${tmp}), `);
    }
}