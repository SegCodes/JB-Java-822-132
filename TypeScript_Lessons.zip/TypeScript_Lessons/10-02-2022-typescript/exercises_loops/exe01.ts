﻿var topN: number = parseInt(prompt("Enter a number."));
for (let i = 1; i <= topN; i++) {
    document.write(`${i}, `);
}