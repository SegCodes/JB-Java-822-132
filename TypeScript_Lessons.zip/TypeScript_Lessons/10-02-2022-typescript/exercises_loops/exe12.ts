﻿var num: number = parseInt(prompt("Enter a number."));
var dig: number = 0;
var tmp: number = num;
var sum: number = 0;

while (tmp > 0) {
    dig = tmp % 10;
    sum += dig;
    tmp = Math.floor(tmp / 10);
}
document.write(`The sum of ${num}'s digits is ${sum}.`);