for (var i_1 = 100; i_1 < 1000; i_1++) {
    var d_1 = i_1 % 10;
    var t = Math.floor(i_1 / 10 % 10);
    var h = Math.floor(i_1 / 100);
    if (d_1 % 2 == 0 && t % 2 == 0 && h % 2 == 0) {
        document.write(i_1 + ", ");
    }
}
//# sourceMappingURL=exe54.js.map