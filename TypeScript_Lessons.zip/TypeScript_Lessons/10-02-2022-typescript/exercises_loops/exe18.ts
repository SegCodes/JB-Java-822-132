﻿var num: number = parseInt(prompt("Enter a number."));
var n2: number = parseInt(prompt("Enter another number."));
var tmp: number = num;
var c: number = 0;

if (n2 == 0) {
    document.write("ERROR: divide by 0.");

} else {
    while (tmp > 0) {
        tmp -= n2;
        c++;
    }

    document.write(`${num} / ${n2} = ${c}.`);

}
