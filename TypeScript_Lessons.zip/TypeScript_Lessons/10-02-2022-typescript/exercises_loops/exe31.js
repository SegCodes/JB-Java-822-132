var n1 = parseInt(prompt("Enter a number."));
var count = 0;
while (!isPrime(n1)) {
    count++;
    n1 = parseInt(prompt("Enter another number."));
}
document.write("You've entered " + count + " non primed numbers.");
function isPrime(num) {
    var c = 0;
    var prime = true;
    if (num == 1 || num == 0) {
        prime = false;
    }
    else {
        for (var i_1 = 1; i_1 <= num; i_1++) {
            if (num % i_1 == 0) {
                c++;
            }
        }
        if (c > 2) {
            prime = false;
        }
    }
    return prime;
}
//# sourceMappingURL=exe31.js.map