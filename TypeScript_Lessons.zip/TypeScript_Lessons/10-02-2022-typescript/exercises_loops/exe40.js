var num = parseInt(prompt("Enter a number."));
var ind = 0;
var max = 0;
var ex = 0;
for (var i_1 = 0; i_1 < num; i_1++) {
    var n_1 = Math.round(Math.random() * 20);
    //let n: number = parseInt(prompt("Enter another number."));
    if (max < n_1) {
        max = n_1;
        ex = 0;
        ind = i_1;
    }
    else if (max == n_1) {
        ex++;
    }
}
document.write("Max value: " + max + ".<br>");
document.write(max + "'s first appearance index: " + ind + ".<br>");
document.write(max + "'s extra appearances: " + ex + ".<br>");
//# sourceMappingURL=exe40.js.map