var num = parseInt(prompt("Enter the first number."));
var c = parseInt(prompt("Enter the maximum number."));
if (num = 0) {
    document.write("ERROR: divide by 0.");
}
for (var i_1 = 0; i_1 <= c; i_1++) {
    if (i_1 % num == 0) {
        document.write(i_1 + ", ");
    }
}
//# sourceMappingURL=exe04.js.map