var num = parseInt(prompt("Enter a number."));
for (var i_1 = 1; i_1 <= num; i_1++) {
    for (var j = num; j >= i_1; j--) {
        document.write(j + " ");
    }
    document.write("<br>");
}
//# sourceMappingURL=exe46.js.map