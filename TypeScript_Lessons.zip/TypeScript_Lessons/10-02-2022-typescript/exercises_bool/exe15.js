var grade = parseInt(prompt("Enter the Student's grade."));
document.write("The grade is ");
if (grade < 55) {
    document.write("not enough.");
}
else if (grade <= 64) {
    document.write("enough.");
}
else if (grade <= 74) {
    document.write("okay.");
}
else if (grade <= 84) {
    document.write("good.");
}
else if (grade <= 94) {
    document.write("great!");
}
else {
    document.write("excellent!");
}
//# sourceMappingURL=exe15.js.map