var num = parseInt(prompt("Enter the first number."));
var n2 = parseInt(prompt("Enter the second number."));
var n3 = parseInt(prompt("Enter the third number."));
document.write("Between " + num + ", " + n2 + " and " + n3 + "...<br>");
var c;
if (num > n2) {
    c = num > n3 ? num : n3;
}
else if (n2 > n3) {
    c = n2;
}
else {
    c = n3;
}
document.write(c + " is the largest.");
//# sourceMappingURL=exe10.js.map