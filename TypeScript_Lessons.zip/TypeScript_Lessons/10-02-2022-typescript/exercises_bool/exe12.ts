﻿var age: number = parseInt(prompt(`Enter the candidate's age.`));
var height: number = parseInt(prompt(`Enter the candidate's height.`));

var qual: string;
if ((age >= 14 && age <= 18) || (age >= 21 && age <= 26)) {
    if (height >= 182) {
        qual = "is qualified";

    } else {
        qual = "is not qualified";
    }
} else {
    qual = "is not qualified";
}

document.write(`The candidate is ${qual}.`);

