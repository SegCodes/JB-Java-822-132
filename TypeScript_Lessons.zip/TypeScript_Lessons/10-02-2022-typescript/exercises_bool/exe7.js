var n1 = parseInt(prompt("Enter a number."));
if (n1 >= 928 || n1 <= 532) {
    document.write(n1 + " checks out.");
}
//# sourceMappingURL=exe7.js.map