﻿var num: number = parseInt(prompt(`Enter the first number.`));
var n2: number = parseInt(prompt(`Enter the second number.`));
var n3: number = parseInt(prompt(`Enter the third number.`));

document.write(`Between ${num}, ${n2} and ${n3}...<br>`);

var c: number;
if (num > n2) {
    c = num > n3 ? num : n3;

} else if (n2 > n3) {
    c = n2;

} else {
    c = n3;
}
document.write(`${c} is the largest.`);

