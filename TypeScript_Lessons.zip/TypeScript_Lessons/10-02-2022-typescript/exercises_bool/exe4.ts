﻿var num: number = parseInt(prompt("Enter the first number."));
var n2: number = parseInt(prompt("Enter the second number."));

var check = num % n2 == 0 ? "can" : "cannot";
document.write(`${num} ${check} be divided by ${n2}.<br>`);

check = n2 % num == 0 ? "can" : "cannot";
document.write(`${n2} ${check} be divided by ${num}.`);