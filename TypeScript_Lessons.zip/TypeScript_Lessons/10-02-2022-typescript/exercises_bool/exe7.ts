﻿var n1: number = parseInt(prompt("Enter a number."));

if (n1 >= 928 || n1 <= 532) {
    document.write(`${n1} checks out.`);
}