﻿var n1: number = parseInt(prompt(`Enter a number between 1 and 10.`));

document.write(`${n1} is `);
switch (n1) {
    case 1:
        document.write("one.");
        break;

    case 2:
        document.write("two.");
        break;

    case 3:
        document.write("three.");
        break;

    case 4:
        document.write("four.");
        break;

    case 5:
        document.write("five.");
        break;

    case 6:
        document.write("six.");
        break;

    case 7:
        document.write("seven.");
        break;

    case 8:
        document.write("eight.");
        break;

    case 9:
        document.write("nine.");
        break;

    case 10:
        document.write("ten.");
        break;

    default:
        alert("FREEZE! Your'e under arrest for defying the instructions!");
        document.body.innerHTML = "";
        document.write("I hope your'e happy, you monster.");
        break;
}