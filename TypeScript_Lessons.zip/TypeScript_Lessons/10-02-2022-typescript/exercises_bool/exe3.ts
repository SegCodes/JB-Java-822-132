﻿var n1: number = parseInt(prompt("Enter a number."));

if (n1 % 2 == 0) {
    document.write(`${n1} is even.`);
} else {
    document.write(`${n1} is odd.`);
}