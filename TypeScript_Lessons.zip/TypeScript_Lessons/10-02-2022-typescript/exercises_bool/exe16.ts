﻿var a: number = parseInt(prompt("Enter the value of A."));
var b: number = parseInt(prompt("Enter the value of B."));
var c: number = parseInt(prompt("Enter the value of C."));
var d: number = parseInt(prompt("Enter the value of D."));
var e: number = parseInt(prompt("Enter the value of E."));
var f: number = parseInt(prompt("Enter the value of F."));

var denum: number = a * e - b * d;
var num = (c * e - b * f) / denum;
var y = (a * f - c * d) / denum;

if (denum == 0) {
    alert("ERROR! division by 0 has occured.");
    document.write("Equation has no solution.");
} else {
    document.write(`${a}x + ${b}y = ${c}<br>`);
    document.write(`${d}x + ${e}y = ${f}<br><br>`);

    document.write(`${a} * ${num} + ${b} * ${y} = ${c}<br>`);
    document.write(`${d} * ${num} + ${e} * ${y} = ${f}<br>`);
}