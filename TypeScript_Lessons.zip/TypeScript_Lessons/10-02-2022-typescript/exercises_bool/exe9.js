var num = parseInt(prompt("Enter the first number."));
var n2 = parseInt(prompt("Enter the second number."));
var n3 = parseInt(prompt("Enter the third number."));
var c;
if (num < n2) {
    if (n2 < n3) {
        document.write("Increasing...");
    }
}
//# sourceMappingURL=exe9.js.map