var num = parseInt(prompt("Enter the first number."));
var n2 = parseInt(prompt("Enter the second number."));
if (num > n2) {
    document.write("Growing...");
}
//# sourceMappingURL=exe1.js.map