var n1 = parseInt(prompt("Enter a number between 1 and 9,999."));
var dig;
if (n1 < 10) {
    dig = 1;
}
else if (n1 < 100) {
    dig = 2;
}
else if (n1 < 1000) {
    dig = 3;
}
else if (n1 > 9999) {
    dig = 4;
}
else {
    dig = NaN;
}
document.write(n1 + " has " + dig + " digits.");
//# sourceMappingURL=exe11.js.map