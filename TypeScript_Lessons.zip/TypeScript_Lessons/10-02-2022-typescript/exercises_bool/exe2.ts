﻿var num: number = parseInt(prompt("Enter the first number."));
var n2: number = parseInt(prompt("Enter the second number."));

if (num > n2) {
    document.write(`${num} is bigger than ${n2}`);
} else {
    document.write(`${n2} is bigger than ${num}`);
}

// var check = n1 > n2 ? n1 : n2;