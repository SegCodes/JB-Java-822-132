var n1 = parseInt(prompt("Enter a number."));
if (n1 > 0) {
    document.write(n1 + " is positive.");
}
else if (n1 < 0) {
    document.write(n1 + " is negative.");
}
else {
    document.write(n1 + " is 0.");
}
//# sourceMappingURL=exe6.js.map