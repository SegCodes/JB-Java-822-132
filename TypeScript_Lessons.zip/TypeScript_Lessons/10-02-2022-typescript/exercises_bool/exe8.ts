﻿var eName: string = prompt("Enter employee's name.")
var sal: number = parseInt(prompt(`Enter ${eName}'s salary.`));

document.write(`${eName}'s salary before change: ${sal}.<br>`);

var newSal: number;
if (sal * 1.1 > 6000) {
    newSal = sal * 1.05;
    document.write(`${eName}'s salary rose by 5% to: ${newSal}.`);
} else {
    newSal = sal * 1.1;
    document.write(`${eName}'s salary rose by 10% to: ${newSal}.`);

}
