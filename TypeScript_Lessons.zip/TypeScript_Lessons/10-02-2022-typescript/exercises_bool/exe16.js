var a = parseInt(prompt("Enter the value of A."));
var b = parseInt(prompt("Enter the value of B."));
var c = parseInt(prompt("Enter the value of C."));
var d = parseInt(prompt("Enter the value of D."));
var e = parseInt(prompt("Enter the value of E."));
var f = parseInt(prompt("Enter the value of F."));
var denum = a * e - b * d;
var num = (c * e - b * f) / denum;
var y = (a * f - c * d) / denum;
if (denum == 0) {
    alert("ERROR! division by 0 has occured.");
    document.write("Equation has no solution.");
}
else {
    document.write(a + "x + " + b + "y = " + c + "<br>");
    document.write(d + "x + " + e + "y = " + f + "<br><br>");
    document.write(a + " * " + num + " + " + b + " * " + y + " = " + c + "<br>");
    document.write(d + " * " + num + " + " + e + " * " + y + " = " + f + "<br>");
}
//# sourceMappingURL=exe16.js.map