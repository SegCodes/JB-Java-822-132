﻿var num: number = parseInt(prompt(`Enter the first number.`));
var n2: number = parseInt(prompt(`Enter the second number.`));
var n3: number = parseInt(prompt(`Enter the third number.`));

var str: string;
if (num < n2) {
    if (num < n3) {
        document.write(`${num}, `);
        str = n2 < n3 ? `${n2}, ${n3}` : `${n3}, ${n2}`;
    } else {
        str = `${n3}, ${num}, ${n2}`;
    }

} else if (n2 < n3) {
    document.write(`${n2}, `);
    str = num < n3 ? `${num}, ${n3}` : `${n3}, ${num}`;

} else {
    str = `${n3}, ${n2}, ${num}`;
}
document.write(`${str}.`);