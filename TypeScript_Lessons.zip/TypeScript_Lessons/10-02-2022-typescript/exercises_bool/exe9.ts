﻿var num: number = parseInt(prompt(`Enter the first number.`));
var n2: number = parseInt(prompt(`Enter the second number.`));
var n3: number = parseInt(prompt(`Enter the third number.`));

var c: number;
if (num < n2) {
    if (n2 < n3) {
        document.write("Increasing...");
    }
}