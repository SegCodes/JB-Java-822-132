var n1 = parseInt(prompt("Enter a number."));
if (n1 % 2 == 0) {
    document.write(n1 + " is even.");
}
else {
    document.write(n1 + " is odd.");
}
//# sourceMappingURL=exe3.js.map