var num = parseInt(prompt("Enter the first number."));
var n2 = parseInt(prompt("Enter the second number."));
document.write(Math.min(num, n2) + ", " + Math.max(num, n2) + ".");
//# sourceMappingURL=exe5.js.map