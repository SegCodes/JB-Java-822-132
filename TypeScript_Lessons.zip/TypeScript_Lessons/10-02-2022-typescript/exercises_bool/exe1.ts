﻿var num: number = parseInt(prompt("Enter the first number."));
var n2: number = parseInt(prompt("Enter the second number."));

if (num > n2) {
    document.write("Growing...");
}