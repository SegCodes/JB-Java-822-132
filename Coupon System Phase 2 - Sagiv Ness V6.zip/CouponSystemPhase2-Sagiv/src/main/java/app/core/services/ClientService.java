package app.core.services;

import javax.persistence.MappedSuperclass;

import org.springframework.beans.factory.annotation.Autowired;

import app.core.repositories.CompaniesRepository;
import app.core.repositories.CouponsRepository;
import app.core.repositories.CustomersRepository;

@MappedSuperclass
public abstract class ClientService {

	// ******************************
	// Attributes
	// ******************************
	@Autowired
	protected CustomersRepository customersRepo;
	@Autowired
	protected CompaniesRepository companiesRepo;
	@Autowired
	protected CouponsRepository couponsRepo;

	// ******************************
	// Methods
	// ******************************
	/**
	 * Checks whether the email and password entered are viable to login.
	 * 
	 * @param email    - The email entered.
	 * @param password - The password entered.
	 * @return true - If the info entered was found and login is possible, false -
	 *         If the email or password are not correct.
	 */
	public abstract boolean login(String email, String password);
}
