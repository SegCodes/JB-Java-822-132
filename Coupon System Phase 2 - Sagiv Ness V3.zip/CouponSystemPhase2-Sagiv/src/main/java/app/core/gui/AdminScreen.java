package app.core.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpringLayout;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;

import app.core.entities.Company;
import app.core.entities.Customer;
import app.core.exceptions.ServiceException;
import app.core.services.AdminService;

public class AdminScreen {

	private AdminService service;
	private JFrame frame;
	private JPanel content;
	private SpringLayout contentLayout;
	private Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

	public AdminScreen(AdminService adminService) {
		frame = new JFrame("Coupons System - Admin");
		contentLayout = new SpringLayout();
		content = new JPanel(contentLayout);
		service = adminService;
		startAdminScreen();
	}

	private void startAdminScreen() {
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.7), (int) (screenSize.getHeight() / 1.4)));
		JMenuBar menuBar = new JMenuBar();

		JMenuItem logout = new JMenuItem("Logout");
		logout.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				LoginScreen.startApplication(null);
			}
		});
		menuBar.add(logout);

		JMenu companiesMenu = new JMenu("Companies");

		JMenu modCompanyMenu = new JMenu("Modify Company");

		JMenuItem addCompany = new JMenuItem("Add");
		addCompany.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setAddCompanyComponents();
			}
		});
		modCompanyMenu.add(addCompany);

		JMenuItem updateCompany = new JMenuItem("Update");
		updateCompany.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setUpdateCompanyComponents();
			}
		});
		modCompanyMenu.add(updateCompany);

		JMenuItem deleteCompany = new JMenuItem("Delete");
		deleteCompany.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setDeleteCompanyComponents();
			}
		});
		modCompanyMenu.add(deleteCompany);

		companiesMenu.add(modCompanyMenu);

		JMenu getCompaniesMenu = new JMenu("Get");

		JMenuItem getAllCompanies = new JMenuItem("All");
		getAllCompanies.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setGetAllCompaniesComponents();
			}
		});
		getCompaniesMenu.add(getAllCompanies);

		JMenuItem getOneCompany = new JMenuItem("One");
		getOneCompany.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setGetOneCompanyComponents();
			}
		});
		getCompaniesMenu.add(getOneCompany);

		companiesMenu.add(getCompaniesMenu);

		menuBar.add(companiesMenu);

		JMenu customersMenu = new JMenu("Customers");

		JMenu modCustomerMenu = new JMenu("Modify Customer");

		JMenuItem addCustomer = new JMenuItem("Add");
		addCustomer.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setAddCustomerComponents();
			}
		});
		modCustomerMenu.add(addCustomer);

		JMenuItem updateCustomer = new JMenuItem("Update");
		updateCustomer.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setUpdateCustomerComponents();
			}
		});
		modCustomerMenu.add(updateCustomer);

		JMenuItem deleteCustomer = new JMenuItem("Delete");
		deleteCustomer.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setDeleteCustomerComponents();
			}
		});
		modCustomerMenu.add(deleteCustomer);

		customersMenu.add(modCustomerMenu);

		JMenu getCustomersMenu = new JMenu("Get");

		JMenuItem getAllCustomers = new JMenuItem("All");
		getAllCustomers.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setGetAllCustomersComponents();
			}
		});
		getCustomersMenu.add(getAllCustomers);

		JMenuItem getOneCustomer = new JMenuItem("One");
		getOneCustomer.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				content.removeAll();
				setGetOneCustomerComponents();
			}
		});
		getCustomersMenu.add(getOneCustomer);

		customersMenu.add(getCustomersMenu);

		menuBar.add(customersMenu);

		frame.setJMenuBar(menuBar);
		frame.setContentPane(content);
		frame.setResizable(false);
		frame.pack();
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
	}

	private void setAddCompanyComponents() {
		JLabel title = new JLabel("Add Company");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		JPanel fieldsPanel = new JPanel();
		fieldsPanel.setLayout(new GridLayout(3, 1, 3, 3));

		JPanel namePanel = new JPanel();
		namePanel.setBorder(BorderFactory.createTitledBorder("Name"));

		JTextField nameField = new JTextField();
		nameField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		namePanel.add(nameField);
		fieldsPanel.add(namePanel);

		JPanel emailPanel = new JPanel();
		emailPanel.setBorder(BorderFactory.createTitledBorder("Email"));

		JTextField emailField = new JTextField();
		emailField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		emailPanel.add(emailField);
		fieldsPanel.add(emailPanel);

		JPanel passwordPanel = new JPanel();
		passwordPanel.setBorder(BorderFactory.createTitledBorder("Password"));

		JTextField passwordField = new JPasswordField();
		passwordField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		passwordPanel.add(passwordField);
		fieldsPanel.add(passwordPanel);

		content.add(fieldsPanel);

		JPanel buttonsPanel = new JPanel(new GridLayout(1, 2, 5, 5));

		JButton addButton = new JButton("Add");
		addButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String name = nameField.getText();
					String email = emailField.getText();
					String password = passwordField.getText();

					int id = service.addCompany(new Company(name, email, password));
					JOptionPane.showMessageDialog(null,
							"Added company with id #" + id + ". Go to Get Companies to see it.",
							"Company Addition Success", JOptionPane.INFORMATION_MESSAGE);

					nameField.setText("");
					emailField.setText("");
					passwordField.setText("");
				} catch (Exception e1) {
					e1.printStackTrace();
					if (e1.getCause() != null) {
						e1.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, e1.getMessage(), "Company Addition Failure",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		buttonsPanel.add(addButton);

		JButton clearButton = new JButton("Clear");
		clearButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				nameField.setText(null);
				emailField.setText(null);
				passwordField.setText(null);
			}
		});
		buttonsPanel.add(clearButton);

		content.add(buttonsPanel);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, fieldsPanel, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, fieldsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		contentLayout.putConstraint(SpringLayout.NORTH, buttonsPanel, 10, SpringLayout.SOUTH, fieldsPanel);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, buttonsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		content.revalidate();
		content.repaint();
	}

	private void setUpdateCompanyComponents() {
		JLabel title = new JLabel("Update Company");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		JPanel fieldsPanel = new JPanel();
		fieldsPanel.setLayout(new GridLayout(3, 1, 3, 3));

		JPanel idPanel = new JPanel();
		idPanel.setBorder(BorderFactory.createTitledBorder("ID"));

		JTextField idField = new JTextField();
		idField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		idPanel.add(idField);
		fieldsPanel.add(idPanel);

		JPanel emailPanel = new JPanel();
		emailPanel.setBorder(BorderFactory.createTitledBorder("Email"));

		JTextField emailField = new JTextField();
		emailField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		emailPanel.add(emailField);
		fieldsPanel.add(emailPanel);

		JPanel passwordPanel = new JPanel();
		passwordPanel.setBorder(BorderFactory.createTitledBorder("Password"));

		JTextField passwordField = new JPasswordField();
		passwordField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		passwordPanel.add(passwordField);
		fieldsPanel.add(passwordPanel);

		content.add(fieldsPanel);

		JPanel buttonsPanel = new JPanel(new GridLayout(1, 2, 5, 5));

		JButton updateButton = new JButton("Update");
		updateButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int choice = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to apply these changes? You cannot revert them!",
						"Company Update Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

				if (choice == JOptionPane.YES_OPTION) {
					try {
						if (idField.getText().isBlank()) {
							throw new Exception("Cannot update a company without id.");

						}

						int id = Integer.parseInt(idField.getText());

						if (emailField.getText().isBlank() && passwordField.getText().isBlank()) {
							throw new Exception("No update was made as there is no info to update.");
						}
						String email = emailField.getText();
						String password = passwordField.getText();

						service.updateCompany(new Company(id, email, password));
						JOptionPane.showMessageDialog(null,
								"Updated company with id #" + id + ". Go to Get Companies to see it.",
								"Company Update Success", JOptionPane.INFORMATION_MESSAGE);

					} catch (NumberFormatException e1) {
						e1.printStackTrace();
						if (e1.getCause() != null) {
							e1.getCause().printStackTrace();
						}
						JOptionPane.showMessageDialog(null, "Invalid id Input.", "Company Update Failure",
								JOptionPane.ERROR_MESSAGE);

					} catch (Exception e2) {
						e2.printStackTrace();
						if (e2.getCause() != null) {
							e2.getCause().printStackTrace();
						}
						JOptionPane.showMessageDialog(null, e2.getMessage(), "Company Update Failure",
								JOptionPane.ERROR_MESSAGE);
					}
				} else {
					JOptionPane.showMessageDialog(null, "No update was made.", "Company Update Notification",
							JOptionPane.WARNING_MESSAGE);
				}
			}
		});
		buttonsPanel.add(updateButton);

		JButton clearButton = new JButton("Clear");
		clearButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				idField.setText(null);
				emailField.setText(null);
				passwordField.setText(null);
			}
		});
		buttonsPanel.add(clearButton);

		content.add(buttonsPanel);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, fieldsPanel, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, fieldsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		contentLayout.putConstraint(SpringLayout.NORTH, buttonsPanel, 10, SpringLayout.SOUTH, fieldsPanel);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, buttonsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		content.revalidate();
		content.repaint();
	}

	private void setDeleteCompanyComponents() {
		JLabel title = new JLabel("Delete Company");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		JPanel fieldPanel = new JPanel();
		fieldPanel.setBorder(BorderFactory.createTitledBorder("ID"));

		JTextField idField = new JTextField();
		idField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		fieldPanel.add(idField);

		content.add(fieldPanel);

		JPanel buttonsPanel = new JPanel(new GridLayout(1, 2, 5, 5));

		JButton deleteButton = new JButton("Delete");
		deleteButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if (idField.getText().isBlank()) {
						throw new Exception("Cannot delete a company without id.");
					}
					int id = Integer.parseInt(idField.getText());

					service.deleteCompany(id);
					JOptionPane.showMessageDialog(null, "Deleted company with id #" + id + ".",
							"Company Deletion Success", JOptionPane.INFORMATION_MESSAGE);

				} catch (NumberFormatException e1) {
					e1.printStackTrace();
					if (e1.getCause() != null) {
						e1.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "Invalid id Input.", "Company Deletion Failure",
							JOptionPane.ERROR_MESSAGE);

				} catch (Exception e2) {
					e2.printStackTrace();
					if (e2.getCause() != null) {
						e2.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, e2.getMessage(), "Company Deletion Failure",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		buttonsPanel.add(deleteButton);

		JButton clearButton = new JButton("Clear");
		clearButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				idField.setText(null);
			}
		});
		buttonsPanel.add(clearButton);

		content.add(buttonsPanel);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, fieldPanel, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, fieldPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		contentLayout.putConstraint(SpringLayout.NORTH, buttonsPanel, 10, SpringLayout.SOUTH, fieldPanel);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, buttonsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		content.revalidate();
		content.repaint();
	}

	private void setGetAllCompaniesComponents() {
		JLabel title = new JLabel("All Companies");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		Object[] cols = { "ID", "Name", "Email", "Password" };
		DefaultTableModel tm = new DefaultTableModel(cols, 0);
		tm.addRow(cols);
		JTable table = new JTable(tm) {

			@Override
			public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
				Component component = super.prepareRenderer(renderer, row, column);
				int rendererWidth = component.getPreferredSize().width;
				TableColumn tableColumn = getColumnModel().getColumn(column);
				tableColumn.setPreferredWidth(
						Math.max(rendererWidth + getIntercellSpacing().width, tableColumn.getPreferredWidth()));
				return component;
			}
		};
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setBorder(new LineBorder(Color.black));
		DefaultTableCellRenderer cellRender = new DefaultTableCellRenderer();
		cellRender.setHorizontalAlignment(SwingConstants.CENTER);

		for (int i = 0; i < table.getColumnCount(); i++) {
			table.getColumnModel().getColumn(i).setCellRenderer(cellRender);
		}

		try {
			List<Company> companies = service.getAllCompanies();
			for (int i = 0; i < companies.size(); i++) {
				int id = companies.get(i).getId();
				String name = companies.get(i).getName();
				String email = companies.get(i).getEmail();
				String password = companies.get(i).getPassword();
				Object[] vals = { id, name, email, password };
				tm.addRow(vals);
			}
		} catch (ServiceException e) {
			e.printStackTrace();
			if (e.getCause() != null) {
				e.getCause().printStackTrace();
			}
			JOptionPane.showMessageDialog(null, e.getMessage(), "Companies Retrieval Failure",
					JOptionPane.ERROR_MESSAGE);
		}
		content.add(table);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, table, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, table, 0, SpringLayout.HORIZONTAL_CENTER, content);

		content.revalidate();
		content.repaint();
	}

	private void setGetOneCompanyComponents() {
		JLabel title = new JLabel("One Company");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		JPanel fieldsPanel = new JPanel();
		fieldsPanel.setLayout(new GridLayout(4, 1, 3, 3));

		JPanel idPanel = new JPanel();
		idPanel.setBorder(BorderFactory.createTitledBorder("ID"));

		JTextField idField = new JTextField();
		idField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.04), (int) (screenSize.getHeight() * 0.02)));
		idPanel.add(idField);

		fieldsPanel.add(idPanel);

		JPanel namePanel = new JPanel();
		namePanel.setBorder(BorderFactory.createTitledBorder("Name"));

		JTextField nameField = new JTextField();
		nameField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		nameField.setFocusable(false);
		namePanel.add(nameField);

		fieldsPanel.add(namePanel);

		JPanel emailPanel = new JPanel();
		emailPanel.setBorder(BorderFactory.createTitledBorder("Email"));

		JTextField emailField = new JTextField();
		emailField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		emailField.setFocusable(false);
		emailPanel.add(emailField);

		fieldsPanel.add(emailPanel);

		JPanel passwordPanel = new JPanel();
		passwordPanel.setBorder(BorderFactory.createTitledBorder("Password"));

		JTextField passwordField = new JTextField();
		passwordField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		passwordField.setFocusable(false);
		passwordPanel.add(passwordField);

		fieldsPanel.add(passwordPanel);

		JButton showButton = new JButton("Show");
		showButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					int id = Integer.parseInt(idField.getText());
					Company company = service.getOneCompany(id);
					nameField.setText(company.getName());
					emailField.setText(company.getEmail());
					passwordField.setText(company.getPassword());

				} catch (NumberFormatException e1) {
					e1.printStackTrace();
					if (e1.getCause() != null) {
						e1.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "Invalid id Input.", "Company Retrieval Failure",
							JOptionPane.ERROR_MESSAGE);

					nameField.setText(null);
					emailField.setText(null);
					passwordField.setText(null);

				} catch (Exception e2) {
					e2.printStackTrace();
					if (e2.getCause() != null) {
						e2.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, e2.getMessage(), "Company Retrieval Failure",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		idPanel.add(showButton);

		content.add(fieldsPanel);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, fieldsPanel, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, fieldsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		content.revalidate();
		content.repaint();
	}

	private void setAddCustomerComponents() {
		JLabel title = new JLabel("Add Customer");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		JPanel fieldsPanel = new JPanel();
		fieldsPanel.setLayout(new GridLayout(4, 1, 3, 3));

		JPanel fNamePanel = new JPanel();
		fNamePanel.setBorder(BorderFactory.createTitledBorder("First Name"));

		JTextField fNameField = new JTextField();
		fNameField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		fNamePanel.add(fNameField);
		fieldsPanel.add(fNamePanel);

		JPanel lNamePanel = new JPanel();
		lNamePanel.setBorder(BorderFactory.createTitledBorder("Last Name"));

		JTextField lNameField = new JTextField();
		lNameField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		lNamePanel.add(lNameField);
		fieldsPanel.add(lNamePanel);

		JPanel emailPanel = new JPanel();
		emailPanel.setBorder(BorderFactory.createTitledBorder("Email"));

		JTextField emailField = new JTextField();
		emailField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		emailPanel.add(emailField);
		fieldsPanel.add(emailPanel);

		JPanel passwordPanel = new JPanel();
		passwordPanel.setBorder(BorderFactory.createTitledBorder("Password"));

		JTextField passwordField = new JPasswordField();
		passwordField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		passwordPanel.add(passwordField);
		fieldsPanel.add(passwordPanel);

		content.add(fieldsPanel);

		JPanel buttonsPanel = new JPanel(new GridLayout(1, 2, 5, 5));

		JButton addButton = new JButton("Add");
		addButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					String fName = fNameField.getText();
					String lName = lNameField.getText();
					String email = emailField.getText();
					String password = passwordField.getText();

					int id = service.addCustomer(new Customer(fName, lName, email, password));
					JOptionPane.showMessageDialog(null,
							"Added customer with id #" + id + ". Go to Get Customer to see it.",
							"Customer Addition Success", JOptionPane.INFORMATION_MESSAGE);

					fNameField.setText("");
					lNameField.setText("");
					emailField.setText("");
					passwordField.setText("");
				} catch (Exception e1) {
					e1.printStackTrace();
					if (e1.getCause() != null) {
						e1.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, e1.getMessage(), "Customer Addition Failure",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		buttonsPanel.add(addButton);

		JButton clearButton = new JButton("Clear");
		clearButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				fNameField.setText(null);
				lNameField.setText(null);
				emailField.setText(null);
				passwordField.setText(null);
			}
		});
		buttonsPanel.add(clearButton);

		content.add(buttonsPanel);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, fieldsPanel, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, fieldsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		contentLayout.putConstraint(SpringLayout.NORTH, buttonsPanel, 10, SpringLayout.SOUTH, fieldsPanel);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, buttonsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		content.revalidate();
		content.repaint();
	}

	private void setUpdateCustomerComponents() {
		JLabel title = new JLabel("Update Customer");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		JPanel fieldsPanel = new JPanel();
		fieldsPanel.setLayout(new GridLayout(5, 1, 3, 3));

		JPanel idPanel = new JPanel();
		idPanel.setBorder(BorderFactory.createTitledBorder("ID"));

		JTextField idField = new JTextField();
		idField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		idPanel.add(idField);
		fieldsPanel.add(idPanel);

		JPanel fNamePanel = new JPanel();
		fNamePanel.setBorder(BorderFactory.createTitledBorder("First Name"));

		JTextField fNameField = new JTextField();
		fNameField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		fNamePanel.add(fNameField);
		fieldsPanel.add(fNamePanel);

		JPanel lNamePanel = new JPanel();
		lNamePanel.setBorder(BorderFactory.createTitledBorder("Last Name"));

		JTextField lNameField = new JTextField();
		lNameField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		lNamePanel.add(lNameField);
		fieldsPanel.add(lNamePanel);

		JPanel emailPanel = new JPanel();
		emailPanel.setBorder(BorderFactory.createTitledBorder("Email"));

		JTextField emailField = new JTextField();
		emailField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		emailPanel.add(emailField);
		fieldsPanel.add(emailPanel);

		JPanel passwordPanel = new JPanel();
		passwordPanel.setBorder(BorderFactory.createTitledBorder("Password"));

		JTextField passwordField = new JPasswordField();
		passwordField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		passwordPanel.add(passwordField);
		fieldsPanel.add(passwordPanel);

		content.add(fieldsPanel);

		JPanel buttonsPanel = new JPanel(new GridLayout(1, 2, 5, 5));

		JButton updateButton = new JButton("Update");
		updateButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int choice = JOptionPane.showConfirmDialog(null,
						"Are you sure you want to apply these changes? You cannot revert them!",
						"Customer Update Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

				if (choice == JOptionPane.YES_OPTION) {
					try {

						if (idField.getText().isBlank()) {
							throw new Exception("Cannot update a customer without id.");
						}

						int id = Integer.parseInt(idField.getText());

						if (fNameField.getText().isBlank() && lNameField.getText().isBlank()
								&& emailField.getText().isBlank() && passwordField.getText().isBlank()) {
							throw new Exception("No update was made as there is no info to update.");
						}
						String fName = fNameField.getText();
						String lName = lNameField.getText();
						String email = emailField.getText();
						String password = passwordField.getText();

						service.updateCustomer(new Customer(id, fName, lName, email, password));
						JOptionPane.showMessageDialog(null,
								"Updated customer with id #" + id + ". Go to Get Customer to see it.",
								"Customer Update Success", JOptionPane.INFORMATION_MESSAGE);

					} catch (NumberFormatException e1) {
						e1.printStackTrace();
						if (e1.getCause() != null) {
							e1.getCause().printStackTrace();
						}
						JOptionPane.showMessageDialog(null, "Invalid id Input.", "Customer Update Failure",
								JOptionPane.ERROR_MESSAGE);

					} catch (Exception e2) {
						e2.printStackTrace();
						if (e2.getCause() != null) {
							e2.getCause().printStackTrace();
						}
						JOptionPane.showMessageDialog(null, e2.getMessage(), "Customer Update Failure",
								JOptionPane.ERROR_MESSAGE);
					}
				} else {
					JOptionPane.showMessageDialog(null, "No update was made.", "Customer Update Notification",
							JOptionPane.WARNING_MESSAGE);
				}

			}
		});
		buttonsPanel.add(updateButton);

		JButton clearButton = new JButton("Clear");
		clearButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				idField.setText(null);
				fNameField.setText(null);
				lNameField.setText(null);
				emailField.setText(null);
				passwordField.setText(null);
			}
		});
		buttonsPanel.add(clearButton);

		content.add(buttonsPanel);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, fieldsPanel, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, fieldsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		contentLayout.putConstraint(SpringLayout.NORTH, buttonsPanel, 10, SpringLayout.SOUTH, fieldsPanel);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, buttonsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		content.revalidate();
		content.repaint();
	}

	private void setDeleteCustomerComponents() {
		JLabel title = new JLabel("Delete Customer");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		JPanel fieldPanel = new JPanel();
		fieldPanel.setBorder(BorderFactory.createTitledBorder("ID"));

		JTextField idField = new JTextField();
		idField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		fieldPanel.add(idField);

		content.add(fieldPanel);

		JPanel buttonsPanel = new JPanel(new GridLayout(1, 2, 5, 5));

		JButton deleteButton = new JButton("Delete");
		deleteButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					if (idField.getText().isBlank()) {
						throw new Exception("Cannot delete a customer without id.");
					}
					int id = Integer.parseInt(idField.getText());

					service.deleteCustomer(id);
					JOptionPane.showMessageDialog(null, "Deleted customer with id #" + id + ".",
							"Customer Deletion Success", JOptionPane.INFORMATION_MESSAGE);

				} catch (NumberFormatException e1) {
					e1.printStackTrace();
					if (e1.getCause() != null) {
						e1.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "Invalid id Input.", "Customer Deletion Failure",
							JOptionPane.ERROR_MESSAGE);

				} catch (Exception e2) {
					e2.printStackTrace();
					if (e2.getCause() != null) {
						e2.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, e2.getMessage(), "Customer Deletion Failure",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		buttonsPanel.add(deleteButton);

		JButton clearButton = new JButton("Clear");
		clearButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				idField.setText(null);
			}
		});
		buttonsPanel.add(clearButton);

		content.add(buttonsPanel);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, fieldPanel, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, fieldPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		contentLayout.putConstraint(SpringLayout.NORTH, buttonsPanel, 10, SpringLayout.SOUTH, fieldPanel);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, buttonsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		content.revalidate();
		content.repaint();
	}

	private void setGetAllCustomersComponents() {
		JLabel title = new JLabel("All Customers");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		Object[] cols = { "ID", "First Name", "Last Name", "Email", "Password" };
		DefaultTableModel tm = new DefaultTableModel(cols, 0);
		tm.addRow(cols);
		JTable table = new JTable(tm) {

			@Override
			public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
				Component component = super.prepareRenderer(renderer, row, column);
				int rendererWidth = component.getPreferredSize().width;
				TableColumn tableColumn = getColumnModel().getColumn(column);
				tableColumn.setPreferredWidth(
						Math.max(rendererWidth + getIntercellSpacing().width, tableColumn.getPreferredWidth()));
				return component;
			}
		};
		table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		table.setBorder(new LineBorder(Color.black));
		DefaultTableCellRenderer cellRender = new DefaultTableCellRenderer();
		cellRender.setHorizontalAlignment(SwingConstants.CENTER);

		for (int i = 0; i < table.getColumnCount(); i++) {
			table.getColumnModel().getColumn(i).setCellRenderer(cellRender);
		}

		try {
			List<Customer> customers = service.getAllCustomers();
			for (int i = 0; i < customers.size(); i++) {
				int id = customers.get(i).getId();
				String fName = customers.get(i).getFirstName();
				String lName = customers.get(i).getLastName();
				String email = customers.get(i).getEmail();
				String password = customers.get(i).getPassword();
				Object[] vals = { id, fName, lName, email, password };
				tm.addRow(vals);
			}
		} catch (ServiceException e) {
			e.printStackTrace();
			if (e.getCause() != null) {
				e.getCause().printStackTrace();
			}
			JOptionPane.showMessageDialog(null, e.getMessage(), "Customers Retrieval Failure",
					JOptionPane.ERROR_MESSAGE);
		}
		content.add(table);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, table, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, table, 0, SpringLayout.HORIZONTAL_CENTER, content);

		content.revalidate();
		content.repaint();
	}

	private void setGetOneCustomerComponents() {
		JLabel title = new JLabel("One Customer");
		title.setFont(new Font("Calibri", Font.BOLD, 20));
		content.add(title);

		JPanel fieldsPanel = new JPanel();
		fieldsPanel.setLayout(new GridLayout(5, 1, 3, 3));

		JPanel idPanel = new JPanel();
		idPanel.setBorder(BorderFactory.createTitledBorder("ID"));

		JTextField idField = new JTextField();
		idField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.04), (int) (screenSize.getHeight() * 0.02)));
		idPanel.add(idField);

		fieldsPanel.add(idPanel);

		JPanel fNamePanel = new JPanel();
		fNamePanel.setBorder(BorderFactory.createTitledBorder("First Name"));

		JTextField fNameField = new JTextField();
		fNameField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		fNameField.setFocusable(false);
		fNamePanel.add(fNameField);

		fieldsPanel.add(fNamePanel);

		JPanel lNamePanel = new JPanel();
		lNamePanel.setBorder(BorderFactory.createTitledBorder("Last Name"));

		JTextField lNameField = new JTextField();
		lNameField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		lNameField.setFocusable(false);
		lNamePanel.add(lNameField);

		fieldsPanel.add(lNamePanel);

		JPanel emailPanel = new JPanel();
		emailPanel.setBorder(BorderFactory.createTitledBorder("Email"));

		JTextField emailField = new JTextField();
		emailField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		emailField.setFocusable(false);
		emailPanel.add(emailField);

		fieldsPanel.add(emailPanel);

		JPanel passwordPanel = new JPanel();
		passwordPanel.setBorder(BorderFactory.createTitledBorder("Password"));

		JTextField passwordField = new JTextField();
		passwordField.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		passwordField.setFocusable(false);
		passwordPanel.add(passwordField);

		fieldsPanel.add(passwordPanel);

		JButton showButton = new JButton("Show");
		showButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					int id = Integer.parseInt(idField.getText());
					Customer customer = service.getOneCustomer(id);
					fNameField.setText(customer.getFirstName());
					lNameField.setText(customer.getLastName());
					emailField.setText(customer.getEmail());
					passwordField.setText(customer.getPassword());

				} catch (NumberFormatException e1) {
					e1.printStackTrace();
					if (e1.getCause() != null) {
						e1.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, "Invalid id Input.", "Customer Retrieval Failure",
							JOptionPane.ERROR_MESSAGE);

					fNameField.setText(null);
					emailField.setText(null);
					passwordField.setText(null);

				} catch (Exception e2) {
					e2.printStackTrace();
					if (e2.getCause() != null) {
						e2.getCause().printStackTrace();
					}
					JOptionPane.showMessageDialog(null, e2.getMessage(), "Customer Retrieval Failure",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		idPanel.add(showButton);

		content.add(fieldsPanel);

		contentLayout.putConstraint(SpringLayout.NORTH, title, (int) (content.getHeight() * 0.1), SpringLayout.NORTH,
				content);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		contentLayout.putConstraint(SpringLayout.NORTH, fieldsPanel, 10, SpringLayout.SOUTH, title);
		contentLayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, fieldsPanel, 0, SpringLayout.HORIZONTAL_CENTER,
				content);

		content.revalidate();
		content.repaint();
	}
}
