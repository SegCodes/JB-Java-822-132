package app.core.gui;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

import org.springframework.context.ApplicationContext;

import app.core.services.AdminService;
import app.core.services.ClientService;
import app.core.services.CompanyService;
import app.core.services.CustomerService;
import app.core.services.LoginManager;
import app.core.services.LoginManager.ClientType;

public class LoginScreen {

	private static JFrame frame;
	private static JPanel content;
	private static ApplicationContext context;
	private static Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

	public static void startApplication(ApplicationContext ctx) {
		if (ctx != null) {
			context = ctx;
		}
		startLoginScreen();
	}

	private static void startLoginScreen() {
		frame = new JFrame("Coupon System - Login");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() / 6.4), (int) (screenSize.getHeight() / 5.3)));

		SpringLayout layout = new SpringLayout();
		content = new JPanel();
		content.setLayout(layout);

		JLabel title = new JLabel("Login");
		title.setFont(new Font("Calibri", Font.BOLD, 20));

		content.add(title);

		JPanel fieldsPanel = new JPanel();
		fieldsPanel.setLayout(new GridBagLayout());
		fieldsPanel.setBorder(BorderFactory.createTitledBorder("Login Info"));

		GridBagConstraints gbc = new GridBagConstraints();

		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets = new Insets(0, 0, 0, 0);

		JLabel emailLabel = new JLabel("Email:");
		fieldsPanel.add(emailLabel, gbc);

		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.insets = new Insets(0, 5, 0, 0);

		JTextField emailTextBox = new JTextField();
		emailTextBox.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		fieldsPanel.add(emailTextBox, gbc);

		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.insets = new Insets(5, 0, 0, 0);

		JLabel passwordLabel = new JLabel("Password:");
		fieldsPanel.add(passwordLabel, gbc);

		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.insets = new Insets(5, 5, 0, 0);

		JTextField passwordTextBox = new JPasswordField();
		passwordTextBox.setPreferredSize(
				new Dimension((int) (screenSize.getWidth() * 0.08), (int) (screenSize.getHeight() * 0.02)));
		fieldsPanel.add(passwordTextBox, gbc);

		content.add(fieldsPanel);

		JPanel buttonsPanel = new JPanel(new GridLayout(1, 2, 5, 5));

		JButton loginButton = new JButton("Login");
		loginButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String email = emailTextBox.getText();
				String password = passwordTextBox.getText();

				ClientService service;
				for (int i = 0; i < ClientType.values().length; i++) {
					ClientType type = ClientType.values()[i];
					service = LoginManager.Login(email, password, type, context);
					if (service instanceof AdminService) {
						AdminService adminService = (AdminService) service;
						frame.dispose();
						new AdminScreen(adminService);
						break;

					} else if (service instanceof CompanyService) {
						CompanyService companyService = (CompanyService) service;
						frame.dispose();
						new CompanyScreen(companyService);
						break;

					} else if (service instanceof CustomerService) {
						CustomerService customerService = (CustomerService) service;
						frame.dispose();
						new CustomerScreen(customerService);
						break;

					} else if (i == ClientType.values().length - 1) {
						JOptionPane.showMessageDialog(null, "Login failed! Email or password is wrong.",
								"Login Failure", JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});
		buttonsPanel.add(loginButton);

		JButton clearButton = new JButton("Clear");
		clearButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				emailTextBox.setText(null);
				passwordTextBox.setText(null);
			}
		});
		buttonsPanel.add(clearButton);

		content.add(buttonsPanel);

		layout.putConstraint(SpringLayout.NORTH, title, 15, SpringLayout.NORTH, content);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, title, 0, SpringLayout.HORIZONTAL_CENTER, content);

		layout.putConstraint(SpringLayout.NORTH, fieldsPanel, -5, SpringLayout.SOUTH, title);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, fieldsPanel, 0, SpringLayout.HORIZONTAL_CENTER, content);

		layout.putConstraint(SpringLayout.NORTH, buttonsPanel, 10, SpringLayout.SOUTH, fieldsPanel);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, buttonsPanel, 0, SpringLayout.HORIZONTAL_CENTER, content);

		frame.setResizable(false);
		frame.setContentPane(content);
		frame.pack();
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
	}
}
