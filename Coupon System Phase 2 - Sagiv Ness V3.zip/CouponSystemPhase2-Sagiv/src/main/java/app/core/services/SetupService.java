package app.core.services;

import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import app.core.entities.Company;
import app.core.entities.Coupon;
import app.core.entities.Customer;
import app.core.exceptions.ServiceException;
import app.core.repositories.CompaniesRepository;
import app.core.repositories.CouponsRepository;
import app.core.repositories.CustomersRepository;

@Service
@Transactional(rollbackFor = ServiceException.class)
public class SetupService {

	@Autowired
	private CouponsRepository couponsRepo;
	@Autowired
	private CompaniesRepository companiesRepo;
	@Autowired
	private CustomersRepository customersRepo;

	public int addExpiredCoupon(Coupon coupon, int companyID) throws ServiceException {
		Company company = companiesRepo.findById(companyID)
				.orElseThrow(() -> new ServiceException("No company was found with id #" + companyID + "."));
		coupon.setCompany(company);

		if (coupon.getStartDate() == null || coupon.getEndDate() == null) {
			throw new ServiceException("Expired coupon must have a start date and expiration date entered.");

		} else if (coupon.getEndDate().isAfter(LocalDate.now())) {
			throw new ServiceException("Expiration date has not pass yet.");
		}

		coupon = couponsRepo.save(coupon);
		return coupon.getId();
	}
	
	public void purchaseExpiredCoupon(Coupon coupon, int customerID) throws ServiceException {
		Customer customer = customersRepo.findById(customerID)
				.orElseThrow(() -> new ServiceException("No customer was found with id #" + customerID + "."));
		
		if (coupon.getStartDate() == null || coupon.getEndDate() == null) {
			throw new ServiceException("Expired coupon must have a start date and expiration date entered.");
			
		} else if (coupon.getEndDate().isAfter(LocalDate.now())) {
			throw new ServiceException("Expiration date has not pass yet.");
		}
		
		customer.purchaseCoupon(coupon);
		
	}

}
