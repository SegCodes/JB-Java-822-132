package app.core.services;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import app.core.entities.Company;
import app.core.entities.Coupon;
import app.core.entities.Coupon.Category;
import app.core.exceptions.ServiceException;

@Service
@Transactional(rollbackFor = ServiceException.class)
@Scope("prototype")
public class CompanyService extends ClientService {

	private int companyID;

	public int getID() {
		return this.companyID;
	}

	@Override
	public boolean login(String email, String password) {
		Optional<Company> opt = companiesRepo.findByEmailAndPassword(email, password);
		if (opt.isPresent()) {
			this.companyID = opt.get().getId();
			return true;
		} else {
			return false;
		}
	}

	public int addCoupon(Coupon coupon) throws ServiceException {
		try {
			coupon.setId(0);
			Company company = getInfo();
			coupon.setCompany(company);

			if (coupon.getCategory() == null) {
				throw new ServiceException("Category is empty.");

			} else if (coupon.getTitle().isBlank() || coupon.getTitle() == null) {
				throw new ServiceException("Title is empty.");

			} else if (couponsRepo.existsByCompanyIdAndTitle(companyID, coupon.getTitle())) {
				throw new ServiceException("You already have a coupon with this title.");

			} else if (coupon.getDescription().isBlank() || coupon.getDescription() == null) {
				throw new ServiceException("Description is empty.");

			} else if (coupon.getStartDate() == null) {
				throw new ServiceException("Start date is empty.");

			} else if (coupon.getEndDate() == null) {
				throw new ServiceException("Expiration date is empty.");

			} else if (coupon.getStartDate().isAfter(coupon.getEndDate())) {
				throw new ServiceException("Start date cannot be after expiration date.");

			} else if (coupon.getEndDate().isBefore(LocalDate.now())) {
				throw new ServiceException("Coupon is expired.");

			} else if (coupon.getAmount() == 0) {
				throw new ServiceException("Stock is empty.");

			} else if (coupon.getPrice() == 0) {
				throw new ServiceException("Price cannot be free.");

			} else if (coupon.getImgPath().isBlank() || coupon.getImgPath() == null) {
				throw new ServiceException("Image path is empty.");
			}

			coupon = couponsRepo.save(coupon);
			company.addCoupon(coupon);
			return coupon.getId();
		} catch (Exception e) {
			throw new ServiceException("Coupon Addition failed - " + e.getMessage(), e);
		}
	}

	public void updateCoupon(Coupon coupon) throws ServiceException {
		try {
			Coupon ogCoupon = couponsRepo.findById(coupon.getId())
					.orElseThrow(() -> new ServiceException("No coupon with id #" + coupon.getId() + " was found."));

			if (ogCoupon.getCompany().getId() != companyID) {
				throw new ServiceException("Coupon does not belong to you.");
			}

			if (coupon.getCategory() != null && !ogCoupon.getCategory().equals(coupon.getCategory())) {
				ogCoupon.setCategory(coupon.getCategory());
			}

			if (!coupon.getTitle().isBlank() && !ogCoupon.getTitle().equals(coupon.getTitle())) {
				ogCoupon.setTitle(coupon.getTitle());
			}

			if (!coupon.getDescription().isBlank() && !ogCoupon.getDescription().equals(coupon.getDescription())) {
				ogCoupon.setDescription(coupon.getDescription());
			}

			if (coupon.getStartDate() != null && coupon.getEndDate() != null
					&& coupon.getStartDate().isAfter(coupon.getEndDate()) && coupon.getStartDate().isAfter(ogCoupon.getEndDate())) {
				throw new ServiceException("Start date cannot be after expiration date.");

			} else if (coupon.getStartDate() != null && !ogCoupon.getStartDate().equals(coupon.getStartDate())) {
				ogCoupon.setStartDate(coupon.getStartDate());
			}

			if (coupon.getEndDate() != null && coupon.getEndDate().isBefore(LocalDate.now())) {
				throw new ServiceException("Expiration date has already passed.");

			} else if (coupon.getEndDate() != null && !ogCoupon.getEndDate().equals(coupon.getEndDate())) {
				ogCoupon.setEndDate(coupon.getEndDate());
			}

			if (coupon.getAmount() >= 0 && ogCoupon.getAmount() != coupon.getAmount()) {
				ogCoupon.setAmount(coupon.getAmount());
			}

			if (coupon.getPrice() >= 0 && ogCoupon.getPrice() != coupon.getPrice()) {
				ogCoupon.setPrice(coupon.getPrice());
			}
		} catch (Exception e) {
			throw new ServiceException("Coupon update failed - " + e.getMessage(), e);
		}
	}

	public void deleteCoupon(int couponID) throws ServiceException {
		try {
			Coupon coupon = couponsRepo.findById(couponID)
					.orElseThrow(() -> new ServiceException("No coupon with id #" + couponID + " was found."));

			if (coupon.getCompany().getId() != this.companyID) {
				throw new ServiceException("Cannot delete a coupon that does not belong to you.");
			}
			coupon.deletePurchaseHistory();
			coupon.getCompany().getCoupons().remove(coupon);
			couponsRepo.delete(coupon);
		} catch (Exception e) {
			throw new ServiceException("Coupon deletion failed - " + e.getMessage(), e);
		}
	}

	public List<Coupon> getCoupons() throws ServiceException {
		try {
			List<Coupon> coupons = couponsRepo.findByCompanyId(companyID);
			if (coupons.isEmpty()) {
				throw new ServiceException("You don't have any coupons.");
			}
			return coupons;
		} catch (Exception e) {
			throw new ServiceException("Customer's coupons retrieval failed - " + e.getMessage(), e);
		}
	}

	public List<Coupon> getCoupons(Category category) throws ServiceException {
		try {
			List<Coupon> coupons = couponsRepo.findByCompanyIdAndCategory(companyID, category);
			if (coupons.isEmpty()) {
				throw new ServiceException("You don't have any coupons in category: " + category);
			}
			return coupons;
		} catch (Exception e) {
			throw new ServiceException("Customer's coupons retrieval by category failed - " + e.getMessage(), e);
		}
	}

	public List<Coupon> getCoupons(double maxPrice) throws ServiceException {
		try {
			List<Coupon> coupons = couponsRepo.findByCompanyIdAndPriceLessThanEqual(companyID, maxPrice);
			if (coupons.isEmpty()) {
				throw new ServiceException("You don't have any coupons under price: " + maxPrice);
			}
			return coupons;
		} catch (Exception e) {
			throw new ServiceException("Customer's coupons retrieval by price failed - " + e.getMessage(), e);
		}
	}

	public Company getInfo() throws ServiceException {
		try {
			return companiesRepo.findById(companyID)
					.orElseThrow(() -> new ServiceException("No company with id #" + companyID + " was found."));
		} catch (Exception e) {
			throw new ServiceException("Company info retrieval failed - " + e.getMessage(), e);
		}
	}
}
