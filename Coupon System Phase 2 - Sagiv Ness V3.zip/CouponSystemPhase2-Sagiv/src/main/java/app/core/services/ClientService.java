package app.core.services;

import javax.persistence.MappedSuperclass;

import org.springframework.beans.factory.annotation.Autowired;

import app.core.repositories.CompaniesRepository;
import app.core.repositories.CouponsRepository;
import app.core.repositories.CustomersRepository;

@MappedSuperclass
public abstract class ClientService {
	
	@Autowired
	protected CustomersRepository customersRepo;
	@Autowired
	protected CompaniesRepository companiesRepo;
	@Autowired
	protected CouponsRepository couponsRepo;
	
	public abstract boolean login(String email, String password);
}
