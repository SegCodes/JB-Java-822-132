package app.core.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import app.core.entities.Employee;
import app.core.entities.Job;
import app.core.repositories.EmployeeRepository;
import app.core.repositories.JobRepository;

@Service
@Transactional(rollbackFor = Exception.class)
public class CompanyService {

	@Autowired
	private EmployeeRepository employeeRepo;
	@Autowired
	private JobRepository jobRepo;

	public Long addEmployee(Employee employee) {
		employee.setId(0);
		if (employee.getJobs() != null && !employee.getJobs().isEmpty()) {
			employee.setJobs(employee.getJobs());
			jobRepo.saveAll(employee.getJobs());
		}
		employee = employeeRepo.save(employee);
		return employee.getId();
	}

	public Employee getEmployee(long employeeID) throws Exception {
		return employeeRepo.findById(employeeID)
				.orElseThrow(() -> new Exception("No employee with id #" + employeeID + " was found."));
	}

	public List<Employee> getEmployees() throws Exception {
		List<Employee> employees = employeeRepo.findAll();

		if (employees == null) {
			throw new Exception("List is null.");

		} else if (employees.isEmpty()) {
			throw new Exception("There are no employees.");
		}
		return employees;
	}

	public List<Employee> getEmployees(String name) throws Exception {
		List<Employee> employees = employeeRepo.findEmployeesByName(name);

		if (employees == null) {
			throw new Exception("List is null.");

		} else if (employees.isEmpty()) {
			throw new Exception("There are no employees with name: " + name + ".");
		}
		return employees;
	}

	public List<Job> getJobs() throws Exception {
		List<Job> jobs = jobRepo.findAll();

		if (jobs == null) {
			throw new Exception("List is null.");

		} else if (jobs.isEmpty()) {
			throw new Exception("There are no jobs.");
		}
		return jobs;
	}

	public List<Job> getJobs(LocalDate endDate) throws Exception {
		List<Job> jobs = jobRepo.findJobsByEndDate(endDate);
		if (jobs == null) {
			throw new Exception("List is null.");

		} else if (jobs.isEmpty()) {
			throw new Exception("There are no jobs in end date: " + endDate + ".");
		}
		return jobs;
	}

	public List<Job> getJobs(LocalDate startDate, LocalDate endDate) throws Exception {
		List<Job> jobs = jobRepo.findJobsByEndDateBetween(startDate, endDate);
		if (jobs == null) {
			throw new Exception("List is null.");

		} else if (jobs.isEmpty()) {
			throw new Exception("There are no jobs between: " + startDate + " and " + endDate + ".");
		}
		return jobs;
	}
}
