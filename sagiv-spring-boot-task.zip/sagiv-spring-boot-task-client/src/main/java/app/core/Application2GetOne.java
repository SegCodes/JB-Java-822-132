package app.core;

import org.springframework.web.client.RestTemplate;

import app.core.beans.Employee;

public class Application2GetOne {

	public static void main(String[] args) {
		String baseUrl = "http://localhost:8080/api/company";
		RestTemplate rt = new RestTemplate();

		long id = 2;
		Employee e = rt.getForObject(baseUrl + "/get/" + id, Employee.class);
		System.out.println(e);
	}

}
