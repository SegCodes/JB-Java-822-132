package app.core.beans;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString(exclude = "employee")
@EqualsAndHashCode(of = "id")
public class Job {

	private long id;
	private String description;
	private LocalDate endDate;
	@JsonIgnore
	private Employee employee;

}
