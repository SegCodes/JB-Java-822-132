package app.core;

import java.util.Arrays;

import org.springframework.web.client.RestTemplate;

import app.core.beans.Employee;

public class Application3GetBatch {

	public static void main(String[] args) {
		String baseUrl = "http://localhost:8080/api/company";
		RestTemplate rt = new RestTemplate();
		
		Employee[] employees = rt.getForObject(baseUrl + "/get/batch", Employee[].class);
		System.out.println(Arrays.asList(employees));
		
		String name = "Sara";
		employees = rt.getForObject(baseUrl + "/get/batch/" + name, Employee[].class);
		System.out.println(Arrays.asList(employees));
	}

}
