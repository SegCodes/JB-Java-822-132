package b;

import Utilites.Names;
import java.util.*;
import java.sql.*;

public class Exe {

	public static void main(String[] args) {
		List<Person> list = new ArrayList<>();
		
		for(int i = 1; i <= 200; i++) {
			int index = (int)(Math.random()*Names.values().length);
			String name = Names.values()[index].toString();
			int age = (int)(Math.random()*80+6);
			list.add(new Person(i, name, age));
		}
		
		String url = "jdbc:mysql://127.0.0.1:3306/db2";
		String sql = "insert into person values(?, ?, ?);";
		
		try(Connection con = DriverManager.getConnection(url, "root", "1234")) {
			System.out.println("Connected to " + url);
			PreparedStatement state = con.prepareStatement(sql);
			
			System.out.println("Filling person...");
			for(Person p : list) {
				state.setInt(1, p.getId());
				state.setString(2, p.getName());
				state.setInt(3, p.getAge());
				state.executeUpdate();
			}
			System.out.println("Done.");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
