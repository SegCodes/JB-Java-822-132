package c;

import java.time.LocalDate;

public class BookMain {

	public static void main(String[] args) {
		
		/*Book b1 = new Book("1235491235", "The Catcher in the Rye", "J.D.Salinger", 19.99, 254, LocalDate.of(1951, 7, 16), "English");
		Book b2 = new Book("9515684123", "Harry Potter: The Sorcerer's Stone", "J.K.Rowling", 29.99, 361, LocalDate.of(1996, 6, 26), "English");
		Book b3 = new Book("4594132154", "Hefetz", "Hanoch Levin", 9.99, 132, LocalDate.of(1972, 3, 5), "Hebrew");
		Book b4 = new Book("4594132154", "Zevel", "Nissim Mizrahi", 9.99, 132, LocalDate.of(1997, 5, 25), "Hebrew");
		

		BookDAO.deleteBook("4594132154");
		BookDAO.getAllBooks();
		BookDAO.updateBook(b4);
		BookDAO.getBook("4594132154");
		BookDAO.addBook(b3);*/
	}

}
