package c;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BookDAO {

	private static String url = "jdbc:mysql://127.0.0.1:3306/db1";
	private static String user = "root";
	private static String password = "1234";
	
	public static void addBook(Book b) {
		String sql = "insert into book values(?, ?, ?, ?, ?, ?, ?);";
		
		try(Connection con = DriverManager.getConnection(url, user, password)) {
			System.out.println("Connected to " + url);
			PreparedStatement state = con.prepareStatement(sql);
			
			System.out.println("Adding book...");
			state.setString(1, b.getIsbn());
			state.setString(2, b.getTitle());
			state.setString(3, b.getAuthor());
			state.setDouble(4, b.getPrice());
			state.setInt(5, b.getPages());
			Date date = Date.valueOf(b.getPublished());
			state.setDate(6, date);
			state.setString(7, b.getLanguage());
			
			state.executeUpdate();
			System.out.println("Book added: " + b.toString());
			System.out.println();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static Book getBook(String isbn) {
		String sql = "select * from book where isbn = " + isbn;
		
		try(Connection con = DriverManager.getConnection(url, user, password)) {
			System.out.println("Connected to " + url);
			
			System.out.println("Getting book with isbn: " + isbn + "...");
			Statement state = con.createStatement();
			ResultSet rs = state.executeQuery(sql);
			
			if(rs.next()) {
				String title = rs.getString("title");
				String author = rs.getString("author");
				double price = rs.getDouble("price");
				int pages = rs.getInt("pages");
				LocalDate published = rs.getDate("published").toLocalDate();
				String language = rs.getString("language");
				
				Book book = new Book(isbn, title, author, price, pages, published, language);
				System.out.println("Got the book " + book.toString());
				System.out.println();
				
				return book;
			} else {
				System.out.println("Book does not exist.");
				System.out.println();
				return null;
			}
			
		} catch(SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static List<Book> getAllBooks() {
		String sql = "select * from book;";
		List<Book> books = new ArrayList<>();
		
		try(Connection con = DriverManager.getConnection(url, user, password)) {
			System.out.println("Connected to " + url);
			
			System.out.println("Getting all book...");
			Statement state = con.createStatement();
			ResultSet rs = state.executeQuery(sql);
			
			while(rs.next()) {
				String isbn = rs.getString("isbn");
				String title = rs.getString("title");
				String author = rs.getString("author");
				double price = rs.getDouble("price");
				int pages = rs.getInt("pages");
				LocalDate published = rs.getDate("published").toLocalDate();
				String language = rs.getString("language");
				
				books.add(new Book(isbn, title, author, price, pages, published, language));
			}
			System.out.println("Got all the books:");
			
			for(Book b: books) {
				System.out.println(b.toString());
			}
			
			System.out.println();
			return books;
			
		} catch(SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static void updateBook(Book b) {
		String sql = "update book set title = ?, author = ?, price = ?, pages = ?, published = ?, language = ? where isbn = " + b.getIsbn();
		try(Connection con = DriverManager.getConnection(url, user, password)) {
			PreparedStatement state = con.prepareStatement(sql);
			
			state.setString(1, b.getTitle());
			state.setString(2, b.getAuthor());
			state.setDouble(3, b.getPrice());
			state.setInt(4, b.getPages());
			Date date = Date.valueOf(b.getPublished());
			state.setDate(5, date);
			state.setString(6, b.getLanguage());
			
			state.executeUpdate();
			
			System.out.println("Updated book: " + b.toString());
			System.out.println();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void deleteBook(String isbn) {
		String sql = "delete from book where isbn = " + isbn;
		
		try (Connection con = DriverManager.getConnection(url, user, password)) {
			System.out.println("Deleting book...");
			Statement state = con.createStatement();
			state.executeUpdate(sql);
			System.out.println("Book deleted." );
			System.out.println();
		} catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	
}
