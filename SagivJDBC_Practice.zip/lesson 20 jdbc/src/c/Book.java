package c;

import java.time.LocalDate;

public class Book {
	
	private String isbn;
	private String title;
	private String author;
	private double price;
	private int pages;
	private LocalDate published;
	private String language;
	
	public Book() {
		
	}
	
	public Book(String isbn, String title, String author, double price, int pages, LocalDate published,
			String language) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		this.price = price;
		this.pages = pages;
		this.published = published;
		this.language = language;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getPages() {
		return pages;
	}

	public void setPages(int pages) {
		this.pages = pages;
	}

	public LocalDate getPublished() {
		return published;
	}

	public void setPublished(LocalDate published) {
		this.published = published;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	@Override
	public String toString() {
		return "[isbn=" + isbn + ", title=" + title + ", author=" + author + ", price=" + price + ", pages="
				+ pages + ", published=" + published + ", language=" + language + "]";
	}
	
}
