package Utilites;

public enum Names {
	BOB, SYLVIA, DANA, JACK, SAM, FRANK, DAVE, NINA, AARON, MAXIMILLIAN, PEDRO, AMELIA, MEG, SANDRA, FRED;
}
