package a;

import java.sql.*;


public class Demo3Statement {

	public static void main(String[] args) {
		
		String url = "jdbc:mysql://localhost:3306/db1";
		// RDBMS credentials.
		String user = "root";
		String password = "1234";
		
		try(Connection con = DriverManager.getConnection(url, user, password)) {
			// With Statement we can execute SQL commands.
			Statement state = con.createStatement();
			// Set the SQL command.
			String sql = "insert into person value(4, 'Ben', 35);";
			// Execute the SQL command.
			state.executeUpdate(sql);
			// Print the successful sql command.
			System.out.println(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
