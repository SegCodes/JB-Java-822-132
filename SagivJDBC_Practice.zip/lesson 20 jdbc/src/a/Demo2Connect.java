package a;

import java.sql.*;

public class Demo2Connect {

	public static void main(String[] args) {
		// To get a connection we need a URL(Uniform Resource Locator).
		String protocol = "jdbc:mysql://";
		String ip = "127.0.0.1:"; // 127.0.0.1 - IP that always refer to this pc.
		String port = "3306/"; // MySQL server application.
		String route = "db1"; // Database name.
		String url = protocol + ip + port + route;
		System.out.println(url);
		
		String user = "root";
		String password = "1234";
		
		try {
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("Connected to " + con);
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
}
