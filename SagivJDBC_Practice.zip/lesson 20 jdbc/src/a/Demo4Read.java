package a;

import java.sql.*;


public class Demo4Read {

	public static void main(String[] args) {
		
		String url = "jdbc:mysql://localhost:3306/db1";
		// RDBMS credentials.
		String user = "root";
		String password = "1234";
		
		try(Connection con = DriverManager.getConnection(url, user, password)) {
			// With Statement we can execute SQL commands.
			Statement state = con.createStatement();
			// Set the SQL command.
			String sql = "select * from person;";
			// Execute the SQL command.
			ResultSet rs = state.executeQuery(sql);
			System.out.println(sql);
			
			// Get Meta Data
			ResultSetMetaData rsMeta = rs.getMetaData();
			for(int i = 1; i <= rsMeta.getColumnCount(); i++) {
				System.out.print(rsMeta.getColumnLabel(i) + ", ");
			}
			System.out.println();
			
			// Get data from ResultSet.
			while(rs.next()) {
				int id = rs.getInt("id");
				System.out.print("[" + id + ", ");
				String name = rs.getString("name");
				System.out.print(name + ", ");
				int age = rs.getInt("age");
				System.out.print(age + "]\n");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
