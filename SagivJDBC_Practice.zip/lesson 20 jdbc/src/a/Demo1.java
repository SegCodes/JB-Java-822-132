package a;

import java.sql.*;
import java.util.*;

public class Demo1 {

	public static void main(String[] args) {
		// To connect to a database we need a driver.
		// The driver is part of the database vendor implementation.
		
		Enumeration<Driver> drivers = DriverManager.getDrivers();
		
		System.out.println("List of drivers:");
		while(drivers.hasMoreElements()) {
			System.out.println(drivers.nextElement());
		}
		System.out.println("====================");
	}

}
