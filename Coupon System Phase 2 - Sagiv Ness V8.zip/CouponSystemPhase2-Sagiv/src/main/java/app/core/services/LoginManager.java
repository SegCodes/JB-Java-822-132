package app.core.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class LoginManager {

	@Autowired
	private ApplicationContext ctx;

	public enum ClientType {
		ADMINISTRATOR, COMPANY, CUSTOMER;
	}

	/**
	 * Attempt to login using the entered email and password as the entered client
	 * type.
	 * 
	 * @param email      - The entered email.
	 * @param password   - The entered password.
	 * @param clientType - The entered client type to login as.
	 * 
	 * @return The matching client service of the client type if the login is
	 *         successful, or null if the login failed.
	 */
	public ClientService Login(String email, String password, ClientType clientType) {
		switch (clientType) {

		case ADMINISTRATOR:
			AdminService adminService = ctx.getBean(AdminService.class);
			if (adminService.login(email, password)) {
				return adminService;
			}
			return null;

		case COMPANY:
			CompanyService companySerivce = ctx.getBean(CompanyService.class);
			if (companySerivce.login(email, password)) {
				return companySerivce;
			}
			return null;

		case CUSTOMER:
			CustomerService customerService = ctx.getBean(CustomerService.class);
			if (customerService.login(email, password)) {
				return customerService;
			}
			return null;

		default:
			return null;
		}
	}
}
